%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Markov-Switching DSGE with Bayesian estimation. Variable alpha
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Begin
%
clc
clear global
clear variables
close all

Sub = '50';     % working subdirectory, to avoid too many files in the current folder
addpath(Sub);
addpath('NewData');
filename = mfilename;   % used for saving

global nst p11_pos p22_pos q11_pos q22_pos beta_pos phi_pos thetaH_pos alpha_pos sigma_pos eta_pos rho_a_pos...
    rho_muF_pos rho_nu_pos sig_muF_pos sig_muH_pos sig_a_pos sig_nu_pos sig_ystar_pos sig_pistar_pos...
    sig_istar_pos ndxSwitch rho_drp_pos sig_drp_pos deltaH_pos deltaF_pos ksi_pos...
    thetaF_pos rho_muH_pos check_cell ndxPM c_ystar_1_pos c_pistar_2_pos c_istar_3_pos...
    mu_y_pos mu_c_pos mu_pi_pos mu_i_pos mu_ys_pos mu_pis_pos mu_is_pos...
    R_y_pos R_c_pos R_pi_pos R_i_pos R_ys_pos R_pis_pos R_is_pos
%% Declaration of Cells
nst = 2;                        % Number of states;
if nst==4; indep = 1; else indep = 0; end; % If nst = 4, the states are independently switching

info_cell = cell(nst,1);        % Information cell that contains everything about the hyperparam
theta_prior  = cell(nst,1);     % Cell for the initial values.
prior_type_cell = cell(nst,1);  % Cell with the prior specifications
draw_cell = cell(nst,1);        % Cell to convert the vector of draws into a cell.
MH_theta_cell = cell(nst,1);    % Saves all the parameters in the MH algorithm
prior_std_cell = cell(nst,1);   % Cell with the prior standard deviations
ndxSwitch = cell(nst,1);        % Cell for the switching, the only exception without_cell
check_cell = cell(nst,1);
Step = 2;                       % 0 for prior 1 for mode, 2 for Mode & Hessian
Asave = 1;                      % 1 to save the variables

%% Data

load EE_CONS_PC.mat         % ee_cons_pc: 1993 Q1 : 2011 Q4 - EE consumption per capita
load EE_GDP_PC.mat          % ee_gdp: 1993 Q1 : 2011 Q4 - EE GDP per capita
load EU_HICP.mat            % eu infl: 1996 Q2 : 2012 Q1 - EU inflation from HICP done (annual) by 400*(lnP/lnP_t-1) 
load EE_HICP.mat            % ee infl: 1996 Q2 : 2012 Q1 - EU inflation from HICP done (annual) by 400*(lnP/lnP_t-1) 
load interest2.mat          % interest(:,1): 1996 Q1 : 2012 Q4 - EU 3-month (annual)
                            % interest(:,2): 1996 Q1 : 2012 Q4 - EE 3-month (annual)
load EE_EU_interest_hp.mat  % interest(:,1): 1996 Q1 : 2012 Q4 - EU 3-month (annual) (HP trend)
load EU_GDP_PC.mat          % eu_gdp: 1995 Q1 : 2011 Q4 - EU GDP per capita
load EU_interest.mat        % eu_i: 1993 Q1 : 2012 Q4 - EU 3-month (annual)
load EE_GDP_INFL.mat        % ee_gdp_infl: 1994 Q1 : 2012 Q4 - EE GDP Deflator inflation (annual) - perc. change
load EE_TOT.mat             % tot: 1993 Q1 : 2012 Q1 - ee log terms of trade = log(ee_P_imp) - log(ee_P_exp)

ee_gdp = ee_gdp(13+1:end);
ee_cons = ee_cons_pc(13+1:end);
ee_pi = ee_infl(1:end-1)/4;
% ee_i = interest(1+1:end-1,2)/4;
ee_i = interest_hp(1+1:end-1,2)/4;  % HP trend
ee_P_infl = ee_gdp_infl(9+1:end-1,1)/4; % Div by for to make it quarterly
ee_tot = tot(13+1:end-1,1);

eu_gdp = eu_gdp(5+1:end);
eu_pi = eu_infl(1:end-1)/4;
eu_i = eu_i(13+1:end-1,1)/4;

yy = [ee_gdp...
    ee_cons...
    ee_pi...
    ee_i...
    eu_gdp...
    eu_pi...
    eu_i...
    ];

time = 1996.25:0.25:2011.75;

%% Parameters
% param = [mu sigma distribution];
% where 1 is for Beta; 2 is for Gamma; 3 is for IGamma; 4 is for Normal; 11 is for
% Point Mass Beta; 12 is for PM Gamma; 13 for PM IGamma; 14 for PM Normal
ppos = 0; ppos = ppos+1; % Parameter position

% Probabilities
p11 = [0.9 0.10 1];   p11_pos = ppos; ppos = ppos+1; parnm=char('$p_{11}$');
p22 = [0.9 0.10 1];   p22_pos = ppos; ppos = ppos+1; parnm=char(parnm,'$p_{22}$');
if nst == 4
q11 = [0.9 0.10 1];   q11_pos = ppos; ppos = ppos+1; parnm=char(parnm,'$q_{11}$');
q22 = [0.9 0.10 1];   q22_pos = ppos; ppos = ppos+1; parnm=char(parnm,'$q_{22}$');
end

% Structural parameters
beta  = [0.995 0 11];    beta_pos = ppos; ppos = ppos+1;    parnm=char(parnm,'$\beta$');    
phi   = [2 0.25 2];        phi_pos = ppos; ppos = ppos+1;   parnm=char(parnm,'$\varphi$'); 
thetaH = [0.75 0.1 1];  thetaH_pos = ppos; ppos = ppos+1;  parnm=char(parnm,'$\theta_H$');  
thetaF = [0.5 0.1 1];  thetaF_pos = ppos; ppos = ppos+1;   parnm=char(parnm,'$\theta_F$'); 
alpha = [0.5 0.1 1];     alpha_pos = ppos; ppos = ppos+1;  parnm=char(parnm,'$\alpha$');  
sigma = [1 1 2];        sigma_pos = ppos; ppos = ppos+1;    parnm=char(parnm,'$\sigma$');
eta   = [2 0.25 2];        eta_pos = ppos; ppos = ppos+1;    parnm=char(parnm,'$\eta$');  
deltaH = [0.5 0.15 1];  deltaH_pos = ppos; ppos = ppos+1;   parnm=char(parnm,'$\delta_H$'); 
deltaF = [0.5 0.15 1];  deltaF_pos = ppos; ppos = ppos+1;   parnm=char(parnm,'$\delta_F$'); 
ksi    = [0.01 0.01 2]; ksi_pos = ppos; ppos = ppos+1;      parnm=char(parnm,'$\chi$');  

% Autoregressive coefficients
rho_a     = [0.7 0.10 1]; rho_a_pos = ppos; ppos = ppos+1;          parnm=char(parnm,'$\rho_a$'); 
rho_muF   = [0.7 0.10 1]; rho_muF_pos = ppos; ppos = ppos+1;        parnm=char(parnm,'$\rho_{\mu_F}$'); 
rho_muH   = [0.7 0.10 1]; rho_muH_pos = ppos; ppos = ppos+1;        parnm=char(parnm,'$\rho_{\mu_H}$'); 
rho_nu    = [0.7 0.10 1]; rho_nu_pos = ppos; ppos = ppos+1;         parnm=char(parnm,'$\rho_{\nu}$');
rho_drp   = [0.7 0.10 1]; rho_drp_pos = ppos; ppos = ppos+1;        parnm=char(parnm,'$\rho_{\phi}$');  
c_ystar_1 = [0.85 0.10 1]; c_ystar_1_pos = ppos; ppos = ppos+1;    parnm=char(parnm,'$c_{y^*}$');  
c_pistar_2 = [0.85 0.10 1]; c_pistar_2_pos = ppos; ppos = ppos+1;  parnm=char(parnm,'$c_{\pi^*}$');  
c_istar_3 = [0.85 0.10 1]; c_istar_3_pos = ppos; ppos = ppos+1;    parnm=char(parnm,'$c_{i^*}$');  

% Standard deviation of the exogenous shocks
sig_muF   = [1 1 3];   sig_muF_pos = ppos;  ppos = ppos+1;  parnm=char(parnm,'$\sigma_{\mu_F}$');    
sig_muH   = [1 1 3];   sig_muH_pos = ppos;  ppos = ppos+1;  parnm=char(parnm,'$\sigma_{\mu_H}$');   
sig_a     = [1 1 3];   sig_a_pos = ppos;    ppos = ppos+1;  parnm=char(parnm,'$\sigma_a$');     
sig_nu    = [1 1 3];   sig_nu_pos = ppos;   ppos = ppos+1;  parnm=char(parnm,'$\sigma_{\nu}$');  
sig_drp   = [0.8 1 3];  sig_drp_pos = ppos; ppos = ppos+1;  parnm=char(parnm,'$\sigma_{\phi}$');  
sig_ystar = [1 1 3];  sig_ystar_pos = ppos; ppos = ppos+1;  parnm=char(parnm,'$\sigma_{y^*}$');   
sig_pistar= [1 1 3];  sig_pistar_pos = ppos;ppos = ppos+1;  parnm=char(parnm,'$\sigma_{\pi^*}$');  
sig_istar = [1 1 3];  sig_istar_pos = ppos;                 parnm=char(parnm,'$\sigma_{i^*}$');     

% Measurement equation components - mean
% ppos = ppos+1;
% mu_y     = [2 1 4]; mu_y_pos = ppos;   parnm=char(parnm,'$\mu_{y}$');     ppos = ppos+1;  
% mu_c     = [1 1 4]; mu_c_pos = ppos;   parnm=char(parnm,'$\mu_{c}$');     ppos = ppos+1;  
% mu_pi    = [0 1 14]; mu_pi_pos = ppos;  parnm=char(parnm,'$\mu_{\pi}$');   ppos = ppos+1;  
% mu_i     = [0 1 14]; mu_i_pos = ppos;   parnm=char(parnm,'$\mu_{i}$');     ppos = ppos+1;  
% mu_ys    = [0 1 14]; mu_ys_pos = ppos;  parnm=char(parnm,'$\mu_{y^*}$');   ppos = ppos+1;  
% mu_pis   = [0 1 14]; mu_pis_pos = ppos; parnm=char(parnm,'$\mu_{\pi^*}$'); ppos = ppos+1;  
% mu_is    = [0 1 14]; mu_is_pos = ppos;  parnm=char(parnm,'$\mu_{i^*}$');  

% Measurement equation components - errors
% ppos = ppos+1;
% R_y     = [0.1 1 13]; R_y_pos = ppos;   parnm=char(parnm,'$\R_{y}$');     ppos = ppos+1;
% R_c     = [0.1 1 13]; R_c_pos = ppos;   parnm=char(parnm,'$\R_{c}$');     ppos = ppos+1;  
% R_pi    = [0.1 1 13]; R_pi_pos = ppos;  parnm=char(parnm,'$\R_{\pi}$');   ppos = ppos+1;  
% R_i     = [0.1 1 13]; R_i_pos = ppos;   parnm=char(parnm,'$\R_{i}$');     ppos = ppos+1;  
% R_ys    = [0.1 1 13]; R_ys_pos = ppos;  parnm=char(parnm,'$\R_{y^*}$');   ppos = ppos+1;   
% R_pis   = [0.1 1 13]; R_pis_pos = ppos; parnm=char(parnm,'$\R_{\pi^*}$'); ppos = ppos+1;    
% R_is    = [0.1 1 13]; R_is_pos = ppos;  parnm=char(parnm,'$\R_{i^*}$');


% Creating the information matrix
for ii = 1:nst
    info_cell{ii} = zeros(ppos,3);
    info_cell{ii}(p11_pos,:) = p11;     % 
    info_cell{ii}(p22_pos,:) = p22;     % 
    if nst == 4
    info_cell{ii}(q11_pos,:) = q11;     % 
    info_cell{ii}(q22_pos,:) = q22;     % 
    end
    info_cell{ii}(beta_pos,:) = beta;   % 
    info_cell{ii}(phi_pos,:) = phi;     %
    info_cell{ii}(thetaH_pos,:) = thetaH; %
    info_cell{ii}(thetaF_pos,:) = thetaF; %  
    info_cell{ii}(alpha_pos,:) = alpha; %     
    info_cell{ii}(sigma_pos,:) = sigma; %
    info_cell{ii}(eta_pos,:) = eta;     % 
    info_cell{ii}(deltaH_pos,:) = deltaH; %
    info_cell{ii}(deltaF_pos,:) = deltaF; % 
    info_cell{ii}(ksi_pos,:) = ksi; % 

    info_cell{ii}(rho_a_pos,:) = rho_a;   % 
    info_cell{ii}(rho_muF_pos,:) = rho_muF; % 
    info_cell{ii}(rho_muH_pos,:) = rho_muH; % 
    info_cell{ii}(rho_nu_pos,:) = rho_nu; % 
    info_cell{ii}(rho_drp_pos,:) = rho_drp; % 
    info_cell{ii}(c_ystar_1_pos,:) = c_ystar_1; % 
    info_cell{ii}(c_pistar_2_pos,:) = c_pistar_2; % 
    info_cell{ii}(c_istar_3_pos,:) = c_istar_3; % 

    info_cell{ii}(sig_a_pos,:) = sig_a;      %   
    info_cell{ii}(sig_muF_pos,:) = sig_muF;    % 
    info_cell{ii}(sig_muH_pos,:) = sig_muH;    % 
    info_cell{ii}(sig_drp_pos,:) = sig_drp;    % 
    info_cell{ii}(sig_nu_pos,:) = sig_nu;    % 
    info_cell{ii}(sig_ystar_pos,:) = sig_ystar;  % 
    info_cell{ii}(sig_pistar_pos,:) = sig_pistar;% 
    info_cell{ii}(sig_istar_pos,:) = sig_istar;  % 
    
    if isempty(mu_y_pos)~=1;    info_cell{ii}(mu_y_pos,:) = mu_y;       end
    if isempty(mu_c_pos)~=1;    info_cell{ii}(mu_c_pos,:) = mu_c;       end 
    if isempty(mu_pi_pos)~=1;   info_cell{ii}(mu_pi_pos,:) = mu_pi;     end        
    if isempty(mu_i_pos)~=1;    info_cell{ii}(mu_i_pos,:) = mu_i;       end
    if isempty(mu_ys_pos)~=1;   info_cell{ii}(mu_ys_pos,:) = mu_ys;     end    
    if isempty(mu_pis_pos)~=1;  info_cell{ii}(mu_pis_pos,:) = mu_pis;   end
    if isempty(mu_is_pos)~=1;   info_cell{ii}(mu_is_pos,:) = mu_is;     end
    
    if isempty(R_y_pos)~=1;     info_cell{ii}(R_y_pos,:) = R_y;         end
    if isempty(R_c_pos)~=1;     info_cell{ii}(R_c_pos,:) = R_c;         end
    if isempty(R_pi_pos)~=1;    info_cell{ii}(R_pi_pos,:) = R_pi;       end
    if isempty(R_i_pos)~=1;     info_cell{ii}(R_i_pos,:) = R_i;         end
    if isempty(R_ys_pos)~=1;    info_cell{ii}(R_ys_pos,:) = R_ys;       end
    if isempty(R_pis_pos)~=1;   info_cell{ii}(R_pis_pos,:) = R_pis;     end
    if isempty(R_is_pos)~=1;    info_cell{ii}(R_is_pos,:) = R_is;       end
end

PS = Prob_extract(info_cell);
np = length(info_cell{1});
ndxPM = [find(info_cell{1}(:,3)==11); find(info_cell{1}(:,3)==12); find(info_cell{1}(:,3)==13); find(info_cell{1}(:,3)==14)];


%% Markov Switching Parameters
PM_vec=(1:np)';             
ndxSwitch{1} = setdiff(PM_vec,ndxPM);

% Case 1: No switch
% if nst == 1
%     info_cell{1}(p11_pos,3) = info_cell{1}(p11_pos,3)+10; % Do not forget, that in a no-switch case, the probabilities should be constant (not maximized over) and equal to both.
%     info_cell{1}(p22_pos,3) = info_cell{1}(p22_pos,3)+10;
% end

if nst == 2
% State 2: High Risk Premium Volatility
sig_drp2   = [2 1 3]; 
ndxSwitch{2} = [sig_drp_pos];
info_cell{2}(ndxSwitch{2},:) = [sig_drp2];

% % State 2: High debt elasticity coefficient
% ksi2    = [0.01 0.01 2]; 
% ndxSwitch{2} = [ksi_pos];
% info_cell{2}(ndxSwitch{2},:) = [ksi2];

% % State 2: High Risk and debt Volatility
% sig_drp2   = [0.8 1 3]; 
% ksi2    = [0.01 0.01 2]; 
% ndxSwitch{2} = [sig_drp_pos; ksi_pos];
% info_cell{2}(ndxSwitch{2},:) = [sig_drp2; ksi2];

% % State 2: All shocks switch
% sig_muF2   = [1 1 3];  
% sig_muH2   = [1 1 3];    
% sig_a2     = [1 1 3];   
% sig_nu2    = [1 1 3];   
% sig_drp2   = [0.8 1 3]; 
% ndxSwitch{2} = [sig_muF_pos; sig_muH_pos; sig_a_pos; sig_nu_pos; sig_drp_pos];
% info_cell{2}(ndxSwitch{2},:) = [sig_muF2; sig_muH2; sig_a2; sig_nu2; sig_drp2];

end

if nst==4
% State 3: High Sigma
% ndxSwitch{3}=[];
sigma2 = [4 1 2];
ndxSwitch{3} = [sigma_pos];
info_cell{3}(ndxSwitch{3},:) = [sigma2];

% State 4: High Both
% ndxSwitch{4}=[];
ndxSwitch{4} = [ndxSwitch{2}; ndxSwitch{3}];
info_cell{4}(ndxSwitch{2},:) = info_cell{2}(ndxSwitch{2},:);
info_cell{4}(ndxSwitch{3},:) = info_cell{3}(ndxSwitch{3},:);
end


%% Initialization of cells

for ii = 1:nst
    check_cell{ii} = zeros(np,1);
    check_cell{ii}(ndxSwitch{ii}) = 1;
    theta_prior{ii} = info_cell{ii}(:,1);
    prior_std_cell{ii} = info_cell{ii}(:,2);
    prior_type_cell{ii} = info_cell{ii}(:,3);
end
check_cell{1} = ones(np,1); % to make sure that all are evaluated in MS_repar for state 1
dist_name = distribution_name(prior_type_cell{1});
dist_bounds = distribution_bounds(prior_type_cell{1});

Rm_cell = ParameterBounds(info_cell);

disp_prior = zeros(np,nst);
for ii = 1:nst
    disp_prior(:,ii) = theta_prior{ii};
end
disp(' ');
disp('Switching coefficients');
disp([parnm(ndxSwitch{end},:) num2str(disp_prior(ndxSwitch{end},:))]);

ndxLam_c{1,1} = (1:length(ndxSwitch{1}))';
for ii = 2:nst-indep
    ndxLam_c{ii,1} = (ndxLam_c{ii-1,1}(end)+1:ndxLam_c{ii-1,1}(end)+length(ndxSwitch{ii}))'; %Indexing cell for the lambda vector            
end
PM_theta_vec = theta_prior{1}(ndxPM); % A vector with the non-reparametrized Point Mass values

%% Estimation
[OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_prior);
disp(Problems)
if nst ~= 1
    [likv_in, Problems.Like, pr_tt_in,pr_tl_in] = MS_Likelihood_Upd(yy, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, PS);
else
    [likv_in]=dsge_kf1(yy,OmegaK,GammaK,H,R_mat,Q_cell{1});
end
disp(' ');
disp('Likelihood:');
disp(likv_in);

if Step < 1
    break
end

%% Posterior Mode
for ii= 1:nst
    theta_prior{ii}=theta_prior{ii};
end
[lambda0_cell,lnjac,lnprior] = MS_repar(theta_prior,Rm_cell,0,prior_type_cell);
rp = length(cell2mat(ndxLam_c));
lambda_vec = zeros(rp,1);
insigma_vec = zeros(rp,1);  
lowBounds_vec = zeros(rp,1);                                                                     
upBounds_vec = zeros(rp,1); 
Rm_low_vec = zeros(rp,1); 
Rm_up_vec = zeros(rp,1); 

for ii = 1:length(ndxLam_c)
    lambda_vec(ndxLam_c{ii})=lambda0_cell{ii}(ndxSwitch{ii});
    insigma_vec(ndxLam_c{ii})=3.*prior_std_cell{ii}(ndxSwitch{ii});
    lowBounds_vec(ndxLam_c{ii})=dist_bounds{ii}(ndxSwitch{ii},1);
    upBounds_vec(ndxLam_c{ii})=dist_bounds{ii}(ndxSwitch{ii},2);
    Rm_low_vec(ndxLam_c{ii})=Rm_cell{ii}(ndxSwitch{ii},1);
    Rm_up_vec(ndxLam_c{ii})=Rm_cell{ii}(ndxSwitch{ii},2);
end

parnmdol_vec = parnm(ndxSwitch{1},:);
dist_typed_vec = dist_name(ndxSwitch{1},:);
for ii=2:nst-indep
    parnmdol_vec = char(parnmdol_vec, parnm(ndxSwitch{ii},:));
    dist_typed_vec = char(dist_typed_vec, dist_name(ndxSwitch{ii},:));
end
for is = 1:rp
    parnm_vec(is,:) = strrep(parnmdol_vec(is,:), '$', ''); 
    dist_type_vec(is,:) = strrep(dist_typed_vec(is,:), '$', ''); 
end


PM_lambda_vec = lambda0_cell{1}(ndxPM); % A vector with the reparametrized Point Mass values
[Like] = MS_Posterior_Upd(lambda_vec, yy, Rm_cell, prior_type_cell,PM_lambda_vec,ndxLam_c);
disp(Like)
% % break
sig   = 1;                                  %The step size
opts.SigmaMax = 5;                          %The maximal value for sigma
opts.MaxIter = 3000;                        %The maximum number of iterations
opts.PopSize = 25;                          %The population size
opts.VerboseModulo = 10;                    %Display results after every 10'th iteration
opts.TolFun = 1e-16;                        %Function tolerance
opts.TolX   = 1e-06;                        %Tolerance in the parameters
opts.Plotting = 'off';                      %Dislpay plotting or not
opts.Saving  =  'on';                       %Saving results 
opts.SaveFileName = 'CMAES_run_data.mat';    %Results are saved to this file
initial_vec = lambda_vec;
% initial_vec(sig_drp_pos-length(ndxPM)) = lambda_vec(end);
% initial_vec(end) = lambda_vec(sig_drp_pos-length(ndxPM));

res = cmaes_dsge(@MS_Posterior_Upd, initial_vec, sig, insigma_vec,opts,...
    yy,Rm_cell, prior_type_cell,PM_lambda_vec,ndxLam_c); 



%% Mode Estimation Results
% load second_result30.mat

% theta_mode_cell=theta_prior;
lambda_mode_cell=lambda0_cell;
for ii = 1:length(ndxLam_c)
    lambda_mode_cell{ii}(ndxSwitch{1})=res(ndxLam_c{1});
    lambda_mode_cell{ii}(ndxSwitch{ii})=res(ndxLam_c{ii});
end
if nst == 4
    lambda_mode_cell{4}(ndxSwitch{1})=res(ndxLam_c{1});
    lambda_mode_cell{4}(ndxSwitch{4})=[lambda_mode_cell{2}(ndxSwitch{2}); lambda_mode_cell{3}(ndxSwitch{3})];
end

[theta_mode,lnjac_km1,lnprior_km1] = MS_repar(lambda_mode_cell,Rm_cell,1,prior_type_cell);
lnprior_km1 = lnprior_km1 - lnjac_km1;

[OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_mode);
PS_m = Prob_extract(theta_mode);
if nst ~= 1
    [likv_km1, Problems.Like, pr_tt0M, pr_tl0M] = MS_Likelihood_Upd(yy, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, PS_m);
else
    [likv_km1, Problems.Like] = dsge_kf1(yy,OmegaK,GammaK,H,R_mat,Q_cell{1});
end
lnpost_km1 = likv_km1 + lnprior_km1;

[disp_mode disp_modef] = disp_results(theta_mode,parnm,np,1);


%% Probabilities Graph
if nst~= 1
    if nst==4
        pmodeT(:,1) = (pr_tt0M(:,1)+pr_tt0M(:,3)); pmodeL(:,1) = (pr_tl0M(:,1)+pr_tl0M(:,3));
        pmodeT(:,2) = (pr_tt0M(:,2)+pr_tt0M(:,4)); pmodeL(:,2) = (pr_tl0M(:,2)+pr_tl0M(:,4));
        pmodeT(:,3) = (pr_tt0M(:,1)+pr_tt0M(:,2)); pmodeL(:,3) = (pr_tl0M(:,1)+pr_tl0M(:,2));
        pmodeT(:,4) = (pr_tt0M(:,4)+pr_tt0M(:,3)); pmodeL(:,4) = (pr_tl0M(:,4)+pr_tl0M(:,3));
    else
        pmodeT = pr_tt0M;
        pmodeL = pr_tl0M;
    end
    pmode_sm = zeros(size(pr_tt0M)); 
    pmode_Nsm = zeros(size(pr_tt0M));

    for ii = 1:nst
        pmode_sm(:,ii) = pmodeT(:,ii);
        figure
        subplot(2,1,1)
        area(time,pmode_sm(:,ii))
        title('Probability at the mode');
        axis([min(time) max(time+0.25) 0 1.01])
        kline=time*zeros;
        subplot(2,1,2)
        plot(time,yy(:,1), time,kline,'k',time,yy(:,2),time,yy(:,3));
        xlim([min(time) max(time)]);
    end
end % if nst~=1

disp(' ');

%% Saving the simulation results
if Asave == 1 
    File = strcat(filename,'.m');
    Time=strcat('nst_',num2str(nst),'__',num2str(fix(clock)))
    mkdir(Sub,Time);
    copyfile(File,strcat(Sub,'/',Time));
    copyfile(strcat(Sub,'/','MS_Solve.m'),strcat(Sub,'/',Time));
    diary('Simulation.txt');  
    disp('Estimated Parameters:');
    disp(disp_modef);
    diary off
    movefile('Simulation.txt',strcat(Sub,'/',Time));
    movefile('CMAES_run_data.mat',strcat(Sub,'/',Time));
    save Step1.mat;
    movefile('Step1.mat',strcat(Sub,'/',Time));
end
if Step < 2
    break
end

%% Calculating the Hessian
% close all
thetamode_vec=zeros(size(res,1),1);
for ii = 1:length(ndxLam_c)
    thetamode_vec(ndxLam_c{ii})=theta_mode{ii}(ndxSwitch{ii});
end
draw_km1 = thetamode_vec;
[Like] = MS_Posterior_Mode(thetamode_vec, yy, Rm_cell, prior_type_cell,PM_theta_vec,ndxLam_c);

disp(Like);
Sigma = nhess(@MS_Posterior_Mode,thetamode_vec,yy, Rm_cell, prior_type_cell,PM_theta_vec,ndxLam_c);
InvSigma = Sigma\eye(length(Sigma));

if Asave == 1;
    save Step2.mat
    movefile('Step2.mat',strcat(Sub,'/',Time));
end


if Step < 3
    break
end

%% Creating LaTex Tables
%{
addpath('C:\Blagov\Matlab\matrix2latex')
m = [theta_prior{1} theta_mean_cell{1} theta_mean_cell{2} theta_mean_cell{3} theta_mean_cell{4}];
M=num2cell(m);
columnLabels = {' & Dist.', 'Prior Mean','State 1', 'State 2', 'State 3', 'State 4'};
rowLabels = cellstr(parnm)'; 
Mean_Table = [cellstr(dist_name), M]
matrix2latex(Mean_Table, 'mean_table.tex','rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.2f')
movefile('mean_table.tex','../Latex/');
%}
%{
addpath('C:\Blagov\Matlab\matrix2latex')
m = [theta_init{1} theta_mode_fix{1} theta_mode{1}];
M=num2cell(m);
columnLabels = {' & Dist.', 'Prior Mean','--','State 1', 'State 2'};
rowLabels = cellstr(parnm)'; 
Mode_Table = [cellstr(dist_name), M]
matrix2latex(Mode_Table, 'mode_table.tex','rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.2f')
movefile('mode_table.tex','../Latex/');
%}

%{
set(gcf, 'PaperSize', [9.25 7.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 9.25 7.5]);

set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [9.25 7.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 9.25 7.5]);
% print(gcf, '-depsc2', 'modeprob.eps');
%}