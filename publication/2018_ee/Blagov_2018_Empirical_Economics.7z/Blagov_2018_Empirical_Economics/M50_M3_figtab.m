clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');


%%%%%%%%%%%%%%%%%%% Linear i, original October model with MHM %%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
% simDir = 'nst_2__2012    11    13    16     1     2  ksi and sigma HP';
simDir = 'nst_2__2012    11    12    17    58    58 all shocks';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
ident = char('M3');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


%% Probabilities plot
load('detrending.mat','data_in')

[pmode_sm, pmode_Nsm] = MS_smooth(pr_tt0M,pr_tl0M,PS_m);

current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 16 8]);
subplot(2,1,2)
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',1.5);
% axis tight
% set(gca, ...
%   'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
%   'Fontsize'    , FS  ,...  
%   'Box'         , 'off'     , ...
%   'TickDir'     , 'out'     , ...
%   'TickLength'  , [.02 .02] , ...  
%   'XMinorTick'  , 'on'      , ...
%   'YMinorTick'  , 'on'      );
beauty
% tith = title(strcat('TALIBOR and EURIBOR'));
% set(tith,'Fontname','Garamond','FontSize',FS);
hLegend= legend('TALIBOR','EURIBOR');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','NOrtheast');
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));

subplot(2,1,1)

sStateProb = 1-pmode_sm(:,2);sStateProb(2) = 0.4999;
tpind = sStateProb>0.5; 
% plot(time,tprob.*~tpind,time,tprob.*tpind)
area(time,sStateProb.*~tpind,'Facecolor',[0 143 213]/255)
hold all
area(time,sStateProb.*tpind,'Facecolor',[180 39 40]/255)
hold off
axis tight
tith = title(strcat('Estimated probability of the second regime'));
set(tith,'Fontname','Garamond','FontSize',FS);
set(gca, ...
  'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...   
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
hLegend= legend('Regime 1','Regime 2');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','South');
set(gcf,'Color',[1 1 1]);

pathname = '..\..\Paper_Final\Graphs_Final\';
name =  strcat('P1_M',Sub,'_',ident,'_prob_mode');
print(current_fig, '-dmeta', name);
movefile(strcat(name,'.emf'),pathname)  

%% IRF plot M4 VS M2
% Graph settings
Fsize=12;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontName', 'Garamond');
set(0,'defaultTextFontName', 'Garamond');
set(0,'defaultAxesFontSize', Fsize);
fName = 'Garamond';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);
ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=10; %12
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontName', 'Garamond');
set(0,'defaultTextFontName', 'Garamond');
set(0,'defaultAxesFontSize', Fsize);
fName = 'Garamond';

[~,~,~,~,~,~,~,~,M2_IRF_unsorted,M2_Variables_sct] = MS_Solve(theta_mean_cell);
M2_VarNames = M2_Variables_sct.VarNames;
M2_Xvar_sct = M2_Variables_sct.Xvar_sct;
M2_Nvar_sct = M2_Variables_sct.Nvar_sct;
Xvar = M2_Variables_sct.xvar;
Nvar = M2_Variables_sct.nvar;

M2_IRF = cell(nst,1); 
for st = 1:nst 
    M2_IRF{st} = zeros(size(M2_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M2_IRF{st}(:,ii) = M2_IRF_unsorted{st}(:,jj);
            if kk == 8
                M2_IRF{st}(:,ii) = M2_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M2_IRF{st}(find(M2_IRF{st}>-10^(-15) & M2_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Then M3
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11    12    17    58    58 all shocks';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
ident = char('M3');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';

[~,~,~,~,~,~,~,~,M3_IRF_unsorted,M3_Variables_sct] = MS_Solve(theta_mean_cell);
M3_VarNames = M3_Variables_sct.VarNames;
M3_Xvar_sct = M3_Variables_sct.Xvar_sct;
M3_Nvar_sct = M3_Variables_sct.Nvar_sct;
Xvar = M3_Variables_sct.xvar;
Nvar = M3_Variables_sct.nvar;

M3_IRF = cell(nst,1); 
for st = 1:nst 
    M3_IRF{st} = zeros(size(M3_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M3_IRF{st}(:,ii) = M3_IRF_unsorted{st}(:,jj);
            if kk == 8
                M3_IRF{st}(:,ii) = M3_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M3_IRF{st}(find(M3_IRF{st}>-10^(-15) & M3_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


jj = 0;
st = 1;
varlist = [M3_Nvar_sct.y M3_Nvar_sct.i M3_Nvar_sct.d M3_Nvar_sct.ist];

sh = M3_Xvar_sct.phi;   %1:12,M1_IRF{st}(1:12,ii+Nvar*(sh-1)),
current_fig = figure;
for ii = 1:11
    if ii ~= 6 & ii ~=9
    jj = jj+1;
    subplot(3,3,jj)
    plot(1:12,M3_IRF{st}(1:12,ii+Nvar*(sh-1)),1:12,M3_IRF{st+1}(1:12,ii+Nvar*(sh-1)),1:12,M2_IRF{st+1}(1:12,ii+Nvar*(sh-1)),'-.',1:12,M2_IRF{st}(1:12,ii+Nvar*(sh-1)),'--','Linewidth',1.5);
    title(deblank(M3_VarNames(ii,:)),'Fontsize',Fsize,'Fontname',fName);  
    beauty
%     kline = zeros(1,20);
%     hold on
%     plot(1:12, kline,'k','Linewidth',1);
%     hold off
%     xlim([1, 12]);
    end  
end
set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [21 14]); %32 24
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 21 14]);
name =  strcat('M',Sub,'_',ident,'_IRF_phi_presnt.eps');
print(current_fig, '-depsc', name);
% print(current_fig, '-dmeta', name);
pathname = '..\Text Rev 2015\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 20.5 10]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')



rmpath(simDir_full);
rmpath(Sub);
rmpath('NewData');