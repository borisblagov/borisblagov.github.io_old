clear variables
clear global
clc

print_table = 2; % If 0, prints only M1 and M2; if 1, prints only the full table; 2: both

% if print_table == 0
%     full_table = 0;
% elseif print_table == 1;
    full_table = 1; % If one, it will print the full robustness table
% else 


%% M1 %%
Sub = '50';
addpath(Sub);
simDir = 'nst_1__2012    11    21    12    12    40 M1 HP';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run2.mat','MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')

S.MH_phigh_cell = vec2cell(MH_phigh_vec, theta_mode, ndxLam_c);
S.MH_plow_cell = vec2cell(MH_plow_vec, theta_mode, ndxLam_c);
S.likv_mn = likv_mn;
S.lnprior_mn = lnprior_mn;
S.parnm_vec = parnm_vec;
S.ndxSwitch = ndxSwitch;
S.theta_mean_cell = theta_mean_cell;
S.mDens_log = mDens_log;
S.mDens_vec = mDens_vec;

M1 = S;


rmpath(simDir_full)
rmpath(Sub)

%% M2 %%
Sub = '50';
addpath(Sub)
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat','MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')

S.MH_phigh_cell = vec2cell(MH_phigh_vec, theta_mode, ndxLam_c);
S.MH_plow_cell = vec2cell(MH_plow_vec, theta_mode, ndxLam_c);
S.likv_mn = likv_mn;
S.lnprior_mn = lnprior_mn;
S.parnm_vec = parnm_vec;
S.ndxSwitch = ndxSwitch;
S.theta_mean_cell = theta_mean_cell;
S.mDens_log = mDens_log;
S.mDens_vec = mDens_vec;

M2 = S;

clear('MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior')

rmpath(simDir_full)
rmpath(Sub)

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if full_table == 1;
%% Robustness Check 1 Equal Prior for states

Sub = '50';
addpath(Sub);
% simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir = 'nst_2__2012    11    19    19     9     7 all shocks HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat','MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')

S.MH_phigh_cell = vec2cell(MH_phigh_vec, theta_mode, ndxLam_c);
S.MH_plow_cell = vec2cell(MH_plow_vec, theta_mode, ndxLam_c);
S.likv_mn = likv_mn;
S.lnprior_mn = lnprior_mn;
S.parnm_vec = parnm_vec;
S.ndxSwitch = ndxSwitch;
S.theta_mean_cell = theta_mean_cell;
S.hst = 1; % identification which is the high state, chosen here. 1 is for low, 2 is for high
S.lst = 2;
S.mDens_log = mDens_log;
S.mDens_vec = mDens_vec;

M3 = S;

clear('MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior')

rmpath(simDir_full)
rmpath(Sub)

%% Robustness Check 2 Change in Ksi and Sigma

Sub = '50';
addpath(Sub);
simDir = 'nst_2__2012    11    13    16     1     2  ksi and sigma HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat','MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')

S.MH_phigh_cell = vec2cell(MH_phigh_vec, theta_mode, ndxLam_c);
S.MH_plow_cell = vec2cell(MH_plow_vec, theta_mode, ndxLam_c);
S.likv_mn = likv_mn;
S.lnprior_mn = lnprior_mn;
S.parnm_vec = parnm_vec;
S.ndxSwitch = ndxSwitch;
S.theta_mean_cell = theta_mean_cell;
S.hst = 2; % identification which is the high state, chosen here. 1 is for low, 2 is for high
S.lst = 1;
S.mDens_log = mDens_log;
S.mDens_vec = mDens_vec;

M4 = S;

clear('MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior')

rmpath(simDir_full)
rmpath(Sub)


%% Robustness Check 3 No detrending

Sub = '53';
addpath(Sub);
simDir = 'nst_2__2013     2     6    15    29    32'; % Raw  interest rate
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat','MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')

S.MH_phigh_cell = vec2cell(MH_phigh_vec, theta_mode, ndxLam_c);
S.MH_plow_cell = vec2cell(MH_plow_vec, theta_mode, ndxLam_c);
S.likv_mn = likv_mn;
S.lnprior_mn = lnprior_mn;
S.parnm_vec = parnm_vec;
S.ndxSwitch = ndxSwitch;
S.theta_mean_cell = theta_mean_cell;
S.hst = 1; % identification which is the high state, chosen here. 1 is for low, 2 is for high
S.lst = 2;
S.mDens_log = mDens_log;
S.mDens_vec = mDens_vec;

M5 = S;

clear('MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior')

rmpath(simDir_full)
rmpath(Sub)



%% Robustness Check 4+2 Three states

Sub = '60';
addpath(strcat('..\Matlab_60\',Sub));
simDir = 'nst_3__2016     4    24    23     4    12'; % Raw  interest rate
simDir_full = strcat('..\Matlab_60\',Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat','MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')

S.MH_phigh_cell = vec2cell(MH_phigh_vec, theta_mode, ndxLam_c);
S.MH_plow_cell = vec2cell(MH_plow_vec, theta_mode, ndxLam_c);
S.likv_mn = likv_mn;
S.lnprior_mn = lnprior_mn;
S.parnm_vec = parnm_vec;
S.ndxSwitch = ndxSwitch;
S.theta_mean_cell = theta_mean_cell;
S.hst = 1; % identification which is the high state, chosen here. 1 is for low, 2 is for high
S.lst = 2;
S.mDens_log = mDens_log;
S.mDens_vec = mDens_vec;

for kk = 1:3
    S.MH_phigh_cell{kk} =  S.MH_phigh_cell{kk}([1 2 5:end]);         % the three states have more params. Remove p23 and p33
    S.MH_plow_cell{kk} =  S.MH_plow_cell{kk}([1 2 5:end]); 
    S.theta_mean_cell{kk} =  S.theta_mean_cell{kk}([1 2 5:end]); 
end

M6 = S;

clear('MH_mean_vec','MH_plow_vec','MH_phigh_vec','theta_mode','ndxLam_c',...
    'mDens_log', 'mDens_vec','likv_mn','lnprior_mn','nst', 'ndxSwitch','parnm_vec','theta_mean_cell','theta_prior')

rmpath(simDir_full)
rmpath(strcat('..\Matlab_60\',Sub))

end

%% Creating LaTex Tables
Sub = '50';
addpath(Sub)
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat','parnm_vec','theta_mean_cell','theta_prior','parnm','dist_name')
parnm(17,:)='$\rho_{\phi}$   ';
parnm(25,:)='$\sigma_{\phi}$ ';

m = [theta_prior{1}...
     M1.theta_mean_cell{1}...
     M2.theta_mean_cell{1} M2.theta_mean_cell{2}];%...
if full_table == 1
    m = [m ... %      
        M3.theta_mean_cell{M3.lst} M3.theta_mean_cell{M3.hst}...
        M4.theta_mean_cell{M4.lst} M4.theta_mean_cell{M4.hst}...%      M5.theta_mean_cell{2} M5.theta_mean_cell{1}];
        M5.theta_mean_cell{M5.lst} M5.theta_mean_cell{M5.hst}...
        M6.theta_mean_cell{M6.lst} M6.theta_mean_cell{M6.hst}...
        ];
end

ndxStd = zeros(size(m,1),size(m,2)+1);% use (size(m,1),size(m,2)+1) for a text column
% ndxStd = zeros(size(m,1),size(m,2));  % use (size(m,1),size(m,2)+1) for a text column

no=3;   % where do the confidence intervals start (which column onwards)
ndxStd(M1.ndxSwitch{1},no)=ones(size(M1.ndxSwitch{1})); no=no+1;
ndxStd(M2.ndxSwitch{1},no)=ones(size(M2.ndxSwitch{1})); no=no+1;
ndxStd(M2.ndxSwitch{2},no)=ones(size(M2.ndxSwitch{2})); no=no+1;
if full_table == 1
ndxStd(M3.ndxSwitch{1},no)=ones(size(M3.ndxSwitch{1})); no=no+1;
ndxStd(M3.ndxSwitch{2},no)=ones(size(M3.ndxSwitch{2})); no=no+1;

ndxStd(M4.ndxSwitch{1},no)=ones(size(M4.ndxSwitch{1})); no=no+1;
ndxStd(M4.ndxSwitch{2},no)=ones(size(M4.ndxSwitch{2})); no=no+1;

ndxStd(M5.ndxSwitch{M5.hst},no)=ones(size(M5.ndxSwitch{M4.hst})); no=no+1;
ndxStd(M5.ndxSwitch{M5.lst},no)=ones(size(M5.ndxSwitch{M5.lst})); no=no+1;

ndxStd(M5.ndxSwitch{M6.hst},no)=ones(size(M5.ndxSwitch{M6.hst})); no=no+1;
ndxStd(M5.ndxSwitch{M6.lst},no)=ones(size(M5.ndxSwitch{M6.lst})); no=no+1;

% ndxStd(M4.ndxSwitch{1},no)=ones(size(M4.ndxSwitch{1})); no=no+1;    % This is for M5 but there the ndxSwtich is different!
% ndxStd(M4.ndxSwitch{2},no)=ones(size(M4.ndxSwitch{2})); no=no+1;
% ndxStd(18,7)=0; ndxStd(19,7)=0; ndxStd(20,7)=0;
% ndxStd(26,7)=0; ndxStd(27,7)=0; ndxStd(28,7)=0;
end

M = num2cell(m);
M_l=num2cell([zeros(size(m,1),1)...
              zeros(size(m,1),1)...
              M1.MH_plow_cell{1}...
              M2.MH_plow_cell{1} M2.MH_plow_cell{2}]);
if full_table == 1
    M_l = [M_l num2cell([...
              M3.MH_plow_cell{M3.lst} M3.MH_plow_cell{M3.hst}...
              M4.MH_plow_cell{M4.lst} M4.MH_plow_cell{M4.hst}...
              M5.MH_plow_cell{M5.lst} M5.MH_plow_cell{M5.hst}...
              M6.MH_plow_cell{M6.lst} M6.MH_plow_cell{M6.hst}...
            ])];
end
M_h=num2cell([zeros(size(m,1),1)...
              zeros(size(m,1),1)...
              M1.MH_phigh_cell{1}...
              M2.MH_phigh_cell{1} M2.MH_phigh_cell{2}]);
if full_table == 1
    M_h = [M_h num2cell([...
              M3.MH_phigh_cell{M3.lst} M3.MH_phigh_cell{M3.hst}...
              M4.MH_phigh_cell{M4.lst} M4.MH_phigh_cell{M4.hst}...
              M5.MH_phigh_cell{M5.lst} M5.MH_phigh_cell{M5.hst}...
              M6.MH_phigh_cell{M6.lst} M6.MH_phigh_cell{M6.hst}...
                ])];
end
M_ndxStd = num2cell(ndxStd);
CI.M_l = [M_l; num2cell(zeros(1,size(M_l,2)))];
CI.M_h = [M_h; num2cell(zeros(1,size(M_l,2)))];
CI.M_ndxStd = [M_ndxStd; num2cell(zeros(1,size(M_l,2)))];

columnLabels = {'Distribution'...
                'Prior Mean'...
                '$\mathcal{M}_1$'...
                '$\mathcal{M}_2$'};
if full_table == 1
    columnLabels{end+1} = '$\mathcal{M}_3$';
%     columnLabels{end+1} = '$\mathcal{M}_3: S_t=2$';
    columnLabels{end+1} = '$\mathcal{M}_4$';
%     columnLabels{end+1} = '$\mathcal{M}_4: S_t=2$';
     columnLabels{end+1} = '$\mathcal{M}_5$';
%      columnLabels{end+1} = '$\mathcal{M}_5: S_t=2$';
     columnLabels{end+1} = '$\mathcal{M}_6$';
%      columnLabels{end+1} = '$\mathcal{M}_6: S_t=2$';
end

rowLabels = cellstr(parnm)'; 
Mean_Table = [cellstr(dist_name), M];

% Mean_Table{1,1} = '---';
% Mean_Table{2,1} = '---';
% Mean_Table{1,1}='$Beta$';
% Mean_Table{2,1}='$Beta$';
model_ident = 5; % the first column which has to be filled with ---
for ii=1:size(ndxStd,1)    
    if ndxStd(ii,model_ident) == 0
        Mean_Table{ii,model_ident} = '---';
    end
    if model_ident<size(ndxStd,2)
        if ndxStd(ii,model_ident+2) == 0
            Mean_Table{ii,model_ident+2} = '---';
        end
    end
    if model_ident+2<size(ndxStd,2)
        if ndxStd(ii,model_ident+4) == 0
            Mean_Table{ii,model_ident+4} = '---';
        end
    end
    if model_ident+4<size(ndxStd,2)
        if ndxStd(ii,model_ident+6) == 0
            Mean_Table{ii,model_ident+6} = '---';
        end
    end
end
Mean_Table{1,3}='---';  % For blanking out the probabilities in M1 which are constant
Mean_Table{2,3}='---';  % For blanking out the probabilities in M1 which are constant
% Mean_Table{20,7}='---';
% Mean_Table{26,7}='---';
% Mean_Table{27,7}='---';
% Mean_Table{28,7}='---';

% Adding the marginal densities
Mean_Table{end+1,3}=M1.mDens_log;
Mean_Table{end,4}=num2str(M2.mDens_log);
if full_table == 1
    Mean_Table{end,6}=num2str(M3.mDens_log);
    Mean_Table{end,8}=num2str(M4.mDens_log);
    Mean_Table{end,10}=num2str(M5.mDens_log);
end
rowLabels{end+1} = '$\mathbb{M}$:';

Mean_Table = Mean_Table(:,[1:4 6 8 10 12]);
CI.M_l = CI.M_l(:,[1:4 6 8 10 12]);
CI.M_h = CI.M_h(:,[1:4 6 8 10 12]);
CI.M_ndxStd =  CI.M_ndxStd(:,[1:4 6 8 10 12]);


disp(Mean_Table);
if full_table ~= 1
    name = strcat('M',Sub,'_Models_Table_pub.tex');
    matrix2latex_ext(Mean_Table, name,CI,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
else
    name = strcat('Tab5a.tex');
    matrix2latex_ext_lscape(Mean_Table, name,CI,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
end
% movefile(name,'../Tables');

% rmpath(simDir_full);
% rmpath(Sub);
%}


