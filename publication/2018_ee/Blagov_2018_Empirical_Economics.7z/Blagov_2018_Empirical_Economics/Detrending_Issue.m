clc
close all
clear
clear global

addpath('NewData');

load detrending.mat

% iEst=figure
% kk=2;
% plot(time,data_in(:,kk),time,data_tr_hp(:,kk),'--',time,data_tr_lin(:,kk),'-.','Linewidth',1.4)
% set(iEst, 'PaperUnits', 'centimeters');
% set(iEst, 'PaperSize', [20 20/3]);
% set(iEst, 'PaperPositionMode', 'manual');
% set(iEst, 'PaperPosition', [0 0 20 20/3]);
% print(iEst, '-depsc2', 'iEst.eps');
% movefile('iEst.eps','../Graphs')
% 
% iEu=figure
% kk=1;
% plot(time,data_in(:,kk),time,data_tr_hp(:,kk),'--',time,data_tr_lin(:,kk),'-.','Linewidth',1.4)
% set(iEu, 'PaperUnits', 'centimeters');
% set(iEu, 'PaperSize', [20 20/3]);
% set(iEu, 'PaperPositionMode', 'manual');
% set(iEu, 'PaperPosition', [0 0 20 20/3]);
% print(iEu, '-depsc2', 'iEu.eps');
% movefile('iEu.eps','../Graphs')

iEst=figure
kk=2;
plot(time,data_in(:,kk),time,data_in(:,1),time,data_tr_hp(:,kk),'--',time,data_tr_lin(:,kk),'-.','Linewidth',1.4)
xlim([1996.0 2011.75])
set(gca,'FontSize',20)
set(iEst, 'PaperUnits', 'inches');
set(iEst, 'PaperSize', [13.5 4.5]);
set(iEst, 'PaperPositionMode', 'manual');
set(iEst, 'PaperPosition', [0 0 13.5 4.5]);
print(iEst, '-depsc2', 'iEst.eps');
movefile('iEst.eps','../Graphs')

%%
FS = 10;
current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 16 4]);
plot(time,data_in(:,kk),time,data_in(:,1),time,data_tr_hp(:,kk),'--',time,data_tr_lin(:,kk),'-.','Linewidth',1.5)
beauty
hLegend= legend('TALIBOR','EURIBOR','HP Trend','Linear Trend');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','NOrtheast');

temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));

name = 'P1_iEst.eps';
pathname = '..\..\Paper_Final\Graphs_Final\';
export_fig(strcat(pathname,name),'-pdf', '-nocrop')

