clc
clear global
clear variables
close all

Sub = '50';
addpath(Sub);
% simDir = 'nst_2__2012    11     2    13     3     2 HP';
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i'; % Oct. draft ver but with corrected vprobvec
% simDir = 'nst_2__2012    11     2    13     3     2 HP'; % Oct. draft ver M4 (HP) but with corrected vprobvec
% simDir = 'nst_2__2012    11    13    11    43    32 Ksi and sigma'; % Ksi and sigma change linear interest
% simDir = 'nst_2__2012    11    19    19     9     7 all shocks HP';
% simDir = 'nst_2__2012    11    30    11    58    47 Demeaned Data';  % Demeaned interest rate
% simDir = 'nst_2__2012    11    30    17    25    48 Raw Interest'; % Raw  interest rate
simDir = 'ADD_HERE_THE_SUBFOLDER';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load Step2.mat
filename = mfilename;
[likv_km1, theta_km1_cell, Problems] = SolvEst(thetamode_vec,theta_mode,ndxLam_c,yy);
% draw_km1 = mvnrnd(draw_km1,0.05*InvSigma)';
% [likv_km1, theta_km1_cell, Problems] = SolvEst(draw_km1,theta_mode,ndxLam_c,yy);
[lambda_km1_cell,lnjac_km1,lnprior_km1] = MS_repar(theta_km1_cell,Rm_cell,0,prior_type_cell);

% lnpost_km1 = likv_km1+lnprior_km1+lnjac_km1;
lnpost_km1 = likv_km1+lnprior_km1;
%% Initializing Metropolis-Hastings Algorithm
init = 'mode';
Nsim = 10000;   % Total number of draws that you want in the end (after thinning and burn in). Must divisible by 10
dsave = 30;     % Thinning - save every 'dsave' draw
batches = 4;    % Number of batches (in how many chunks should it be estimated (to avoid memory problems))
Burn = 1/4;     % Brn in proportion (this is a proportion from Nsim*dsave)
ch = 0.2;       % Scaling constant for the inverse of the Hessian
disp_freq = 30; % How often to display information about the MH algorithm
run_n = 1;      % Simulation number - every run is saved and this variable gives it a unique name (otherwise it overrides)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% do not change anything below this line %%%%%%%%%%%%%%%%%%%%%%%%%%
Nsim_n = Nsim*(1+Burn)*dsave;   % Total number of simulations
Nsim_b = Nsim_n/batches;        % Number of simulations per batch
Nsim1_b = Nsim_b/dsave;         % Number of draws saved (thinned)
Nsim2_b = Nsim1_b*batches;      % Total number of draws saved (thinned)
ndxBurn = floor(Burn*Nsim);     % The last element of the burn-in phase
nskip = 1;                      % Do not change this value
fcc_prob = 0;                   % to save every violation of the forward condition
det_prob = 0;                   % to save every indeterminant solution
lik_prob = 0;                   % to save every problem with the likelihood
bounds_prob = 0;                % to save every problem with the bounds 
movingratio = 0;                % to calculate the overall moving ratio
theta_con = zeros(rp,1);
toc_b = 0;

%% Metropolis Hastings itself #1
MetropolisHastings

%% Patching together the batches (and burning in if needed)
MH_Nsim_mat=zeros(rp,Nsim2_b);
MH_Nsim_LogPost_mat=zeros(Nsim2_b,1);
move_burn = 0;     
for iq = 1:batches
    iter_load = strcat('MH',num2str(run_n),'_',init,num2str(iq));
    load(iter_load)
    MH_Nsim_mat(:,1 + (iq-1)*Nsim1_b : Nsim1_b + (iq-1)*Nsim1_b) = MH_draw_mat;    
    MH_Nsim_LogPost_mat(1 + (iq-1)*Nsim1_b : Nsim1_b + (iq-1)*Nsim1_b,:) = MH_lik_mat;    
    move_burn = move_burn + MR;
end
MH_mat = MH_Nsim_mat(:,ndxBurn+1:end);
MH_LogPost_mat = MH_Nsim_LogPost_mat(ndxBurn+1:end,:);

%% Convergence and Moments
MH_mean_vec = mean(MH_mat,2);           % Mean (vector)
MH_std_vec = std(MH_mat,0,2);           % Standard deviation (vector)
MH_plow_vec = prctile(MH_mat,5,2);      % The  5-th percentile (vector)   
MH_phigh_vec = prctile(MH_mat,95,2);    % The 95-th percentile (vector)
MH_rmean_mat = rmean(MH_mat,2);         % Recursive mean (matrix)

[mDens_log mDens_vec] = mhm(MH_mat,MH_LogPost_mat,0.9,100);
% disp(num2str([move_burn fcc_prob det_prob lik_prob bounds_prob]))
% disp(' ');

[likv_mn, theta_mean_cell, Problems_mn] = SolvEst(MH_mean_vec,theta_mode,ndxLam_c,yy);
[lambda_mn_cell,lnjac_mn,lnprior_mn] = MS_repar(theta_mean_cell,Rm_cell,0,prior_type_cell);
[disp_mean disp_meanf] = disp_results(theta_mean_cell,parnm,np,0);

Coda_str = strcat('Coda_run',num2str(run_n),'.txt');
diary(Coda_str);   
disp('  '); disp('Estimated coefficients'); disp('  ');
disp('                  Mean         5%           95%');
disp([parnm_vec num2str([MH_mean_vec MH_plow_vec MH_phigh_vec])]);
disp('  '); disp('  '); disp('Lieklihood value at the posterior mode:');
disp(['L = ' num2str(likv_mn+lnprior_mn)]);
coda(MH_mat',parnm_vec)
diary off
movefile(Coda_str,simDir_full);
Step3_str = strcat('Step3_run',num2str(run_n),'.mat');
save(Step3_str)
movefile(Step3_str,simDir_full);


%% Convergence plots
LW = 1.9;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Trace Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
trace_fig = figure;
for ikl=1:rp    
subplot(ceil(rp/4),4,ikl); 
hold on
plot(MH_mat(ikl,:),'LineStyle','-','Color','b');   
title(parnmdol_vec(ikl,:),'Interpreter','latex');
hold off
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Recursive Means plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
recmean_fig = figure;
for ik=1:rp    
    subplot(ceil(rp/4),4,ik); 
    plot(MH_rmean_mat(ik,:),'LineStyle','-','Color','b','LineWidth',1.5);   
    hold on
    plot(xlim,[MH_mean_vec(ik,:) MH_mean_vec(ik,:)],'k--','Linewidth',1.5);
    axis tight
    title(parnmdol_vec(ik,:),'Interpreter','latex');
    hold off
end


%%%%%%%%%%%%%%%%%%%%%%%%% Posterior and Prior Densities %%%%%%%%%%%%%%%%%%%%%%%%%
distrib_fig = figure;
for ip = 1:rp
    [int dens domain] = pltdens(MH_mat(ip,:)');
    subplot(ceil(rp/4),4,ip);
    Ydomain = domain;
    if strcmpi(dist_type_vec(ip,:),'IGamma')==1
        Y = inv_gampdf(Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
        Y = Y.*(Ydomain>0.01);
    else
        Y = pdf(dist_type_vec(ip,:),Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
        if strcmpi(dist_type_vec(ip,:),'Beta')
            dens=dens.*(domain<1);
            Y = Y.*(Ydomain<1);
        end
    end
    plot(domain,dens,'Color','b','LineWidth',LW); hold on;
    plot([mean(MH_mat(ip,:)) mean(MH_mat(ip,:))], [0 max([dens])],'LineStyle','-','Color','k','LineWidth',1.5);    
    axis tight
    plot(Ydomain,Y,'LineStyle','--','Color',[0 0.6 0],'LineWidth',LW);
    hold off
    title(parnmdol_vec(ip,:),'Interpreter','latex');
end     % plotting the densities

hgsave(trace_fig,strcat('MH',num2str(run_n),'_trace.fig'));
hgsave(recmean_fig,strcat('MH',num2str(run_n),'_recmean.fig'));
hgsave(distrib_fig,strcat('MH',num2str(run_n),'_distrib.fig'));
movefile(strcat('MH',num2str(run_n),'_trace.fig'),simDir_full);
movefile(strcat('MH',num2str(run_n),'_recmean.fig'),simDir_full);
movefile(strcat('MH',num2str(run_n),'_distrib.fig'),simDir_full);
