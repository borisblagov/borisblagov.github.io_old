clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');


%%%%%%%%%%%%%%%%%%% Linear i, original October model with MHM %%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);
ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=20;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');

%% Probabilities plot
% load('detrending.mat','data_in')
% % 
% % set(0,'defaultAxesFontName', 'Times');
% % set(0,'defaultTextFontName', 'Times');
% FS = 10;
% % 
% [pmode_sm, pmode_Nsm] = MS_smooth(pr_tt0M,pr_tl0M,PS_m);
% prob_fig = figure;
% current_fig = prob_fig;
% subplot(2,1,1)
% plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',1.5);
% beauty
% % xlim([1996.0 2011.75])
% % set(gca,'FontSize',Fsize)
% subplot(2,1,2)
% plot(time,1-pmode_sm(:,1));
% beauty
% hold on
% plot(time,1-pmode_Nsm(:,1),'Color',[44 160 44]/255,'LineStyle','--','Linewidth',1.5);
% hold off
% % xlim([1996.0 2011.75])
% name =  strcat('M',Sub,'_',ident,'_prob_mode.eps');
% 
% pathname = '..\..\Paper_Final\Graphs_Final\';
% set(current_fig, 'Units','centimeters','Position', [10 10 16 8]);
% export_fig(strcat(pathname,name),'-pdf', '-nocrop')

%% Probabilities area plot
load('detrending.mat','data_in')
% 
% set(0,'defaultAxesFontName', 'Times');
% set(0,'defaultTextFontName', 'Times');
FS = 10;
FNAME = 'Times';
pathname = '..\Text Rev 2016\';
[pmode_sm, pmode_Nsm] = MS_smooth(pr_tt0M,pr_tl0M,PS_m);
%%

current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 16 8]);
subplot(2,1,2)
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',1.5);
% axis tight
% set(gca, ...
%   'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
%   'Fontsize'    , FS  ,...  
%   'Box'         , 'off'     , ...
%   'TickDir'     , 'out'     , ...
%   'TickLength'  , [.02 .02] , ...  
%   'XMinorTick'  , 'on'      , ...
%   'YMinorTick'  , 'on'      );
beauty
% tith = title(strcat('TALIBOR and EURIBOR'));
% set(tith,'Fontname','Times','FontSize',FS);
hLegend= legend('TALIBOR','EURIBOR');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','NOrtheast');
% temp_ylabels=str2num(get(gca,'YTickLabel'));
% set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));

subplot(2,1,1)

sStateProb = 1-pmode_sm(:,1);sStateProb(2) = 0.4999;
tpind = sStateProb>0.5; 
% plot(time,tprob.*~tpind,time,tprob.*tpind)
area(time,sStateProb.*~tpind,'Facecolor',[100 143 213]/255)
hold all
area(time,sStateProb.*tpind,'Facecolor',[180 39 40]/255)
hold off
axis tight
% tith = title(strcat('Estimated probability of the second regime'));
% set(tith,'Fontname','Times','FontSize',FS);
set(gca, ...
  'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...   
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
hLegend= legend('Regime 1','Regime 2');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','South');
set(gcf,'Color',[1 1 1]);

name =  strcat('Fig3');
export_fig(strcat(pathname,name),'-eps', '-nocrop')




%% Convergence plots
LW = 1.4;

%%%%%%%%%%%%%%%%%%%%%%%%% Posterior and Prior Densities %%%%%%%%%%%%%%%%%%%%%%%%% 
%
distrib_fig = figure;
current_fig = distrib_fig;
for ip = 1:rp
    [int dens domain] = pltdens(MH_mat(ip,:)');
    subplot(7,4,ip);
    Ydomain = domain;
    if strcmpi(dist_type_vec(ip,:),'IGamma')==1
        Y = inv_gampdf(Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
        Y = Y.*(Ydomain>0.01);
    else
        Y = pdf(dist_type_vec(ip,:),Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
        if strcmpi(dist_type_vec(ip,:),'Beta')
            dens=dens.*(domain<1);
            Y = Y.*(Ydomain<1);
        end
    end
%     plot(domain,dens,'Color','b','LineWidth',LW); hold on;
    plot(domain,dens,'Color','k','LineWidth',LW); hold all;
    plot([mean(MH_mat(ip,:)) mean(MH_mat(ip,:))], [0 max([dens])],'LineStyle','-','Color','k','LineWidth',1.5);    
    axis tight
%     plot(Ydomain,Y,'LineStyle','--','Color',[0 0.6 0],'LineWidth',LW);
    plot(Ydomain,Y,'k','LineStyle','--','LineWidth',LW);
    hold off
    title(parnmdol_vec(ip,:),'Interpreter','latex','Fontsize',10);
%     set(gca,'FontSize',10)
%     beauty
if ~exist('FS')
    FS = 8;
end    
 set(gca, ...
  'Fontname'    , 'Times'  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...  
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
end
set(gcf,'Color',[1 1 1])
  % plotting the densities

set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [22.5 30]);
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 22.5 30]);
name =  strcat('Fig13.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
%}

% pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 16]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Recursive Means plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
recmean_fig = figure;
current_fig = recmean_fig;
for ik=1:rp    
    subplot(7,4,ik); 
    plot(MH_rmean_mat(ik,:),'k','LineWidth',LW);
    hold on
    plot(xlim,[MH_mean_vec(ik,:) MH_mean_vec(ik,:)],'k','LineWidth',LW-0.4);
    axis tight
    title(parnmdol_vec(ik,:),'Interpreter','latex','Fontsize',10);
    hold off

if ~exist('FS')
    FS = 8;
end    
 set(gca, ...
  'Fontname'    , 'Times'  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...  
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
end
set(gcf,'Color',[1 1 1])

set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [22.5 30]);
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 22.5 30]);
name =  strcat('Fig14.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');


% pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 16]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')

%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Trace Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
trace_fig = figure;
current_fig = trace_fig;
for ikl=1:rp    
subplot(7,4,ikl); 
hold on
plot(MH_mat(ikl,:),'LineStyle','-','Color','k');   
title(parnmdol_vec(ikl,:),'Interpreter','latex','Fontsize',10);
% set(gca, 'Fontsize', 8);
hold off
if ~exist('FS')
    FS = 8;
end    
 set(gca, ...
  'Fontname'    , 'Times'  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...  
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
end
set(gcf,'Color',[1 1 1])

set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [22.5 30]);
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 22.5 30]);
name =  strcat('Fig15.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
%}
% pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 16]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Coda statistics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Coda = coda(MH_mat',parnm_vec)

%% Autocorrelation tables
lag1    = zeros(rp,1);
lag5    = zeros(rp,1);
lag10   = zeros(rp,1);
lag50   = zeros(rp,1);
irl     = zeros(rp,1);
thin   = zeros(rp,1);
nburn   = zeros(rp,1);
ntot    = zeros(rp,1);
nminim    = zeros(rp,1);

vertical = char('|');
for iq = 1:rp
    lag1(iq,1)  = Coda(1,iq).auto1;
    lag5(iq,1)  = Coda(1,iq).auto5;
    lag10(iq,1) = Coda(1,iq).auto10;
    lag50(iq,1) = Coda(1,iq).auto50;
    irl(iq,1)   = Coda(1,iq).irl;
    thin(iq,1)  = Coda(1,iq).kthin;
    nburn(iq,1) = Coda(1,iq).nburn;
    ntot(iq,1)  = Coda(1,iq).n;
    nminim(iq,1)  = Coda(1,iq).nmin; 
    if iq < rp
    vertical = [char('|'); vertical];
    end
end


m = [lag1 lag5 lag10 lag50 thin nburn ntot nminim irl];
Mean_Table = [num2cell(m(:,1:4))];
columnLabels = {'Lag 1.', 'Lag 5', 'Lag 10','Lag 50'};
rowLabels = cellstr(parnmdol_vec)'; 
name = strcat('M',Sub,'_',ident,'_autocorr.tex');
matrix2latex(Mean_Table, name,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
copyfile(name,simDir_full);
movefile(name,'../Tables');

Mean_Table = [num2cell(m(:,5:9))];
columnLabels = {'Thin', 'Burn', 'Total(N)', '(Nmin)','I-stat'};
rowLabels = cellstr(parnmdol_vec)'; 
name = strcat('M',Sub,'_',ident,'_raferty.tex');
matrix2latex(Mean_Table, name,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
copyfile(name,simDir_full);
movefile(name,'../Tables');


rmpath(simDir_full);
rmpath(Sub);
rmpath('NewData');