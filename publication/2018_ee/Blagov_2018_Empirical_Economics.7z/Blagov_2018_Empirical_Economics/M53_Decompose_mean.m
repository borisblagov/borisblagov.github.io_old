clc
clear global
clear variables
close all

Sub = '53';
addpath(Sub);
simDir = 'nst_2__2013     2     6    15    29    32';

simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load Step3_run1.mat
filename = mfilename;
mident = 'M2';

Fsize=14;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultAxesFontSize', Fsize);
set(0,'defaultTextFontName', 'Times');

% theta_vec = datasample(MH_mat,1,2);
% theta_cell=theta_prior;
% for ii = 1:length(ndxLam_c)
%     theta_cell{ii}(ndxSwitch{1})  = theta_vec(ndxLam_c{1});
%     theta_cell{ii}(ndxSwitch{ii}) = theta_vec(ndxLam_c{ii});
% end
% if nst == 4
%     theta_cell{4}(ndxSwitch{1}) = theta_vec(ndxLam_c{1});
%     theta_cell{4}(ndxSwitch{4}) = [theta_cell{2}(ndxSwitch{2}); theta_cell{3}(ndxSwitch{3})];
% end
theta_cell = theta_mean_cell;
[OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems,termK,IRS,Variables_sct,CR_cell] = MS_Solve(theta_cell);

% theta=theta_mean_cell{1};

VD_cell =cell(2,1);
VD_area = cell(2,1);
VD_table = cell(2,1);
for ii = 1:nst
    Aw = OmegaK{ii};
    Bw = GammaK{ii};
    Bx = [Bw(4:5,:); Bw(8:9,:); Bw(11:14,:)];
    By = Bx(:,4:end);
    R = CR_cell{ii}(4:end,4:end);
    Ax = [Aw(:,4) Aw(:,5) Aw(:,8) Aw(:,9) Aw(:,11) Aw(:,12) Aw(:,13) Aw(:,14)]; % building s_t = [q,s,piH,piF,d,y*,pi*,i*,muF,muH,a,nu,phi]'
    Ay = [Ax(4:5,:); Ax(8:9,:); Ax(11:14,:)];
    Az = [Ay By; zeros(5,8) R];
    Bz = [Bx(:,1:3) zeros(8,5); zeros(5,3) eye(5)];
    Uw = [Ax Bw(:,4:end)];
    Ux = [Uw(1:3,:); Uw(6:7,:); Uw(10,:)];

    Cz = [Ux(1:3,:); Ux(5,:)];

    F=Az;
    Q=Bz*Q_cell{ii}*Bz';

    qr = 41;
    VD = zeros(qr,4);
    SigmaX = zeros(size(Q));
    for k=1:qr-1
        SigmaX = SigmaX + (F^(k-1))*Q*(F^(k-1))';%+(F^2)*Q*(F^2)';
        SigmaD = Cz*SigmaX*Cz';
        VD(k,:) = diag(SigmaD)';
    end
    SigmaX_k_vec = (eye(size(Q(:),1)) - kron(F,F))\Q(:);
    SigmaX_k = reshape(SigmaX_k_vec,size(F));
    SigmaD_k = Cz*SigmaX_k*Cz';
    VD(k+1,:) = diag(SigmaD_k)';

    VD_cell{ii} = zeros(qr,4,8);

    for r=1:8
        Sigma_sh = zeros(size(Q));
        Qa = Bz(:,r)*Q_cell{ii}(r,r)*Bz(:,r)';
        for k=1:qr-1
            Sigma_sh = Sigma_sh + (F^(k-1))*Qa*(F'^(k-1));%+(F^2)*Q*(F^2)';
            SigmaD_sh = Cz*Sigma_sh*Cz';
            VD_cell{ii}(k,:,r) = diag(SigmaD_sh)'./VD(k,:)*100;
        end
        SigmaX_k_sh_vec = (eye(size(Q(:),1)) - kron(F,F))\Qa(:);
        SigmaX_sh_k = reshape(SigmaX_k_sh_vec,size(F));
        SigmaD_sh_k = Cz*SigmaX_sh_k*Cz';
        VD_cell{ii}(k+1,:,r) = diag(SigmaD_sh_k)'./VD(k+1,:)*100;
    end
    tit = [' c  ';' y  ';' i  ';' \pi'];
    VD_area{ii} = zeros(qr,8,4);
    for zz = 1:4
        for z=1:qr
        VD_area{ii}(z,:,zz) = [VD_cell{ii}(z,zz,1) VD_cell{ii}(z,zz,2) VD_cell{ii}(z,zz,3)  VD_cell{ii}(z,zz,4)...
             VD_cell{ii}(z,zz,5) VD_cell{ii}(z,zz,6) VD_cell{ii}(z,zz,7) VD_cell{ii}(z,zz,8)];
        end
        current_fig = figure;
        area(VD_area{ii}(1:12,:,zz))
        axis tight
        hl = legend('\epsilon_{y^*}','\epsilon_{\pi^*}','\epsilon_{i^*}','\epsilon_{\mu_F}','\epsilon_{\mu_H}','\epsilon_a','\epsilon_{\nu}','\epsilon_{\phi}');
        set(hl,'FontSize',Fsize);
        %title(strcat('Variance Decomposition for',tit(zz,:)),'FontSize',Fsize)
        set(current_fig, 'PaperUnits', 'centimeters');
        set(current_fig, 'PaperSize', [14 10]);
        set(current_fig, 'PaperPositionMode', 'manual');
        set(current_fig, 'PaperPosition', [0 0 14 10]);
        name =  strcat('M',Sub,'_',mident,'_',num2str(ii),tit(zz,2),'_VD.eps');
        if zz==4; name =  strcat('M',Sub,'_',mident,'_',num2str(ii),tit(zz,3),'_VD.eps'); end;
%         print(current_fig, '-depsc', name);
%         copyfile(name,simDir_full);
%         movefile(name,'../Graphs');
    end
%     VD_table{ii} = zeros(7,8,4);
%     for r = 1:4
%         VD_table{ii}(1,:,r)  = VD_area{ii}(1,:,r);
%         VD_table{ii}(2,:,r)  = VD_area{ii}(4,:,r);
%         VD_table{ii}(3,:,r)  = VD_area{ii}(8,:,r);
%         VD_table{ii}(4,:,r)  = VD_area{ii}(12,:,r);
%         VD_table{ii}(5,:,r)  = VD_area{ii}(20,:,r);
%         VD_table{ii}(6,:,r)  = VD_area{ii}(40,:,r);
%         VD_table{ii}(7,:,r)  = VD_area{ii}(41,:,r);
%         M = VD_table{ii}(:,:,r);
%         rowLabels = {'1', '4', '8', '12', '20', '40', '$\infty$'};
%         name =  strcat('M',Sub,'_',mident,'_',num2str(ii),tit(r,2),'_VD_table.tex');
%         if r==4; name =  strcat('M',Sub,'_',mident,'_',num2str(ii),tit(r,3),'_VD_table.tex'); end;
%         columnLabels = {'$\varepsilon_{y^*}$','$\varepsilon_{\pi^*}$','$\varepsilon_{i^*}$','$\varepsilon_{\mu_F}$','$\varepsilon_{\mu_H}$','$\varepsilon_a$','$\varepsilon_{\nu}$','$\varepsilon_{\phi}$'};
%         matrix2latex(M, name, 'rowLabels', rowLabels, 'columnLabels', columnLabels, 'alignment', 'c', 'format', '%-6.2f');
%         movefile(name,'../Tables');
%     end
end



