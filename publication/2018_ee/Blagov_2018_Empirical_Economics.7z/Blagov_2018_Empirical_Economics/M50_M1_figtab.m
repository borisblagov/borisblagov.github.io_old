clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');


%%%%%%%%%%%%%%%%%% HP interest, nst1 with MHM %%%%%%%%%%%%%%%%%%%%%%%%%
simDir = 'nst_1__2012    11    21    12    12    40 M1 HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
ident = char('M1');
parnmdol_vec(13,:)='$\rho_{\phi}$   ';
parnmdol_vec(21,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=20;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontName', 'Garamond');
set(0,'defaultTextFontName', 'Garamond');

%% Convergence plots
LW = 1.4;

%%%%%%%%%%%%%%%%%%%%%%%%% Posterior and Prior Densities %%%%%%%%%%%%%%%%%%%%%%%%% 
%
distrib_fig = figure;
current_fig = distrib_fig;
for ip = 1:rp
    [int dens domain] = pltdens(MH_mat(ip,:)');
    subplot(7,4,ip);
    Ydomain = domain;
    if strcmpi(dist_type_vec(ip,:),'IGamma')==1
        Y = inv_gampdf(Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
        Y = Y.*(Ydomain>0.01);
    else
        Y = pdf(dist_type_vec(ip,:),Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
        if strcmpi(dist_type_vec(ip,:),'Beta')
            dens=dens.*(domain<1);
            Y = Y.*(Ydomain<1);
        end
    end
%     plot(domain,dens,'Color','b','LineWidth',LW); hold on;
    plot(domain,dens,'Color','k','LineWidth',LW); hold all;
    plot([mean(MH_mat(ip,:)) mean(MH_mat(ip,:))], [0 max([dens])],'LineStyle','-','Color','k','LineWidth',1.5);    
    axis tight
    plot(Ydomain,Y,'LineStyle','--','Color',[0 0.6 0],'LineWidth',LW);
    plot(Ydomain,Y,'k','LineStyle','--','LineWidth',LW);
    hold off
    title(parnmdol_vec(ip,:),'Interpreter','latex','Fontsize',12);
%     set(gca,'FontSize',10)
if ~exist('FS')
    FS = 8;
end    
 set(gca, ...
  'Fontname'    , 'Garamond'  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...  
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
end
set(gcf,'Color',[1 1 1])


set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [22.5 30]);
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 22.5 30]);
name =  strcat('M',Sub,'_',ident,'_distrib.eps');
% print(current_fig, '-depsc', name);
% print(current_fig, '-dmeta', name);
pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 16]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')

% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Recursive Means plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
recmean_fig = figure;
current_fig = recmean_fig;
for ik=1:rp    
    subplot(7,4,ik); 
    plot(MH_rmean_mat(ik,:),'k','LineWidth',LW);
    hold on
    plot(xlim,[MH_mean_vec(ik,:) MH_mean_vec(ik,:)],'k','LineWidth',LW-0.4);
    axis tight
    title(parnmdol_vec(ik,:),'Interpreter','latex','Fontsize',12);
    hold off

if ~exist('FS')
    FS = 8;
end    
 set(gca, ...
  'Fontname'    , 'Garamond'  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...  
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
end
set(gcf,'Color',[1 1 1])


set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [22.5 30]);
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 22.5 30]);
name =  strcat('M',Sub,'_',ident,'_recmean.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
%}
pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 16]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Trace Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
trace_fig = figure;
current_fig = trace_fig;
for ikl=1:rp    
subplot(7,4,ikl); 
hold on
plot(MH_mat(ikl,:),'LineStyle','-','Color','k');   
title(parnmdol_vec(ikl,:),'Interpreter','latex','Fontsize',12);
% set(gca, 'Fontsize', 8);
hold off
if ~exist('FS')
    FS = 8;
end    
 set(gca, ...
  'Fontname'    , 'Garamond'  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...  
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
end
set(gcf,'Color',[1 1 1])


set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [22.5 30]);
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 22.5 30]);
name =  strcat('M',Sub,'_',ident,'_trace.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
%}

pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 16]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')
break
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Coda statistics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Coda = coda(MH_mat',parnm_vec)

%% Autocorrelation tables
lag1    = zeros(rp,1);
lag5    = zeros(rp,1);
lag10   = zeros(rp,1);
lag50   = zeros(rp,1);
irl     = zeros(rp,1);
thin   = zeros(rp,1);
nburn   = zeros(rp,1);
ntot    = zeros(rp,1);
nminim    = zeros(rp,1);

vertical = char('|');
for iq = 1:rp
    lag1(iq,1)  = Coda(1,iq).auto1;
    lag5(iq,1)  = Coda(1,iq).auto5;
    lag10(iq,1) = Coda(1,iq).auto10;
    lag50(iq,1) = Coda(1,iq).auto50;
    irl(iq,1)   = Coda(1,iq).irl;
    thin(iq,1)  = Coda(1,iq).kthin;
    nburn(iq,1) = Coda(1,iq).nburn;
    ntot(iq,1)  = Coda(1,iq).n;
    nminim(iq,1)  = Coda(1,iq).nmin; 
    if iq < rp
    vertical = [char('|'); vertical];
    end
end


m = [lag1 lag5 lag10 lag50 thin nburn ntot nminim irl];
Mean_Table = [num2cell(m(:,1:4))];
columnLabels = {'Lag 1.', 'Lag 5', 'Lag 10','Lag 50'};
rowLabels = cellstr(parnmdol_vec)'; 
name = strcat('M',Sub,'_',ident,'_autocorr.tex');
matrix2latex(Mean_Table, name,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
copyfile(name,simDir_full);
movefile(name,'../Tables');

Mean_Table = [num2cell(m(:,5:9))];
columnLabels = {'Thin', 'Burn', 'Total(N)', '(Nmin)','I-stat'};
rowLabels = cellstr(parnmdol_vec)'; 
name = strcat('M',Sub,'_',ident,'_raferty.tex');
matrix2latex(Mean_Table, name,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
copyfile(name,simDir_full);
movefile(name,'../Tables');


rmpath(simDir_full);
rmpath(Sub);
rmpath('NewData');

