This is the replication code for Blagov (2018) "Financial crises and time-varying risk premia in a small open economy: a Markov-switching DSGE model for Estonia." Empirical Economics, 54(3), pp 1017–1060.

The code is provided as is and is for research purposes. It has been last tested on Matlab 2019b and worked. The code started originally from codes of Gianni Amisano that were heavily modified by me. I am grateful that he had shared his, so that I can learn.


Note that this was my very first research article so the code is poorly optimized and takes forever (uses global variables which later I learned you should not do).

HOW TO USE:

The folder consists of many files here are the most important ones.
1. You should run Model_50.m first. You can choose there which version you want nst = 1,2 or 4 states. The default is the two-state MS-Model. 
 	- The code performs Maximum Likelihood to find the posterior mode for the start of the MH step. You should expect a lot of orange messages about invertibility, this is normal
 	- The code will then generate a subfolder in the folder "50" with the time it was done. For example the folder will be called "nst_2__2022     6    22    13     0    45" if you ran it on the 22.06.2022 at 13:45 with two states. This folder name is important, copy it!
	- Additionally in the folder you will get a copy of the file that you ran (for reference purposes).

2. Open Model_50_MH.m. This will run the main MH algorithm. Copy the folder name from step 1 in simDir (line 15). For example 
simDir = 'nst_2__2022     6    22    13     0    45';
 	- It takes several days on a good computer. In 2013 it was close to a week. 
	- Once it is done it will save the MH moments in that subfolder

3. You can use any of the other files to generate graphs with IRFs or tables, just remember to copy the simDir name at the top of the respective file. You might need to add Export_fig (included) for the export as .eps or the export_table.
