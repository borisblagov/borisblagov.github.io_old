clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');

%%% Graph for regimes is in M53_Posterior.m


%%%%%%%%%%%%%%%%%%% Linear i, original October model with MHM %%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11    13    16     1     2  ksi and sigma HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
ident = char('M4');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');

FNAME = 'Times';
pathname = '..\Text Rev 2016\';
FS = 10;
%% Probabilities plot
load('detrending.mat','data_in')

[pmode_sm, pmode_Nsm] = MS_smooth(pr_tt0M,pr_tl0M,PS_m);

current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 16 8]);
subplot(2,1,2)
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',1.5);
% axis tight
% set(gca, ...
%   'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
%   'Fontsize'    , FS  ,...  
%   'Box'         , 'off'     , ...
%   'TickDir'     , 'out'     , ...
%   'TickLength'  , [.02 .02] , ...  
%   'XMinorTick'  , 'on'      , ...
%   'YMinorTick'  , 'on'      );
beauty
% tith = title(strcat('TALIBOR and EURIBOR'));
% set(tith,'Fontname','Times','FontSize',FS);
hLegend= legend('TALIBOR','EURIBOR');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','NOrtheast');
% temp_ylabels=str2num(get(gca,'YTickLabel'));
% set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));

subplot(2,1,1)

sStateProb = 1-pmode_sm(:,1);sStateProb(2) = 0.4999;
tpind = sStateProb>0.5; 
% plot(time,tprob.*~tpind,time,tprob.*tpind)
area(time,sStateProb.*~tpind,'Facecolor',[0 143 213]/255)
hold all
area(time,sStateProb.*tpind,'Facecolor',[180 39 40]/255)
hold off
axis tight
% tith = title(strcat('Estimated probability of the second regime'));
% set(tith,'Fontname','Times','FontSize',FS);
set(gca, ...
  'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...   
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
hLegend= legend('Regime 1','Regime 2');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','South');
set(gcf,'Color',[1 1 1]);

name =  strcat('Fig15');
export_fig(strcat(pathname,name),'-eps', '-nocrop')

%% IRF plot M4 VS M2
% Graph settings
Fsize=12;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontSize', Fsize);
fName = 'Times';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);
ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=10; %12
set(0,'defaultAxesFontSize', Fsize);
fName = 'Times';

[~,~,~,~,~,~,~,~,M2_IRF_unsorted,M2_Variables_sct] = MS_Solve(theta_mean_cell);
M2_VarNames = M2_Variables_sct.VarNames;
M2_Xvar_sct = M2_Variables_sct.Xvar_sct;
M2_Nvar_sct = M2_Variables_sct.Nvar_sct;
Xvar = M2_Variables_sct.xvar;
Nvar = M2_Variables_sct.nvar;

M2_IRF = cell(nst,1); 
for st = 1:nst 
    M2_IRF{st} = zeros(size(M2_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M2_IRF{st}(:,ii) = M2_IRF_unsorted{st}(:,jj);
            if kk == 8
                M2_IRF{st}(:,ii) = M2_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M2_IRF{st}(find(M2_IRF{st}>-10^(-15) & M2_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Then M4
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11    13    16     1     2  ksi and sigma HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
ident = char('M4');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';

[~,~,~,~,~,~,~,~,M4_IRF_unsorted,M4_Variables_sct] = MS_Solve(theta_mean_cell);
M4_VarNames = M4_Variables_sct.VarNames;
M4_Xvar_sct = M4_Variables_sct.Xvar_sct;
M4_Nvar_sct = M4_Variables_sct.Nvar_sct;
Xvar = M4_Variables_sct.xvar;
Nvar = M4_Variables_sct.nvar;

M4_IRF = cell(nst,1); 
for st = 1:nst 
    M4_IRF{st} = zeros(size(M4_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M4_IRF{st}(:,ii) = M4_IRF_unsorted{st}(:,jj);
            if kk == 8
                M4_IRF{st}(:,ii) = M4_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M4_IRF{st}(find(M4_IRF{st}>-10^(-15) & M4_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


jj = 0;
st = 1;
varlist = [M4_Nvar_sct.y M4_Nvar_sct.i M4_Nvar_sct.d M4_Nvar_sct.ist];

sh = M4_Xvar_sct.phi;   %1:12,M1_IRF{st}(1:12,ii+Nvar*(sh-1)),
current_fig = figure;
for ii = 1:11
    if ii ~= 6 & ii ~=9
    jj = jj+1;
    subplot(3,3,jj)
    plot(1:12,M4_IRF{st}(1:12,ii+Nvar*(sh-1)),1:12,M4_IRF{st+1}(1:12,ii+Nvar*(sh-1)),':',1:12,M2_IRF{st+1}(1:12,ii+Nvar*(sh-1)),'-.',1:12,M2_IRF{st}(1:12,ii+Nvar*(sh-1)),'--','Linewidth',1.5);
    title(deblank(M4_VarNames(ii,:)),'Fontsize',Fsize,'Fontname',fName,'Fontweight','normal');  
    beauty
%     kline = zeros(1,20);
%     hold on
%     plot(1:12, kline,'k','Linewidth',1);
%     hold off
%     xlim([1, 12]);
    end  
end
set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [21 14]); %32 24
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 21 14]);
name =  strcat('Fig14');

set(current_fig, 'Units','centimeters','Position', [10 10 20.5 10]);
export_fig(strcat(pathname,name),'-eps', '-nocrop')

%% Interest rates plot
%{
load('detrending.mat','data_in')

interest_fig = figure;
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',2);
xlim([1996.0 2011.75])
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [13.5 4.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 13.5 4.5]);
print(interest_fig, '-depsc', 'interest_fig.eps');
movefile('interest_fig.eps','../Graphs');


%% GDP plot
gdp_ee_fig = figure;
plot(time,yy(:,1),'k','Linewidth',2);
hold on
plot(time,kline,'k')
hold off
xlim([1996.0 2011.75])
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [13.5 4.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 13.5 4.5]);
print(gdp_ee_fig, '-depsc', 'gdp_ee_fig.eps');
movefile('gdp_ee_fig.eps','../Graphs');
%}


%% Convergence plots
% LW = 1.4;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%% Posterior and Prior Densities %%%%%%%%%%%%%%%%%%%%%%%%% 
% %
% distrib_fig = figure;
% current_fig = distrib_fig;
% for ip = 1:rp
%     [int dens domain] = pltdens(MH_mat(ip,:)');
%     subplot(7,4,ip);
%     Ydomain = domain;
%     if strcmpi(dist_type_vec(ip,:),'IGamma')==1
%         Y = inv_gampdf(Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
%         Y = Y.*(Ydomain>0.01);
%     else
%         Y = pdf(dist_type_vec(ip,:),Ydomain,Rm_low_vec(ip),Rm_up_vec(ip));
%         if strcmpi(dist_type_vec(ip,:),'Beta')
%             dens=dens.*(domain<1);
%             Y = Y.*(Ydomain<1);
%         end
%     end
%     plot(domain,dens,'Color','b','LineWidth',LW); hold on;
%     plot([mean(MH_mat(ip,:)) mean(MH_mat(ip,:))], [0 max([dens])],'LineStyle','-','Color','k','LineWidth',1.5);    
%     axis tight
%     plot(Ydomain,Y,'LineStyle','--','Color',[0 0.6 0],'LineWidth',LW);
%     hold off
%     title(parnmdol_vec(ip,:),'Interpreter','latex','Fontsize',12);
%     set(gca,'FontSize',10)
% end     % plotting the densities
% 
% set(current_fig, 'PaperUnits', 'centimeters');
% set(current_fig, 'PaperSize', [22.5 30]);
% set(current_fig, 'PaperPositionMode', 'manual');
% set(current_fig, 'PaperPosition', [0 0 22.5 30]);
% name =  strcat('M',Sub,'_',ident,'_distrib.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
% %}
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%% Recursive Means plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %
% recmean_fig = figure;
% current_fig = recmean_fig;
% for ik=1:rp    
%     subplot(7,4,ik); 
%     plot(MH_rmean_mat(ik,:),'LineWidth',LW);
%     hold on
%     plot(xlim,[MH_mean_vec(ik,:) MH_mean_vec(ik,:)],'k','LineWidth',LW-0.4);
%     axis tight
%     title(parnmdol_vec(ik,:),'Interpreter','latex','Fontsize',12);
%     hold off
% end
% 
% set(current_fig, 'PaperUnits', 'centimeters');
% set(current_fig, 'PaperSize', [22.5 30]);
% set(current_fig, 'PaperPositionMode', 'manual');
% set(current_fig, 'PaperPosition', [0 0 22.5 30]);
% name =  strcat('M',Sub,'_',ident,'_recmean.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
% %}
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Trace Plots %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %
% trace_fig = figure;
% current_fig = trace_fig;
% for ikl=1:rp    
% subplot(7,4,ikl); 
% hold on
% plot(MH_mat(ikl,:),'LineStyle','-','Color','b');   
% title(parnmdol_vec(ikl,:),'Interpreter','latex','Fontsize',12);
% % set(gca, 'Fontsize', 8);
% hold off
% end
% set(current_fig, 'PaperUnits', 'centimeters');
% set(current_fig, 'PaperSize', [22.5 30]);
% set(current_fig, 'PaperPositionMode', 'manual');
% set(current_fig, 'PaperPosition', [0 0 22.5 30]);
% name =  strcat('M',Sub,'_',ident,'_trace.eps');
% print(current_fig, '-depsc', name);
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');
% %}
% 
% %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Coda statistics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Coda = coda(MH_mat',parnm_vec)
% 
% %% Autocorrelation tables
% lag1    = zeros(rp,1);
% lag5    = zeros(rp,1);
% lag10   = zeros(rp,1);
% lag50   = zeros(rp,1);
% irl     = zeros(rp,1);
% thin   = zeros(rp,1);
% nburn   = zeros(rp,1);
% ntot    = zeros(rp,1);
% nminim    = zeros(rp,1);
% 
% vertical = char('|');
% for iq = 1:rp
%     lag1(iq,1)  = Coda(1,iq).auto1;
%     lag5(iq,1)  = Coda(1,iq).auto5;
%     lag10(iq,1) = Coda(1,iq).auto10;
%     lag50(iq,1) = Coda(1,iq).auto50;
%     irl(iq,1)   = Coda(1,iq).irl;
%     thin(iq,1)  = Coda(1,iq).kthin;
%     nburn(iq,1) = Coda(1,iq).nburn;
%     ntot(iq,1)  = Coda(1,iq).n;
%     nminim(iq,1)  = Coda(1,iq).nmin; 
%     if iq < rp
%     vertical = [char('|'); vertical];
%     end
% end
% 
% 
% m = [lag1 lag5 lag10 lag50 thin nburn ntot nminim irl];
% Mean_Table = [num2cell(m(:,1:4))];
% columnLabels = {'Lag 1.', 'Lag 5', 'Lag 10','Lag 50'};
% rowLabels = cellstr(parnmdol_vec)'; 
% name = strcat('M',Sub,'_',ident,'_autocorr.tex');
% matrix2latex(Mean_Table, name,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
% copyfile(name,simDir_full);
% movefile(name,'../Tables');
% 
% Mean_Table = [num2cell(m(:,5:9))];
% columnLabels = {'Thin', 'Burn', 'Total(N)', '(Nmin)','I-stat'};
% rowLabels = cellstr(parnmdol_vec)'; 
% name = strcat('M',Sub,'_',ident,'_raferty.tex');
% matrix2latex(Mean_Table, name,'rowLabels',rowLabels,'columnLabels', columnLabels,'alignment', 'c', 'format', '%-6.3f')
% copyfile(name,simDir_full);
% movefile(name,'../Tables');


rmpath(simDir_full);
rmpath(Sub);
rmpath('NewData');