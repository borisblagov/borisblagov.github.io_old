function [M,V] = betastat_ves(A,B)
    M = A./(A+B);
    V = A.*B./ ((A+B+1).*((A.*B).^2) );
end