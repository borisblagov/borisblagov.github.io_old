 clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');

FNAME = 'Times';
pathname = '..\Text Rev 2016\';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% M1 %%
Sub = '50';
addpath(Sub);
simDir = 'nst_1__2012    11    21    12    12    40 M1 HP';
simDir_full = strcat(Sub,'\',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
% load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

% d_ee = d_ee(2:end);
ident = char('M1');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=12;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontSize', 12);


[~,~,~,~,~,~,~,~,M1_IRF_unsorted,M1_Variables_sct] = MS_Solve_nst1IRF(theta_mean_cell);
M1_VarNames = M1_Variables_sct.VarNames;
M1_Xvar_sct = M1_Variables_sct.Xvar_sct;
M1_Nvar_sct = M1_Variables_sct.Nvar_sct;
Xvar = M1_Variables_sct.xvar;
Nvar = M1_Variables_sct.nvar;
% nst=2
M1_IRF = cell(nst,1); 
for st = 1:nst 
    M1_IRF{st} = zeros(size(M1_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M1_IRF{st}(:,ii) = M1_IRF_unsorted{st}(:,jj);
            if kk == 8
                M1_IRF{st}(:,ii) = M1_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M1_IRF{st}(find(M1_IRF{st}>-10^(-15) & M1_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


jj = 0;
st = 1;
varlist = [M1_Nvar_sct.y M1_Nvar_sct.i M1_Nvar_sct.d M1_Nvar_sct.ist];

% sh = M1_Xvar_sct.phi;
% % current_fig = figure;
% for ii = 1:14
%     jj = jj+1;
%     subplot(4,4,jj)
%     plot(1:20,M1_IRF{st}(:,ii+Nvar*(sh-1)),'-.','Linewidth',1.5);
%     title(deblank(M1_VarNames(ii,:)),'Fontsize',Fsize);    
% end

% % set(current_fig, 'PaperUnits', 'centimeters');
% % set(current_fig, 'PaperSize', [30 30]);
% % set(current_fig, 'PaperPositionMode', 'manual');
% % set(current_fig, 'PaperPosition', [0 0 30 30]);
% % name =  strcat('M',Sub,'_',ident,'_IRF_phi.eps');
% % print(current_fig, '-depsc', name);
% % copyfile(name,simDir_full);
% % movefile(name,'../Graphs');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);
ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=10; %12
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontSize', Fsize);
fName = 'Times';

[~,~,~,~,~,~,~,~,M2_IRF_unsorted,M2_Variables_sct] = MS_Solve(theta_mean_cell);
M2_VarNames = M2_Variables_sct.VarNames;
M2_Xvar_sct = M2_Variables_sct.Xvar_sct;
M2_Nvar_sct = M2_Variables_sct.Nvar_sct;
Xvar = M2_Variables_sct.xvar;
Nvar = M2_Variables_sct.nvar;

M2_IRF = cell(nst,1); 
for st = 1:nst 
    M2_IRF{st} = zeros(size(M2_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M2_IRF{st}(:,ii) = M2_IRF_unsorted{st}(:,jj);
            if kk == 8
                M2_IRF{st}(:,ii) = M2_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M2_IRF{st}(find(M2_IRF{st}>-10^(-15) & M2_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


jj = 0;
st = 1;
varlist = [M2_Nvar_sct.y M2_Nvar_sct.i M2_Nvar_sct.d M2_Nvar_sct.ist];

sh = M2_Xvar_sct.phi;
current_fig = figure;
for ii = 1:11
    if ii ~= 6 & ii ~=9
    jj = jj+1;
    subplot(3,3,jj)
    plot(1:12,M2_IRF{st}(1:12,ii+Nvar*(sh-1)),'--',1:12,M2_IRF{st+1}(1:12,ii+Nvar*(sh-1)),'-.',1:12,M1_IRF{st}(1:12,ii+Nvar*(sh-1)),'Linewidth',1.5);
    title(deblank(M2_VarNames(ii,:)),'Fontsize',Fsize,'Fontname',fName,'Fontweight','normal');  
    beauty
%     kline = zeros(1,20);
%     hold on
%     plot(1:12, kline,'k','Linewidth',1);
%     hold off
%     xlim([1, 12]);
    end
end
% legend1 = legend('M2, state 1', 'M2, state 2', 'M1');
% set(legend1,'Position',[0.7 0 0.1 0.25]);

set(current_fig, 'PaperUnits', 'centimeters');
set(current_fig, 'PaperSize', [21 14]); %32 24
set(current_fig, 'PaperPositionMode', 'manual');
set(current_fig, 'PaperPosition', [0 0 21 14]);
name =  strcat('Fig4.eps');

set(current_fig, 'Units','centimeters','Position', [10 10 20.5 10]);
export_fig(strcat(pathname,name),'-eps', '-nocrop')
% copyfile(name,simDir_full);
% movefile(name,'../Graphs');


