%% Begin
%
clc
clear global
clear variables
close all

Sub = '50';     % working subdirectory, to avoid too many files in the current folder
addpath(Sub);
addpath('NewData');
filename = mfilename;   % used for saving

load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);

% Graph settings
Fsize=12;
LW = 1.4;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');

%% Data

load EE_CONS_PC.mat         % ee_cons_pc: 1993 Q1 : 2011 Q4 - EE consumption per capita
load EE_GDP_PC.mat          % ee_gdp: 1993 Q1 : 2011 Q4 - EE GDP per capita
load EU_HICP.mat            % eu infl: 1996 Q2 : 2012 Q1 - EU inflation from HICP done (annual) by 400*(lnP/lnP_t-1) 
load EE_HICP.mat            % ee infl: 1996 Q2 : 2012 Q1 - EU inflation from HICP done (annual) by 400*(lnP/lnP_t-1) 
load interest2.mat          % interest(:,1): 1996 Q1 : 2012 Q4 - EU 3-month (annual)
                            % interest(:,2): 1996 Q1 : 2012 Q4 - EE 3-month (annual)
load EU_GDP_PC.mat          % eu_gdp: 1995 Q1 : 2011 Q4 - EU GDP per capita
load EU_interest.mat        % eu_i: 1993 Q1 : 2012 Q4 - EU 3-month (annual)
load EE_GDP_INFL.mat        % ee_gdp_infl: 1994 Q1 : 2012 Q4 - EE GDP Deflator inflation (annual) - perc. change

ee_gdp = ee_gdp(13+1:end);
ee_cons = ee_cons_pc(13+1:end);
ee_pi = ee_infl(1:end-1)/4;
ee_i = interest(1+1:end-1,2)/4;
ee_P_infl = ee_gdp_infl(9+1:end-1,1)/4; % Div by for to make it quarterly


eu_gdp = eu_gdp(5+1:end);
eu_pi = eu_infl(1:end-1)/4;
eu_i = eu_i(13+1:end-1,1)/4;

yy = [ee_gdp...
    ee_cons...
    ee_pi...
    ee_i...
    eu_gdp...
    eu_pi...
    eu_i...
    ];

time = 1996.25:0.25:2011.75;
kline=zeros(size(time));

%% GDP plot
gdp_ee_fig = figure;
plot(time,yy(:,1),'Linewidth',2);
hold on
plot(time,kline,'k')
hold off
xlim([1996.0 2011.75])
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [10 5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 10 5]);
name = strcat('M',Sub,'_gdp_ee_gr.eps');
print(gdp_ee_fig, '-depsc', name);
movefile(name,'../Graphs');
% pathname = 'C:\Dropbox\Paper_Final\Graphs\';
% set(current_fig, 'Units','centimeters','Position', [10 10 16 10]);
% export_fig(strcat(pathname,name),'-pdf', '-eps','-nocrop')

%}
% 
% current_fig = figure;
% plot(time,d_ee*100,'linewidth',2)
% hold on
% plot(time,kline,'k')
% hold off
% xlim([1996.0 2011.75])
% set(gca,'FontSize',Fsize)
% set(gcf, 'PaperUnits', 'inches');
% set(gcf, 'PaperSize', [10 5]);
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperPosition', [0 0 10 5]);
% name = strcat('M',Sub,'_debt_ee_gr.eps');
% print(current_fig, '-depsc', name);
% movefile(name,'../Graphs');

%% Intro plots
%interest
units = 'centimeters';
period1_a = 1997.5;
period1_b = 2000;
period2_a = 2008;
period2_b = 2011;
pos_a = 21;
pos_b = 7;

load('detrending.mat','data_in')

current_fig = figure;
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',LW);
xlim([1996.0 2011.75]);
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', units);
set(gcf, 'PaperSize', [pos_a pos_b]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 pos_a pos_b]);
hold on
line([period1_a period1_a],[ylim],'Color','k','LineStyle','--');
line([period1_b period1_b],[ylim],'Color','k','LineStyle','--');
line([period2_a period2_a],[ylim],'Color','k','LineStyle','--');
line([period2_b period2_b],[ylim],'Color','k','LineStyle','--');
hold off
name = strcat('M',Sub,'_intro_interest.eps');
print(current_fig, '-depsc', name);
movefile(name,'../Graphs');
%%
FS = 10;
current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 16 4]);
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--');
beauty
hLegend= legend('TALIBOR','EURIBOR');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','NOrtheast');
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));
name = strcat('P1_M',Sub,'_intro_interest.eps');

pathname = '..\..\Paper_Final\Graphs_Final\';
export_fig(strcat(pathname,name),'-pdf', '-nocrop')


%%
current_fig = figure;
plot(time,yy(:,1),'Linewidth',LW);
hold on
plot(time,kline,'k')
hold off
xlim([1996.0 2011.75])
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits',units);
set(gcf, 'PaperSize', [pos_a pos_b]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 pos_a pos_b]);
hold on
line([period1_a period1_a],[ylim],'Color','k','LineStyle','--');
line([period1_b period1_b],[ylim],'Color','k','LineStyle','--');
line([period2_a period2_a],[ylim],'Color','k','LineStyle','--');
line([period2_b period2_b],[ylim],'Color','k','LineStyle','--');
hold off
name = strcat('M',Sub,'_intro_gdp.eps');
print(current_fig, '-depsc', name);
movefile(name,'../Graphs');




%}
% 
% current_fig = figure;
% plot(time,d_ee*100,'linewidth',LW)
% xlim([1996.0 2011.75])
% set(gca,'FontSize',Fsize)
% set(gcf, 'PaperUnits', units);
% set(gcf, 'PaperSize', [pos_a pos_b]);
% set(gcf, 'PaperPositionMode', 'manual');
% set(gcf, 'PaperPosition', [0 0 pos_a pos_b]);
% hold on
% line([period1_a period1_a],[ylim],'Color','k','LineStyle','--');
% line([period1_b period1_b],[ylim],'Color','k','LineStyle','--');
% line([period2_a period2_a],[ylim],'Color','k','LineStyle','--');
% line([period2_b period2_b],[ylim],'Color','k','LineStyle','--');
% hold off
% axis tight
% name = strcat('M',Sub,'_intro_debt.eps');
% print(current_fig, '-depsc', name);
% movefile(name,'../Graphs');

%%

gdp_ee=figure;
plot(time,yy(:,1),time,yy(:,5),'--','linewidth',2)
hold on
plot(time,kline,'k')
hold off
% title('$\triangle GDP^{EE}$','Interpreter','latex','Fontsize',16);
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [9 3.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 9 4]);
print(gcf, '-depsc2', 'M40_gdp_ee.eps');
movefile('M40_gdp_ee.eps','../Graphs')

cons_ee=figure;
plot(time,yy(:,2),'linewidth',2)
hold on
plot(time,kline,'k')
hold off
% title('$CONS^{EE}$','Interpreter','latex','Fontsize',16);
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [9 3.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 9 4]);
print(gcf, '-depsc2', 'M40_cons_ee.eps');
movefile('M40_cons_ee.eps','../Graphs')

infl_ee=figure;
plot(time,yy(:,3),time,yy(:,6),'--','linewidth',2)
hold on
plot(time,kline,'k')
hold off
% title('INFL^{EE}','Interpreter','latex','Fontsize',16);
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [9 3.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 9 4]);
print(gcf, '-depsc2', 'M40_infl_ee.eps');
movefile('M40_infl_ee.eps','../Graphs')

int_ee=figure;
plot(time,yy(:,4),time,yy(:,7),'--','linewidth',2)
hold on
plot(time,kline,'k')
hold off
% title('INT^{EE}','Interpreter','latex','Fontsize',16);
set(gca,'FontSize',Fsize)
set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperSize', [9 3.5]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 9 4]);
print(gcf, '-depsc2', 'M40_int_ee.eps');
movefile('M40_int_ee.eps','../Graphs')

%%

FS = 10;
current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 8 4]);
plot(time,yy(:,1),time,yy(:,5),'--')
beauty
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));
name = 'P1_M50_gdp_ee.eps';
pathname = '..\..\Paper_Final\Graphs_Final\';
export_fig(strcat(pathname,name),'-pdf', '-nocrop')


current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 8 4]);
plot(time,yy(:,2))
beauty
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));
name = 'P1_M50_cons_ee.eps';
pathname = '..\..\Paper_Final\Graphs_Final\';
export_fig(strcat(pathname,name),'-pdf', '-nocrop')


current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 8 4]);
plot(time,yy(:,3),time,yy(:,6),'--')
beauty
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));
name = 'P1_M50_infl_ee.eps';
pathname = '..\..\Paper_Final\Graphs_Final\';
export_fig(strcat(pathname,name),'-pdf', '-nocrop')


current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 8 4]);
plot(time,yy(:,4),time,yy(:,7),'--')
beauty
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));
name = 'P1_M50_int_ee.eps';
pathname = '..\..\Paper_Final\Graphs_Final\';
export_fig(strcat(pathname,name),'-pdf', '-nocrop')

