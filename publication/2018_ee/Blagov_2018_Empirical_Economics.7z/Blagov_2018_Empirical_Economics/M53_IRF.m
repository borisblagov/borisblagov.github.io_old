clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);
ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';

[~,~,~,~,~,~,~,~,M2_IRF_unsorted,M2_Variables_sct] = MS_Solve(theta_mean_cell);
M2_VarNames = M2_Variables_sct.VarNames;
M2_Xvar_sct = M2_Variables_sct.Xvar_sct;
M2_Nvar_sct = M2_Variables_sct.Nvar_sct;
Xvar = M2_Variables_sct.xvar;
Nvar = M2_Variables_sct.nvar;

M2_IRF = cell(nst,1); 
for st = 1:nst 
    M2_IRF{st} = zeros(size(M2_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M2_IRF{st}(:,ii) = M2_IRF_unsorted{st}(:,jj);
            if kk == 8
                M2_IRF{st}(:,ii) = M2_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M2_IRF{st}(find(M2_IRF{st}>-10^(-15) & M2_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Sub = '53';
addpath(Sub);
addpath('NewData');
simDir = 'nst_2__2013     2     6    15    29    32';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

d_ee = d_ee(2:end);
ident = char('M5');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';


% Graph settings
Fsize=12;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontSize', 12);


[~,~,~,~,~,~,~,~,M5_IRF_unsorted,M5_Variables_sct] = MS_Solve(theta_mean_cell);
M5_VarNames = M5_Variables_sct.VarNames;
M5_Xvar_sct = M5_Variables_sct.Xvar_sct;
M5_Nvar_sct = M5_Variables_sct.Nvar_sct;
Xvar = M5_Variables_sct.xvar;
Nvar = M5_Variables_sct.nvar;

M5_IRF = cell(nst,1); 
for st = 1:nst 
    M5_IRF{st} = zeros(size(M5_IRF_unsorted{st}));
    ii = 0;
    for kk = 1:Xvar    
        for jj=kk:Xvar:Xvar*Nvar
            ii = ii+1;            
            M5_IRF{st}(:,ii) = M5_IRF_unsorted{st}(:,jj);
            if kk == 8
                M5_IRF{st}(:,ii) = M5_IRF{st}(:,ii)*(-1);
            end
        end
    end
    M5_IRF{st}(find(M5_IRF{st}>-10^(-15) & M5_IRF{st}<10^(-15)))=0; % to remove anything 10^-16
end


jj = 0;
st = 1;
varlist = [M5_Nvar_sct.y M5_Nvar_sct.i M5_Nvar_sct.d M5_Nvar_sct.ist];




%%%%%% M5

set(0,'defaultAxesFontName', 'Garamond');
set(0,'defaultTextFontName', 'Garamond');
set(0,'defaultAxesFontSize', Fsize);
fName = 'Garamond';
sh = M5_Xvar_sct.phi;   %1:12,M1_IRF{st}(1:12,ii+Nvar*(sh-1)),
current_fig = figure;
for ii = 1:11
    if ii ~= 6 & ii ~=9
    jj = jj+1;
    subplot(3,3,jj)
    plot(1:12,M5_IRF{st}(1:12,ii+Nvar*(sh-1)),1:12,M5_IRF{st+1}(1:12,ii+Nvar*(sh-1)),1:12,M2_IRF{st+1}(1:12,ii+Nvar*(sh-1)),'-.',1:12,M2_IRF{st}(1:12,ii+Nvar*(sh-1)),'--','Linewidth',1.5);
    title(deblank(M5_VarNames(ii,:)),'Fontsize',Fsize,'Fontname',fName);  
    beauty
%     kline = zeros(1,20);
%     hold on
%     plot(1:12, kline,'k','Linewidth',1);
%     hold off
%     xlim([1, 12]);
    end  
end

