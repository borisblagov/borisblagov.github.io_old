clear variables
clear global
close all
clc

Sub = '53';
addpath(Sub);
addpath('NewData');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
simDir = 'nst_2__2013     2     6    15    29    32';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
% load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

% d_ee = d_ee(2:end);

ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';

%% Probabilities Graph
% Graph settings
Fsize=12;
set(0,'defaultAxesFontName', 'Times');
set(0,'defaultTextFontName', 'Times');
set(0,'defaultAxesFontSize', 12);

figure
[pmode_sm, pmode_Nsm] = MS_smooth(pr_tt0M,pr_tl0M,PS_m);
area(time,1-pmode_sm(:,1))
hold on
plot(time,1-pmode_Nsm(:,1),'r--')
plot(time,1-pmode_Nsm(:,1),'r--','Linewidth',1.5)
hold off

current_fig = figure;
subplot(2,1,1)
plot(time,data_in(2:end-1,1),time,data_in(2:end-1,2),'Linewidth',1.5);
axis tight
subplot(2,1,2)
area(time,1-pmode_sm(:,1))
hold on
plot(time,1-pmode_Nsm(:,1),'r--')
plot(time,1-pmode_Nsm(:,1),'r--','Linewidth',1.5)
hold off
% set(gca,'FontSize',20)
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperSize', [24 16]);
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperPosition', [0 0 24 16]);
print(current_fig, '-depsc', 'M5_prob_fig.eps');
movefile('M5_prob_fig.eps','../Graphs');


FS = 10;
current_fig = figure;
subplot(2,1,1)
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'Linewidth',1.5);
beauty
subplot(2,1,2)
plot(time,1-pmode_sm(:,1))
beauty
hold on
% plot(time,1-pmode_Nsm(:,1),'r--')
plot(time,1-pmode_Nsm(:,1),'Color',[44 160 44]/255,'LineStyle','--','Linewidth',1.5)
hold off

name = 'M5_prob_fig.eps';
pathname = '..\..\Paper_Final\Graphs_Final\';
set(current_fig, 'Units','centimeters','Position', [10 10 16 8]);
export_fig(strcat(pathname,name),'-pdf', '-nocrop')

%%

FS = 10;
current_fig = figure;
set(current_fig, 'Units','centimeters','Position', [10 10 16 8]);

subplot(2,1,2)
plot(time,data_in(2:end-1,2),time,data_in(2:end-1,1),'--','Linewidth',1.5);
beauty
% tith = title(strcat('TALIBOR and EURIBOR'));
% set(tith,'Fontname','Garamond','FontSize',FS);
hLegend= legend('TALIBOR','EURIBOR');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','NOrtheast');
temp_ylabels=str2num(get(gca,'YTickLabel'));
set(gca, 'YTick', temp_ylabels);
set(gca,'YTickLabel',strcat(get(gca,'YTickLabel'),['%']));

subplot(2,1,1)
sStateProb = 1-pmode_sm(:,1);
tpind = sStateProb>0.5;
% plot(time,tprob.*~tpind,time,tprob.*tpind)
area(time,sStateProb.*~tpind,'Facecolor',[0 143 213]/255)
hold all
area(time,sStateProb.*tpind,'Facecolor',[180 39 40]/255)
hold off
axis tight
tith = title(strcat('Estimated probability of the second regime'));
set(tith,'Fontname','Garamond','FontSize',FS);
set(gca, ...
  'Fontname'    , FNAME  ,...  'Color'       , [0.937 0.925 0.918],...
  'Fontsize'    , FS  ,...   
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...  
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      );
hLegend= legend('Regime 1','Regime 2');
set(hLegend, 'Box','off','Fontname',FNAME,'FontSize',FS,'Location','South');
set(gcf,'Color',[1 1 1]);


name = 'P1_M5_prob_fig';
pathname = '..\..\Paper_Final\Graphs_Final\';
print(current_fig, '-dmeta', name);
movefile(strcat(name,'.emf'),pathname)  


%%
theta_samp_vec = datasample(MH_mat,1,2); % draw a vector of theta from the posterior

theta_samp_cell=theta_mode;
for ii = 1:length(ndxLam_c)
    theta_samp_cell{ii}(ndxSwitch{1})  = theta_samp_vec(ndxLam_c{1});
    theta_samp_cell{ii}(ndxSwitch{ii}) = theta_samp_vec(ndxLam_c{ii});
end
if nst == 4
    theta_samp_cell{4}(ndxSwitch{1}) = theta_samp_vec(ndxLam_c{1});
    theta_samp_cell{4}(ndxSwitch{4}) = [theta_samp_cell{2}(ndxSwitch{2}); theta_samp_cell{3}(ndxSwitch{3})];
end

[OmegaK_samp,GammaK_samp,Q_samp_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_samp_cell);

yy_fsamp_cell = cell(nst,1);
for ii = 1:nst
    yy_fsamp_cell{ii} = zeros(10000,size(yy,2));
    for ji = 1:10000
        xx_samp = zeros(14,64);     %64 and not 63 because of the initial obs.
        yy_samp = zeros(size(yy));
        for j = 1:63
            xx_samp(:,j+1) = OmegaK_samp{ii}*xx_samp(:,j) + GammaK_samp{ii}*(sqrt(diag(Q_samp_cell{ii})).*randn(8,1));
            yy_samp(j,:) = (H*xx_samp(:,j+1))';
        end
        yy_fsamp_cell{ii}(ji,:) = std(yy_samp);
    end
    disp(mean(yy_fsamp_cell{ii}));
end
disp(std(yy));