MH_Mean_mat = mean(MH_full_mat,2);
MH_Std_mat = std(MH_full_mat,0,2);

MH_CIlow_mat = MH_Mean_mat - 2.576*MH_Std_mat./sqrt(Nsim_act);
MH_CIhigh_mat = MH_Mean_mat + 2.576*MH_Std_mat./sqrt(Nsim_act);
[MH_Mean_mat MH_CIlow_mat MH_CIhigh_mat]