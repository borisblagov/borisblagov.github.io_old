clear variables
clear global
close all
clc

Sub = '50';
addpath(Sub);
addpath('NewData');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% M2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simDir = 'nst_2__2012    11     2     0    37    54 Linear i';
% simDir = 'nst_2__2012    11     2    13     3     2 HP';
simDir = 'nst_2__2022     6    22    13     0    45';
simDir_full = strcat(Sub,'/',simDir);
addpath(simDir_full);

load('Step3_run1.mat')
% load d_ee.mat               % d_ee: 1996Q1 : 2011Q4 - Estonian net external debt as percentage to GDP per capita from above

% d_ee = d_ee(2:end);
ident = char('M2');
parnmdol_vec(15,:)='$\rho_{\phi}$   ';
parnmdol_vec(23,:)='$\sigma_{\phi}$ ';
parnmdol_vec(27,:)='$\sigma_{\phi}$ ';

yy_fsamp_cell = cell(nst,1);
for ii = 1:nst
    yy_fsamp_cell{ii} = zeros(5000,size(yy,2));
    for ji = 1:5000
    theta_samp_vec = datasample(MH_mat(:,5000:end),1,2); % draw a vector of theta from the posterior

    theta_samp_cell=theta_mode;
    for is = 1:length(ndxLam_c)
        theta_samp_cell{is}(ndxSwitch{1})  = theta_samp_vec(ndxLam_c{1});
        theta_samp_cell{is}(ndxSwitch{is}) = theta_samp_vec(ndxLam_c{is});
    end
    if nst == 4
        theta_samp_cell{4}(ndxSwitch{1}) = theta_samp_vec(ndxLam_c{1});
        theta_samp_cell{4}(ndxSwitch{4}) = [theta_samp_cell{2}(ndxSwitch{2}); theta_samp_cell{3}(ndxSwitch{3})];
    end

    [OmegaK_samp,GammaK_samp,Q_samp_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_samp_cell);


        xx_samp = zeros(14,64);     %64 and not 63 because of the initial obs.
        yy_samp = zeros(size(yy));
        for j = 1:63
            xx_samp(:,j+1) = OmegaK_samp{ii}*xx_samp(:,j) + GammaK_samp{ii}*(sqrt(diag(Q_samp_cell{ii})).*randn(8,1));
            yy_samp(j,:) = (H*xx_samp(:,j+1))';
        end
        yy_fsamp_cell{ii}(ji,:) = std(yy_samp);
        if rem(ji,100) == 0
            disp(ji);
        end
    end
    disp(mean(yy_fsamp_cell{ii}));
end
disp(std(yy));
rmpath(simDir_full);