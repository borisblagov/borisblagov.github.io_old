function out_vec = inv_gampdf(in_vec,alpha,beta)
% Calculates the pdf of an inverse gamma with shape parameter alpha and
% scale parameter beta. If x is a vector, it returns a vector.
out_vec = (beta^alpha/gamma(alpha))*(in_vec.^(-alpha-1)).*exp(-beta./in_vec);