function dist_bounds = distribution_bounds(type)
global nst
dist_bounds = cell(nst,1);

for i=1:nst
    np = size(type,1);
    outparv = zeros(np,2);

     % Beta distributed parameters
     ndx = find(type==1);
     outparv(ndx,1) = 0;
     outparv(ndx,2) = 1;

     % Gamma distributed parameters
     ndx = find(type==2);
     outparv(ndx,1) = 0;
     outparv(ndx,2) = 100;
     
     % Inverse Gamma distributed parameters
     ndx = find(type==3);
     outparv(ndx,1) = 0;
     outparv(ndx,2) = 100;
     
     % PM Beta paramters that would not be estimated but have to be reparametrised
     ndx = find(type==11);
     outparv(ndx,1) = 0;
     outparv(ndx,2) = 1;

     % PM Gamma paramters that would not be estimated but have to be reparametrised
     ndx = find(type==12);
     outparv(ndx,1) = 0;
     outparv(ndx,2) = 100;

     % PM IGamma paramters that would not be estimated but have to be reparametrised
     ndx = find(type==13);
     outparv(ndx,1) = 0;
     outparv(ndx,2) = 100;
      
    % Gaussian distributed parameters 
    ndx=find(type==4); 
    outparv(ndx,1) = -Inf;
    outparv(ndx,2) = Inf;    
    
    dist_bounds{i}=outparv;
end
