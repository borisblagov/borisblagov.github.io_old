function [PS] = Prob_extract(in_cell)
nst = size(in_cell,1);

P = [in_cell{1}(1,1) 1-in_cell{1}(2,1);
    1-in_cell{1}(1,1) in_cell{1}(2,1)];  %P_{ij} = Prob(S_t = j|S_{t-1}) = i) <==> P_21= Prob of coming to State 2 from 1 (1-p11);
PS = P;
if nst == 4
    Q = [in_cell{1}(3,1) 1-in_cell{1}(4,1);
    1-in_cell{1}(3,1) in_cell{1}(4,1)];  

    PS = kron(P,Q);
end