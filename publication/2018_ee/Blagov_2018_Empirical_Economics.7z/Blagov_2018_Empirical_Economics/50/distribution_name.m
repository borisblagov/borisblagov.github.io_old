function dist_name = distribution_name(type)
if type(1,1)==1
    dist_name = '$Beta$';
elseif type(1,1)==2   
    dist_name = '$Gamma$';
elseif type(1,1)==3   
    dist_name = '$IGamma$';
elseif type(1,1)==4   
    dist_name ='$Normal$';  
elseif type(1,1)>10   
    dist_name = '$PM$';   
end

for i=2:length(type)
    if type(i,1)==1
        dist_name = char(dist_name,'$Beta$');
    elseif type(i,1)==2   
        dist_name = char(dist_name,'$Gamma$');
    elseif type(i,1)==3   
        dist_name = char(dist_name,'$IGamma$');
    elseif type(i,1)==4   
        dist_name = char(dist_name,'$Normal$');       
    elseif type(i,1)>10   
        dist_name = char(dist_name,'$PM$');      
    end
end
