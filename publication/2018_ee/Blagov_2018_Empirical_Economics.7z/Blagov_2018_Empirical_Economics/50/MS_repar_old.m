function [outparv_cell,lnjac,lnprior]=MS_repar(inparv_cell,R_cell,direction,prior_type_cell)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The function performs reparameterisation (bounded to unbounded or unbounded to
% bounded parameters and computes lnjac and lnprior in a DSGE model, modified to take
% cells as inputs and to return cells as output for a Markov-Switching environment.
% -----------------------------------------------------------------------------------
% -Input-:
% inparv_cell:      2x1 cell with 2 (np x 1) parameter vectors, either original
%                   parameters or reparametrized version (decided  by 'direction')
% R_cell:           parameters of the distributions (alpha, beta for Gamma dist. etc) 
% direction:        determines whether original parmeters should be reparametrized(0)
%                   or reparametrized parameters should be converted back(1).
% prior_type_cell:  a cell indicating the distributions of the parameters.
%                   1 for Beta
%                   2 for Gamma
%                   3 for Inverse Gamma
%                   4 for Normal
%                   11 for Point Mass Beta
%                   12 for Point Mass Gamma
%                   13 for Point Mass Inverse Gamma
%                   14 for Point Mass Normal
% -Output-:
% outparv_cell:     2x1 cell with (np x 1) parameter vector each
% lnjac:            scalar - ln jacobian 
% lnprior:          scalar - ln prior (kernel only)
% -----------------------------------------------------------------------------------
% Written by: Gianni Amisano
% Modified by: Boris Blagov
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global check_cell
nst = max(size(inparv_cell));
outparv_cell = cell(nst,1);
lnjac=0;
lnprior=0;
for i=1:nst
    inparv = inparv_cell{i};
    np = size(inparv,1);
    outparv = zeros(np,1);
    prior_type_ndxv = prior_type_cell{i}.*check_cell{i};
    if i == 4
        lnjac3 = lnjac;
        lnprior3 = lnprior;
    end
    if direction~=0
         % Direct transformation from lambda to theta (from unbounded to bounded)
         % Beta distributed parameters
         ndx = find(prior_type_ndxv==1);
         outparv(ndx) = (1+exp(-(inparv(ndx)))).^(-1);
         p1  = log(outparv(ndx));%ln(theta)
         p2  = log(1-outparv(ndx)); %ln(1-theta)
         lnjac   = lnjac - sum(p1+p2);
         lnprior = lnprior + sum((R_cell{i}(ndx,1)-1).*p1 +(R_cell{i}(ndx,2)-1).*p2);
         
         % Gamma distributed parameters
         ndx = find(prior_type_ndxv==2);
         p1  = inparv(ndx); % omega
         p2  = exp(p1);     % theta
         outparv(ndx) = p2;
         lnjac   = lnjac - sum(p1);
         lnprior = lnprior + sum(p1.*(R_cell{i}(ndx,1) - 1) - p2./R_cell{i}(ndx,2));
         
         % Inverse Gamma distributed parameters
         ndx = find(prior_type_ndxv==3);
         p1  = inparv(ndx); %omega
         p2  = exp(p1);     %theta
         outparv(ndx) = p2;
         lnjac   = lnjac - sum(p1);
         lnprior = lnprior + sum(p1.*(-R_cell{i}(ndx,1)-1) - R_cell{i}(ndx,2)./p2);
         
         % PM Beta paramters that would not be estimated but have to be reparametrised
         ndx = find(prior_type_ndxv==11);
         outparv(ndx) = (1+exp(-(inparv(ndx)))).^(-1);
         
         % PM Beta paramters that would not be estimated but have to be reparametrised
         ndx = find(prior_type_ndxv==12);
         outparv(ndx) =  exp(inparv(ndx));
         
         % PM Beta paramters that would not be estimated but have to be reparametrised
         ndx = find(prior_type_ndxv==13);
         outparv(ndx) = exp(inparv(ndx));
         
    else
         % INVERSE transformation from theta to lambda (from bounded to unbounded)
         % Beta distributed parameters
         ndx = find(prior_type_ndxv==1);
         p1  = log(inparv(ndx));    %ln(theta)
         p2  = log(1-inparv(ndx));  %ln(1-theta)
         outparv(ndx) = p1-p2;
         lnjac   = lnjac + sum(p1+p2);
         lnprior = lnprior + sum((R_cell{i}(ndx,1)-1).*p1 +(R_cell{i}(ndx,2)-1).*p2);
         
         % Gamma distributed parameters
         ndx = find(prior_type_ndxv==2);
         p1 = inparv(ndx);
         p2 = log(p1);
         outparv(ndx) = p2;
         lnjac = lnjac + sum(p2);
         lnprior = lnprior + sum(p2.*(R_cell{i}(ndx,1) - 1) - p1./R_cell{i}(ndx,2));
         
         % Inverse Gamma distributed parameters
         ndx = find(prior_type_ndxv==3);
         p1 = inparv(ndx);
         p2 = log(p1);
         outparv(ndx) = p2;
         lnjac = lnjac + sum(p2);
         lnprior = lnprior + sum(p2.*(-R_cell{i}(ndx,1)-1) - R_cell{i}(ndx,2)./p1); %beta of IG dist is 1/beta of gamma
         
         % PM Beta paramters that would not be estimated but have to be reparametrised
         ndx = find(prior_type_ndxv==11);
         outparv(ndx) = log(inparv(ndx))-log(1-inparv(ndx));
         
         % PM Gamma paramters that would not be estimated but have to be reparametrised
         ndx = find(prior_type_ndxv==12);         
         outparv(ndx) = log(inparv(ndx));
         
         % PM IGamma paramters that would not be estimated but have to be reparametrised
         ndx = find(prior_type_ndxv==13);
         outparv(ndx) = log(inparv(ndx));
    end
    % Gaussian distributed parameters (here no transformation is involved) 
    % therefore the code is the same in the direct and inverse transformation 
    % and lnjac=0 
    ndx=find(prior_type_ndxv==4); 
    p1=inparv(ndx); %lambda=theta 
    outparv(ndx)=p1; 
    lnprior=lnprior-sum(((p1-R_cell{i}(ndx,1))./R_cell{i}(ndx,2)).^2)/2;
    
    % PM Gaussian to be reparametrised (not needed actually)
    ndx=find(prior_type_ndxv==14); 
    outparv(ndx)=inparv(ndx); 
    
    outparv_cell{i}=outparv;
    outparv_cell{i}=outparv_cell{1}.*(1-check_cell{i}) + outparv_cell{i}.*check_cell{i};
    if i==1 
        if find(isnan(outparv_cell{1}))
            outparv_cell{1}(find(isnan(outparv_cell{1})))=-Inf;
        end; 
    end
    if i==4
        lnprior = lnprior3;
        lnjac = lnjac3;
    end
end

