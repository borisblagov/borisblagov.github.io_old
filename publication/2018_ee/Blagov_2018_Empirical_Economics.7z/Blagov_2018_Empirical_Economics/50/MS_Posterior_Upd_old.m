function [Like] = MS_Posterior_Upd(lambda_vec, yy, Rm_cell, prior_type_cell,PM_lambda_vec,ndxLam_c)
global ndxSwitch nst ndxPM

np = length(prior_type_cell{1});

lambda1_cell = cell(nst,1);
for ii = 1:nst
    lambda1_cell{ii} = zeros(np,1);
    lambda1_cell{ii}(ndxPM) = PM_lambda_vec;
    lambda1_cell{ii}(ndxSwitch{1}) = lambda_vec(ndxLam_c{1});
    if ii ~= 4
        lambda1_cell{ii}(ndxSwitch{ii}) = lambda_vec(ndxLam_c{ii});
    elseif ii == 4
        lambda1_cell{ii}(ndxSwitch{ii}) = [lambda_vec(ndxLam_c{2});lambda_vec(ndxLam_c{3})];
    end
end

[theta_prior,lnjac,lnprior] = MS_repar(lambda1_cell,Rm_cell,1,prior_type_cell);
lnprior1=lnprior-lnjac;
% 
% P = [theta_prior{1}(1,1) 1-theta_prior{1}(2,1);
%     1-theta_prior{1}(1,1) theta_prior{1}(2,1)];  %P_{ij} = Prob(S_t = j|S_{t-1}) = i) <==> P_21= Prob of coming to State 2 from 1 (1-p11);
% PS = P;
% if nst == 4
% Q = [theta_prior{1}(3,1) 1-theta_prior{1}(4,1);
%     1-theta_prior{1}(3,1) theta_prior{1}(4,1)];  %P_{ij} = Prob(S_t = j|S_{t-1}) = i) <==> P_21= Prob of coming to State 2 from 1 (1-p11);
% PS = kron(P,Q);
% end
PS = Prob_extract(theta_prior);
[OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_prior);
if Problems.FCC~=0 || Problems.Det ~=0
    likv1 = NaN;
else
    if nst==4
        [likv1, Problems.Like] = MS_Likelihood_Upd(yy, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, PS);
    else
    [likv1, Problems.Like] = MS_Likelihood(yy, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, PS);
    end    

    if Problems.Like == 1
        likv1 = NaN;
    end
end

% [lnlv,liklvl]=dsge_kf(yy,OmegaK{1}, GammaK{1},H,R_cell{1},Q_cell{1});
% likv1 = liklvl;

Like =-(lnprior1 + likv1);    % use this if you want to maximize the posterior
% Like =-(likv1);                 % use this if you want to maximize the likelihood alone