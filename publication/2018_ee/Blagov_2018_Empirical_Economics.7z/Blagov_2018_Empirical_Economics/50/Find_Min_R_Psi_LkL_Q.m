function [R_BarPsi_LkL,varargout] = Find_Min_R_Psi_LkL_Q(par,n,S,k,KKSbegin,KKSend,P) 
         
         Phi=cell(S,S);
            for i=1:S, for j=1:S
                 Phi{i,j}=reshape(par(KKSbegin(i,j):KKSend(i,j)),k{j},k{i});
             end, end

         nKKSend=KKSend(S,S);
         nVi=nKKSend;
         V=cell(S,1);
         for i=1:S,          
            V{i,1}= reshape(  par(nVi+1: nVi+n*k{i,1},:) , n,k{i,1} );
            nVi=nVi+n*k{i};
         end
         
         L=cell(S,S);
            for i=1:S, for j=1:S,
                 L{i,j}=V{j}*Phi{i,j}*V{i}';
             end, end

         BarPsi_LkL=[];
            for i=1:S, 
                tmp=[]; 
                for j=1:S, 
                    tmp=[tmp P(j,i)*kron(L{j,i},L{j,i})];
                end
                BarPsi_LkL=[BarPsi_LkL;tmp];
            end
      
         R_BarPsi_LkL=max(abs(eig(BarPsi_LkL)));
         
        varargout(1)={L};
        varargout(2)={Phi};
        varargout(3)={V};
        varargout(4)={BarPsi_LkL};
                                       
