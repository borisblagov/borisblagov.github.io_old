function [disp_res disp_resf] = disp_results(in_cell,parnames,np,DISP)
% Converts and displays the results from a cell representation to a string
% representation (with parameter names) or to a matrix. DISP = 0 suppresses output
global nst ndxSwitch

disp_res = zeros(np,nst);
for ii = 1:nst
    disp_res(:,ii) = in_cell{ii};
end
disp(' ');
disp_resf =[parnames num2str(disp_res)];
if DISP~=0
    disp(disp_resf);
    if nst~=1
        disp(' ');
        disp(' ');
        disp('Switching coefficients');
        disp([parnames(ndxSwitch{end},:) num2str(disp_res(ndxSwitch{end},:))]);
    end
end