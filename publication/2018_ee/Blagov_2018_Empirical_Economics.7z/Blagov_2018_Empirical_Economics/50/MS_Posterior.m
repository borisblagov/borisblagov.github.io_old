function [Like] = MS_Posterior(max_vec, yy, Rm_cell, prior_type_cell,PMvalues_vec)
global ndxSwitch nst

np = length(prior_type_cell{1});
mp = length(max_vec)-length(ndxSwitch); % to extract how many elements of the input lambda_vec are in one state, excluding the PM elements

lambda_prior = vec2cell(max_vec,mp,np,PMvalues_vec);
[theta_prior,lnjac,lnprior] = MS_repar(lambda_prior,Rm_cell,1,prior_type_cell);
lnprior1=lnprior-lnjac;

P  = zeros(nst,nst);
for si = 1:nst
    P(si,si) = theta_prior{1}(si,1);
end
P(2,1) = 1-P(1,1);
P(1,2) = 1-P(2,2);  % K&N Convetion, not Cho's convention

[OmegaK,GammaK,Q_cell,R_mat,H,FK,termK, Problems] = MS_Solve(theta_prior);
if Problems.FCC~=0 || Problems.Det ~=0
    likv1 = NaN;
else
[likv1, Problems.Like] = MS_Likelihood(yy, OmegaK, GammaK, H, R_mat, Q_cell, P);
    if Problems.Like == 1
        likv1 = NaN;
    end
end

% [lnlv,liklvl]=dsge_kf(yy,OmegaK{1}, GammaK{1},H,R_cell{1},Q_cell{1});
% likv1 = liklvl;

Like =-(lnprior1 + likv1);    % use this if you want to maximize the posterior
% Like =-(likv1);                 % use this if you want to maximize the likelihood alone