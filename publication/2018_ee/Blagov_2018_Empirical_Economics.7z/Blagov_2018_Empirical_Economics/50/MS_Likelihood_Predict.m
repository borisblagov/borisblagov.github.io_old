function [likv, osaf, Problems,pr_tt0M,pr_tl0M] = MS_Likelihood_Predict(yy, F, G, H, R, Q, mu, P)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimates the likelihood of a Markov Switching Model along the lines of Kim&Nelson 
% (1999)'s "States State-Space Models with Regime-Switching: Classical and Gibbs - 
% Sampling Approaches with Applications" (MIT Press).
% -------------------------------------------------------------------------
% The model:
%           yy_t = H(s)*beta_t     +   e_t + mu_me(s)     (measurment eq.)
%         beta_t = F(s)*beta_{t-1} + G*v_t + mu_tr(s)     (transition eq.)
% with
%           e_t ~ N(0, R(s)), v_t ~ N(0, Q(s)) and E[e_t v_t] = 0
%
% Output:   [likv] = MS_Likelihood (yy, F, Q, H, R, P) where
% likv:     the final log likelihood value (negative)
% yy:       vector or a matrix - data for the model.
% F:        a cell array with "s" transition matrices F (may be equal).
% H:        a cell array with "s" H matrices, linkin observed with unobserved 
%           variables (usually equal).
% G:        a cell array with the vector augmenting the structural shocks v_t.
% Q:        a cell array with the variance of the structural shocks (1x1 in RBC).          
% R:        a cell, the variance of e_t
% P:        the matrix of switching probabilities, defined in the manner of
% Hamilton (1994) and Kim and Nelson (1999): p_21 = Prob(s_t=2 | s_{t-1}=1)
% -------------------------------------------------------------------------
% Written by: Boris Blagov
% This version: 1.07.2012
% matlabpool open
nst=size(F,1);

lastwarn('');
Problems = 0;
warn1='MATLAB:illConditionedMatrix';

T=length(yy);
nx=size(F{1},1);


P_mat = P';
im = ones(nst,1);
A= [eye(nst)-P; im'];
prob = (A'*A)\A'*[zeros(nst,1);1];


pr_tl0M=zeros(T,nst); % to store Pr(S_t=0 | Y_{t-1})
pr_tt0M=zeros(T,nst); % to store Pr(S_t=0 | Y_t)

B_LL = cell(nst,1);
osaf = cell(nst,nst);
P_LL = cell(nst,1);
B_TL = cell(nst,nst);
P_TL = cell(nst,nst);
B_TT = cell(nst,nst);
P_TT = cell(nst,nst);
f_cast = cell(nst,nst);
ss = cell(nst,nst);
PR_VL = zeros(nst,nst);

for i = 1:nst
    B_LL{i} = zeros(nx,1);
    P_LL{i}=reshape((eye(nx^2)-kron(F{i},F{i}))\reshape(G{i}*Q{i}*G{i}',nx^2,1),nx,nx);
    osaf{i,1} = zeros(size(H,1),T)';
    osaf{i,2} = zeros(size(H,1),T)';
end

likv=0;
for j = 1:T        
    for k=1:nst
        pr_tl0M(j,k)= P(k,:)*prob;
        for l = 1:nst
            B_TL{k,l}   = F{l}*B_LL{k};
            P_TL{k,l}   = F{l}*P_LL{k}*F{l}' + G{l}*Q{l}*G{l}';
            f_cast{k,l} = yy(j,:)' - H*B_TL{k,l} - mu{l};
            osaf{k,l}(j,:) = H*B_TL{k,l};
            ss{k,l}     = H*P_TL{k,l}*H' + R;
            B_TT{k,l}   = B_TL{k,l} + ((P_TL{k,l}*H')/ss{k,l})*f_cast{k,l};
            P_TT{k,l}   = (eye(nx) - ((P_TL{k,l}*H')/ss{k,l})*H)*P_TL{k,l};
            PR_VL(k,l)  = v_probVec(f_cast{k,l},ss{k,l})*P_mat(k,l)*prob(k);
        end
    end
    pr_val = sum(sum(PR_VL));
    pro    = PR_VL./pr_val;
    prob   = sum(pro)';
    for k=1:nst
        pr_tt0M(j,k) = prob(k);
    end
    bb = zeros(nx,1,nst);
    pp = zeros(nx,nx,nst);
    
    for n= 1:nst
        for m=1:nst
            bb(:,:,m) = pro(m,n)*B_TT{m,n};            
        end
        B_LL{n} = sum(bb,3)/prob(n);        
    end
        
    for n= 1:nst
        for m=1:nst
            pp(:,:,m)= pro(m,n)*(P_TT{m,n} + (B_LL{n} - B_TT{m,n})*(B_LL{n} - B_TT{m,n})');            
        end
        P_LL{n} = sum(pp,3)/prob(n);
    end
                  
    if j>1        
            likv = likv+log(pr_val);
    end
    [msg, msgid] = lastwarn;
    if strcmp(msgid,warn1)==1
        Problems = 1;
        likv = -100000000;
        return
    end      
end