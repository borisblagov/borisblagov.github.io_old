function [LambdaMin,varargout]=Find_Min_R_Psi_LkL(P,F,Opt)
%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
% === A supplementary code for "Characterizing MSRE Models" 
% === Written by Seonghoon Cho, October 9, 2011
% === For a model with P, and F, this code produces a non-fundamental
% === component process that minimizes R_BarPsi_LkL (see below).
% ==================================================================
% Some Definitions first
%   Model : w(t)=E_t [F(s(t),s(t+1))w(t+1)]
%   Solution : w(t+1)=Lambda(s(t),s(t+1))w(t)+V(s(t+1))V(s(t+1)'*eta(t+1) where
%                     Lambda(s(t),s(t+1))=V(s(t+1))*Phi(s(t),s(t+1))*V(s(t))                     
%   Psi_X= Psi_X,   BarPsi_L =BarPsi_X where
%   X can be L (Lambda), LkL for kron(L,L)
%            F, FkF for kron(F,F), 
%            FkLt for kron(F,L^T) with T being "transpose" 
%   Xij being X(s(t)=i,s(t+1)=j)
%   R_Psi_X is the spectral radius of Psi_X
%      
%% This code does the following.
%  (1) For a given transition prob matrix P and F, computes 
%      a non-fundamental solution Lambda (s(t),s(t+1)) such
%      that  E_t [ F(s(t),s(t+1)) Lambda (s(t),s(t+1)) ] w(t) = w(t) 
%       , minimizing the spectral radius of Psi_LkL, R_Psi_LkL specified in
%       Find_Min_R_Psi_LkL_Q.m subject to the constraints 
%       : V{i}^T V{i} =eye(k{i}), sum_j P(i,j)F{i,j}V{j}Psi{i,j} =V{i} 
%         specified in Find_Min_R_Psi_LkL_NL.m.
%  (2) Confirm Assertion 2 of Lemma 4 in the paper 
%       R_BarPsi_LkL = tau >= (1/xi) where xi = R_Psi_FkF
%      Remark 1: This codes find Lambda minimizing R_BarPsi_LkL. 
%           Every minimization starting from different initial Lambda will yield 
%           different Lambda, but will confirm that tau >= 1/xi.  
%           The problem is like to find (x,y) to min z=(x+y-1)^2. Thus
%            Different initial choice of (x0, y0) will yield the same z=0
%            but different (x*, y*)=argmin z.
%      Remark 2: Within several trials, one will almost always find a set 
%           yielding tau=1/xi. BUT xi<1 is not necessary for Determinacy
%           because it is possible that tau > 1>= 1/xi when xi>=1.
%           This happens only when F does not make any economic sense.
%           e.g.: F_ij=zeros if i~=j. 
%% Contents of the Code
%   [1] Specify your own Input and run the code.
%   [2] Default Initial values for ks, V and Phi are specified.
%   [3] Optimization
%   [4] Output
%% Input and Output
%   [1] Input arguments
%       [1-1] Required Input arguments
%           P(1,1)=p11;.... P(S,S)=pSS;
%                  : S by S transition matrix where the ij-th element, 
%                  p_ij=Pr(s(t+1)=j|s(t)=i).
%           F=cell(S,S); F{1,1}=Fij; ..., F{S,S}=FSS;
%                  : S by S cell array such that F{i,j}=F(s(t)=i,s(t+1)=j).
%                  (If F=F(s(t)), then A is S by 1 cell array such that
%                    F{i,1}=F(s(t)=i).) size(F{i,j})=n by n
%       [1-2] Optional Input arguments
%           Opt.ks  : S by 1 vector of [k(s(t)=1) ... k(s(t)=S)]' 
%                 where 0<= k(i) <= n for all i and
%                       0<  k(i) for some i
%                 - Default : ks=[n_1 ... n_S]' where n_i=rank(F{i,j))                   
%           Opt.V   : S by 1 cell array such that V{i} is the  n by k(i) initial
%                 matrix with orthornormal columns
%                 - Default : columns of V{i) are random orthonormal columns.
%           Opt.Phi : S by S cell array such that Phi{i,j} is the  k(j) by k(i) initial
%                 matrix 
%                 - Default : Phi{i,j} is random. 
%   [2] Output arguments
%           LambdaMin : Lambda{i,j} Minimizing R_Psi_kron(Lambda,Lambda)
%           V         : V{j} corresponding to LambdaMin
%           Psi       : Psi{i,J} corresponding to LambdaMin
%           k         : Choice of k{i}
%           R_BarPsi_LkL : R_BarPsi_kron(LambdaMin,LambdaMin)
%           R_BarPsi_L : BarPsi_LambdaMin
%           R_Psi_FkF : R_Psi_kron(F,F)
%           R_Psi_F   : R_Psi_kron(F)
%           Psi_LtkF  : Psi_kron(Lambda',F)


%% [0] Identify S (number of Regime), n (rows of A) 
    S=size(P,1); 
    n=size(F{1,1},1);   

%% [2] Default Specifications for ks, V and Phi
    if nargin==3 && isfield(Opt,'ks'), ks=Opt.ks; 
                                else
                                        ks=zeros(S,1);
                                        for i=1:S,
                                            ks(i)=rank(F{i,1});
                                            %ks(i)=n;
                                        end
                              	end
    if nargin==3 && isfield(Opt,'V'), V=Opt.V; 
                                else 
                                   k=cell(S,1); W=cell(S,1); V=cell(S,1);     
                                        for j=1:S,
                                            k{j,1}=ks(j,1);
                                            W{j,1}=orth(randn(n,n)); % Random orthonormal basis
                                            V{j,1}=W{j,1}(:,1:k{j,1});
                                        end
                                end
    if nargin==3 && isfield(Opt,'Phi'), Phi=Opt.Phi; 
                                else
                                      Phi=cell(S,S);
                                        for i=1:S, for j=1:S,
                                            Phi{i,j}=(randn(k{j},k{i})); 
                                        end, end      
                                end
          
%% [3] Constrained Optimization
%     Search over V{i}, Phi{i,j} subject to Vi'Vi=eye(ki) and 
%     Sum[p_ij F_ij L_ij]=Vi Vi',    

    %% (3-1) Compute Psi_F, Psi_FkF,  and xi=R_Psi_FkF   
        Psi_F=[]; Psi_FkF=[]; 
        for i=1:S
            tmp1=[]; tmp2=[];
                for j=1:S, 
                    tmp1=[tmp1 P(i,j)*F{i,j}]; 
                    tmp2=[tmp2 P(i,j)*kron(F{i,j},F{i,j})]; 
                end
            Psi_F=[Psi_F;tmp1]; Psi_FkF=[Psi_FkF;tmp2];
        end
        R_Psi_F=max(abs(eig(Psi_F))); R_Psi_FkF=max(abs(eig(Psi_FkF)));
        xi=R_Psi_FkF; 
    %% (3-2) vectorize the parameters
        vecPhi=[]; for i=1:S, for j=1:S, vecPhi=[vecPhi;vec(Phi{i,j})]; end, end
        vecV=[]; for i=1:S, vecV=[vecV;vec(V{i})]; end
        par0=[vecPhi;vecV]; % initial parameter vector.
    
    %% (3-3) Index matrices  KKSbegin and KKSend for identifying 
    %%      Psi{i,j} from vecPhi
    %%      vec(Phi{i,j}) = par0 ( KKSbegin(i,j):KKSend(i,j) )
        KK=[]; 
        for i=1:S, for j=1:S,
            KK(i,j)=k{i}*k{j}; % dimension of vec(Phi{i,j})
        end; end
        
        tmp=vec(KK');
        KKSendv=[];
        for i=1:S^2, KKSendv(i)=sum(tmp(1:i)); end
            
        KKSend=reshape(KKSendv,S,S)'; 
            vKKSendt=vec(KKSend');
            vKKSbegint=[1;vKKSendt(1:end-1)+1];
        KKSbegin=reshape(vKKSbegint,S,S)';
        
    %% (3-4) Optimization 
         options=optimset('Algorithm','interior-point','Display','iter','MaxFunEvals',200000,'MaxIter',2000,'DerivativeCheck','on',...
                           'LargeScale','on','TolFun',1e-8,'TolX',1e-8,'Diagnostics','off');
         [par,fval,exitflag] = fmincon(@(par) Find_Min_R_Psi_LkL_Q(par,n,S,k,KKSbegin,KKSend,P),par0,[],[],[],[],[],[],...
                                       @(par) Find_Min_R_Psi_LkL_NL(par,n,S,k,KKSbegin,KKSend,P,F),options);      
         [R_BarPsi_LkL,L,Phi,V,BarPsi_LkL]=Find_Min_R_Psi_LkL_Q(par,n,S,k,KKSbegin,KKSend,P); % Output
              
%% [4] OutPut       
	%% BarPsi_L, FkLt and PhitkF
        LtkF=cell(S,S); PhitkF=cell(S,S);
            for i=1:S, for j=1:S
            LtkF{i,j}=kron(L{i,j}',F{i,j}); 
            PhitkF{i,j}=kron(Phi{i,j}',F{i,j});
            end, end

        BarPsi_L=[]; Psi_LtkF=[]; Psi_PhitkF=[];
            for i=1:S
            tmp1=[]; tmp2=[]; tmp3=[];
                for j=1:S, 
                    tmp1=[tmp1 P(j,i)*L{j,i}]; 
                    tmp2=[tmp2 P(i,j)*LtkF{i,j}];        
                    tmp3=[tmp3 P(i,j)*PhitkF{i,j}];        
                end
            BarPsi_L=[BarPsi_L;tmp1];    
            Psi_LtkF=[Psi_LtkF;tmp2]; 
            Psi_PhitkF=[Psi_PhitkF;tmp3]; 
            end
        R_BarPsi_L=max(abs(eig(BarPsi_L))); 
        R_Psi_LtkF=max(abs(eig(Psi_LtkF))); 
        R_Psi_PhitkF=max(abs(eig(Psi_PhitkF))); 
        
    %% Print out
LambdaMin=L;
varargout{1}=V;
varargout{2}=Phi;
varargout{3}=k;
varargout{4}=R_BarPsi_LkL;
varargout{5}=R_BarPsi_L;
varargout{6}=R_Psi_FkF;
varargout{7}=R_Psi_F;
varargout{8}=Psi_LtkF;
    
        disp('**** Choice of k{i}')
            disp(k')
        disp('**** F : R_Psi_F R_Psi_FkF=xi ')
            disp([R_Psi_F R_Psi_FkF ])
    
        disp('**** L : R_BarPsi_L R_BarPsi_LkL 1/xi : Confirm R_BarPsi_LkL >= 1/xi')
            disp([R_BarPsi_L R_BarPsi_LkL 1/xi])
      
        disp('****  Confirm that Psi_LtkF has a unit eigenvalue: The absolute')
        disp('      value of the eigenvalues are:')
            disp(abs(eig(Psi_LtkF))')

