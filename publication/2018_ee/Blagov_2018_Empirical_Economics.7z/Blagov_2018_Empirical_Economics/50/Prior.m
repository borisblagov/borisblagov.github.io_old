%% Parameters
% param = [mu sigma distribution];
% where 1 is for Beta; 2 is for Gamma; 3 is for IGamma; 4 is for Normal; 11 is for
% Point Mass Beta; 12 is for PM Gamma; 13 for PM IGamma; 14 for PM Normal
ppos = 0; ppos = ppos+1; % Parameter position

% Probabilities
p11 = [0.85 0.05 1];   p11_pos = ppos; ppos = ppos+1; parnames=char('$p_{11}$');
p22 = [0.85 0.05 1];   p22_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$p_{22}$');


% Structural parameters
beta  = [0.99 0 11];    beta_pos = ppos; ppos = ppos+1;  parnames=char(parnames,'$\beta$');  % Discount factor    
phi   = [2 1 2];        phi_pos = ppos; ppos = ppos+1;   parnames=char(parnames,'$\varphi$');  % Labour supply parameter
theta = [0.75 0.10 1];  theta_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\theta$');  % Calvo parameter 
alpha = [0.6 0 11];     alpha_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\alpha$');  % Degree of openness
sigma = [1 1 2];        sigma_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\sigma$');  % Coefficient of relative risk aversion. 1/sigma:elast. of intert. substitution 
eta   = [2 1 2];        eta_pos = ppos; ppos = ppos+1;   parnames=char(parnames,'$\eta$');  % Elasticity of substitution b/n H and F goods

% Autoregressive coefficients
rho_a     = [0.85 0.15 1]; rho_a_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\rho_a$'); % From E-DSGE posterior
rho_mc    = [0.85 0.15 1]; rho_mc_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\rho_{\mu}$'); % From E-DSGE posterior 
rho_nu    = [0.85 0.15 1]; rho_nu_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\rho_{\nu}$');% From E-DSGE posterior
rho_rp    = [0.85 0.15 1]; rho_rp_pos = ppos; ppos = ppos+1; parnames=char(parnames,'$\rho_{\rp}$');  

% Standard deviation of the exogenous shocks
sig_mc    = [2 1 3];   parnames=char(parnames,'$\sigma_{\mu}$');  sig_mc_pos = ppos; ppos = ppos+1;  
sig_a     = [2 1 3];   parnames=char(parnames,'$\sigma_a$');   sig_a_pos = ppos; ppos = ppos+1;   
sig_nu    = [2 1 3];   parnames=char(parnames,'$\sigma_{\nu}$');  sig_nu_pos = ppos; ppos = ppos+1; 
sig_rp    = [2 1 3];   parnames=char(parnames,'$\sigma_{\rp}$');  sig_rp_pos = ppos; ppos = ppos+1; 
sig_ystar = [1 1 13];  parnames=char(parnames,'$\sigma_{y^*}$');   sig_ystar_pos = ppos; ppos = ppos+1;   % estimated from the VAR
sig_pistar= [1 1 13];  parnames=char(parnames,'$\sigma_{\pi^*}$');  sig_pistar_pos = ppos; ppos = ppos+1;   % estimated from the VAR
sig_istar = [1 1 13];  parnames=char(parnames,'$\sigma_{i^*}$');   sig_istar_pos = ppos; %ppos = ppos+1;   % estimated from the VAR


% Creating the information matrix
info_mat = zeros(ppos,3);
info_mat2 = zeros(ppos,3);
info_mat(p11_pos,:) = p11;     % 1
info_mat(p22_pos,:) = p22;     % 2
info_mat(beta_pos,:) = beta;   % 3
info_mat(phi_pos,:) = phi;     % 4
info_mat(theta_pos,:) = theta; % 5 
info_mat(alpha_pos,:) = alpha; % 6    
info_mat(sigma_pos,:) = sigma; % 7
info_mat(eta_pos,:) = eta;     % 8

info_mat(rho_a_pos,:) = rho_a;   % 9
info_mat(rho_mc_pos,:) = rho_mc; % 10
info_mat(rho_nu_pos,:) = rho_nu; % 11
info_mat(rho_rp_pos,:) = rho_nu; % 12

info_mat(sig_a_pos,:) = sig_a;      % 13  
info_mat(sig_mc_pos,:) = sig_mc;    % 14
info_mat(sig_nu_pos,:) = sig_nu;    % 15
info_mat(sig_rp_pos,:) = sig_nu;    % 16
info_mat(sig_ystar_pos,:) = sig_ystar;  % 17
info_mat(sig_pistar_pos,:) = sig_pistar;% 18
info_mat(sig_istar_pos,:) = sig_istar;  % 19

P = [info_mat(1,1) 1-info_mat(2,1);
    1-info_mat(1,1) info_mat(2,1)];  %P_{ij} = Prob(S_t = j|S_{t-1}) = i) <==> P_21= Prob of coming to State 2 from 1 (1-p11);
