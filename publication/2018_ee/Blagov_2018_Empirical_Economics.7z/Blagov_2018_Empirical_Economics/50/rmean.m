function [Out_mat] = rmean(In_mat,DIM)
% Calculates the recursive mean of a MCMC chain (In_mat) along the dimension DIM. If DIM = 2,
% the recursive mean will be calculated along the horizontal dimension and along the
% vertical otherwise. 
% Written by: Boris Blagov

if DIM ~= 2
    np = size(In_mat,2);
    Nsim = size(In_mat,1);
    In_mat = In_mat';
else
    np = size(In_mat,1);
    Nsim = size(In_mat,2);
end

Out_mat = zeros(np,Nsim);
for il=1:Nsim
    Out_mat(:,il) = mean(In_mat(:,1:il),2);
end

if DIM~=2
    Out_mat = Out_mat';
end


