function Out_cell = vec2cell(in_vec, PM_cell, ndxLam_c);
global nst ndxSwitch

Out_cell=PM_cell;
for ii = 1:length(ndxLam_c)
    Out_cell{ii}(ndxSwitch{1})=in_vec(ndxLam_c{1});
    Out_cell{ii}(ndxSwitch{ii})=in_vec(ndxLam_c{ii});
end
if nst == 4
    Out_cell{4}(ndxSwitch{1})=in_vec(ndxLam_c{1});
    Out_cell{4}(ndxSwitch{4})=[Out_cell{2}(ndxSwitch{2}); Out_cell{3}(ndxSwitch{3})];
end