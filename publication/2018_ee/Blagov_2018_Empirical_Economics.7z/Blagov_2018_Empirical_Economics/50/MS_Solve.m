function [OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems,termK,IRS,Variables_sct,CR_cell] = MS_Solve(theta_cell)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global nst p11_pos p22_pos q11_pos q22_pos beta_pos phi_pos thetaH_pos alpha_pos sigma_pos eta_pos rho_a_pos...
    rho_muF_pos rho_nu_pos sig_muF_pos sig_muH_pos sig_a_pos sig_nu_pos sig_ystar_pos sig_pistar_pos...
    sig_istar_pos rho_drp_pos sig_drp_pos deltaH_pos deltaF_pos ksi_pos...
    thetaF_pos rho_muH_pos c_ystar_1_pos c_pistar_2_pos c_istar_3_pos...
    mu_y_pos mu_c_pos mu_pi_pos mu_i_pos mu_ys_pos mu_pis_pos mu_is_pos...
    R_y_pos R_c_pos R_pi_pos R_i_pos R_ys_pos R_pis_pos R_is_pos
npts=20;
Problems=struct('FCC',[0],'Det',[0]);
% lastwarn('');
% sing_chk=0;
% warn1='MATLAB:illConditionedMatrix';
% warn2='MATLAB:nearlySingularMatrix';

p11   = theta_cell{1}(p11_pos);    % Probability of staying in state 1
p22   = theta_cell{1}(p22_pos);    % Probability of stayin in state 2
p12   = 1 - p11;
p21   = 1 - p22;

P = [p11 p12;
     p21 p22]; %P_{ij} = Prob(S_t=j |S_{t-1}) = i) <==> P_21= Prob of coming to State 1 from 2 (1-p22);
PS = P;
if nst == 4
    q11   = theta_cell{1}(q11_pos);    % Probability of staying in state 1
    q22   = theta_cell{1}(q22_pos);    % Probability of stayin in state 2
    q12   = 1 - q11;
    q21   = 1 - q22;
    Q = [q11 q12;
    q21 q22]; %P_{ij} = Prob(S_t=j |S_{t-1}) = i) <==> P_21= Prob of coming to State 1 from 2 (1-p22);
    PS = kron(P,Q);
end

 
% if find(cell2mat(ndxSwitch)==sigma_pos)
%     nst2=1;
% else
%     nst2=1;
% end
nst2=nst;
% Declaration of cells
A_cell = cell(nst,nst2);
B_cell = cell(nst,1);
C_cell = cell(nst,1);
CR_cell= cell(nst,1);
Q_cell = cell(nst,1);
sigma_t1=cell(nst2,1);
stderr_cell=cell(nst,1);
a1 = cell(nst,nst2);

for ii=1:nst
    %% Derived Parameters
    beta  = theta_cell{ii}(beta_pos);     %Discount factor
    phi   = theta_cell{ii}(phi_pos);      %Labour supply parameter
    thetaH = theta_cell{ii}(thetaH_pos);    %Calvo parameter 
    thetaF = theta_cell{ii}(thetaF_pos);
    alpha = theta_cell{ii}(alpha_pos);    %Degree of openness
    sigma = theta_cell{ii}(sigma_pos);
    eta   = theta_cell{ii}(eta_pos);      %Elasticity of substitution b/n H and F goods
    deltaH = theta_cell{ii}(deltaH_pos);
    deltaF = theta_cell{ii}(deltaF_pos);
    ksi    = theta_cell{ii}(ksi_pos);

    rho_a   = theta_cell{ii}(rho_a_pos); 
    rho_muF = theta_cell{ii}(rho_muF_pos);
    rho_muH = theta_cell{ii}(rho_muH_pos);
    rho_nu  = theta_cell{ii}(rho_nu_pos);
    rho_drp  = theta_cell{ii}(rho_drp_pos);
    c_ystar_1 = theta_cell{ii}(c_ystar_1_pos);
    c_pistar_2 = theta_cell{ii}(c_pistar_2_pos);
    c_istar_3 = theta_cell{ii}(c_istar_3_pos);
    
    sig_a = theta_cell{ii}(sig_a_pos);
    sig_nu = theta_cell{ii}(sig_nu_pos);
    sig_muF = theta_cell{ii}(sig_muF_pos);
    sig_muH = theta_cell{ii}(sig_muH_pos);
    sig_drp = theta_cell{ii}(sig_drp_pos);
    sig_ystar = theta_cell{ii}(sig_ystar_pos);    
    sig_pistar= theta_cell{ii}(sig_pistar_pos);    
    sig_istar = theta_cell{ii}(sig_istar_pos); 

    lambdaH=(1-thetaH)*(1-beta*thetaH)/thetaH;
    lambdaF=(1-thetaF)*(1-beta*thetaF)/thetaF;
    for jj=1:nst2
        sigma_t1{jj,1} = theta_cell{jj}(sigma_pos);
    end
%% Variables    
% Variables - not needed unless you want to plot IRs
nvar=1; % Endog. vars
xvar=1; % Exog. vars

    c = nvar;       nvar = nvar+1; Nvar_sct.c = c; VarNames=char('Consumption');
    y = nvar;       nvar = nvar+1; Nvar_sct.y = y; VarNames=char(VarNames,'Output');
    i = nvar;       nvar = nvar+1; Nvar_sct.i = i; VarNames=char(VarNames,'Interest Rate'); 
    q = nvar;       nvar = nvar+1; Nvar_sct.q = q; VarNames=char(VarNames,'Real Exchange Rate'); 
    s = nvar;       nvar = nvar+1; Nvar_sct.s = s; VarNames=char(VarNames,'Terms of Trade');
    psi = nvar;     nvar = nvar+1; Nvar_sct.psi = psi; VarNames=char(VarNames,'LOOP');
    pi = nvar;      nvar = nvar+1; Nvar_sct.pi = pi;    VarNames=char(VarNames,'Inflation'); 
    piH = nvar;     nvar = nvar+1; Nvar_sct.piH = piH;   VarNames=char(VarNames,'Inflation Home Goods'); 
    piF = nvar;     nvar = nvar+1; Nvar_sct.piF = piF;   VarNames=char(VarNames,'Inflation Foreign Goods');
    mc = nvar;      nvar = nvar+1; Nvar_sct.mc = mc;     VarNames=char(VarNames,'Marginal Cost');
    d = nvar;       nvar = nvar+1; Nvar_sct.d = d;       VarNames=char(VarNames,'Net FA Position');
    ystar_e = nvar; nvar = nvar+1; Nvar_sct.yst = ystar_e;   VarNames=char(VarNames,'World Output');
    pistar_e = nvar;nvar = nvar+1; Nvar_sct.pist = pistar_e;  VarNames=char(VarNames,'World Inflation'); 
    istar_e = nvar; nvar = nvar+1; Nvar_sct.ist = istar_e;   VarNames=char(VarNames,'World Interest rate');
    nvar = nvar-1;

    eps_ystar = xvar;   xvar = xvar+1;  Xvar_sct.eyst = eps_ystar;   VarNames=char(VarNames,'World Output Shock');
    eps_pistar= xvar;   xvar = xvar+1;  Xvar_sct.epist = eps_pistar;   VarNames=char(VarNames,'World Cost-Push Shock');
    eps_istar = xvar;   xvar = xvar+1;  Xvar_sct.eist = eps_istar;    VarNames=char(VarNames,'World MP Shock');
    muF   = xvar;   xvar = xvar+1;      Xvar_sct.muF = muF;      VarNames=char(VarNames,'Import Cost-Push Shock');
    muH   = xvar;   xvar = xvar+1;      Xvar_sct.muH = muH;      VarNames=char(VarNames,'Domestic Cost-Push Shock');
    a = xvar;       xvar = xvar+1;      Xvar_sct.a = a;          VarNames=char(VarNames,'Technology Shock');
    nu = xvar;      xvar = xvar+1;      Xvar_sct.nu = nu;        VarNames=char(VarNames,'Preference Shock');
    drp = xvar;     xvar = xvar+1;      Xvar_sct.phi = drp;      VarNames=char(VarNames,'Risk Premium Shock');
    xvar = xvar-1;
    
    Variables_sct.Nvar_sct = Nvar_sct;
    Variables_sct.Xvar_sct = Xvar_sct;
    Variables_sct.VarNames = VarNames;
    Variables_sct.nvar = nvar;
    Variables_sct.xvar = xvar;
    
    b1 = zeros(nvar,nvar);
    
    b2 = zeros(nvar,nvar);
    c1 = zeros(nvar,xvar);
    R = zeros (xvar,xvar);

    %% Model Equations
    eqn = 0;
    
    for jj = 1:nst2
        a1{ii,jj} = zeros(nvar,nvar);
        if jj==1
            eqnrec=eqn;
        else
            eqn=eqnrec;
        end
        
        % Euler 
        eqn = eqn+1;
        b1(eqn,c) = 1;
        b1(eqn,i) = 1/sigma;
        a1{ii,jj}(eqn,c) = sigma_t1{jj,1}/sigma;
        a1{ii,jj}(eqn,pi)= 1/sigma;    
        c1(eqn,nu)= (1-rho_nu)/sigma;        
        
       
        % Domestic Price Inflation
        eqn = eqn+1;
        b1(eqn,piH) = (1+beta*deltaH);
        b1(eqn,mc)  = -lambdaH;
        a1{ii,jj}(eqn,piH) = beta;
        b2(eqn,piH) = deltaH;
        c1(eqn,muH) = 1;
    
        % Import Price Inflation
        eqn = eqn+1;
        b1(eqn,piF) = (1+beta*deltaF);
        b1(eqn,psi)  = -lambdaF;
        a1{ii,jj}(eqn,piF) = beta;
        b2(eqn,piF) = deltaF;
        c1(eqn,muF) = 1;
    end
    
    % Market Clearing
    eqn = eqn+1;
    b1(eqn,y) = 1;
    b1(eqn,c) = -(1-alpha);
    b1(eqn,s) = -alpha*eta;
    b1(eqn,q) = -alpha*eta;
    b1(eqn,ystar_e) = -alpha;
    
    % Law of One Price
    eqn = eqn+1;
    b1(eqn,psi) = 1;
    b1(eqn,q) = -1;
    b1(eqn,s) = (1-alpha);
    
    % Terms of Trade
    eqn = eqn+1;
    b1(eqn,s) = 1;
    b1(eqn,piF) = -1;
    b1(eqn,piH) = 1;
    b2(eqn,s)   = 1;
    
    % Change in NER
    eqn = eqn+1;
    b1(eqn,q) = -1;
    b2(eqn,q) = -1;
    b1(eqn,pi)= -1;
    b1(eqn,pistar_e) = 1;
        
    % Marginal cost
    eqn = eqn+1;
    b1(eqn,mc)  = 1;
    b1(eqn,y) = -phi;
    b1(eqn,s) = -alpha;
    b1(eqn,c) = -sigma;
    c1(eqn,a) = -(1+phi);
    
        
    % Domestic CPI Inflation
    eqn = eqn+1;
    b1(eqn,pi) = 1;
    b1(eqn,piH) = -(1-alpha);
    b1(eqn,piF) = -alpha;
    
    % Foreign Asset BC
    eqn = eqn+ 1;
    b1(eqn,c) = 1;
    b1(eqn,d) = 1;
    b1(eqn,q) = alpha;
    b1(eqn,s) = alpha^2;
    b1(eqn,y) = -1;
    b2(eqn,d)= 1/beta;

    % Interest rate reaction function
    eqn = eqn+1;
    b1(eqn,i) = 1;
    b1(eqn,istar_e) = -1;
    b1(eqn,d) = ksi;
    c1(eqn,drp) = -1;
    
    % World equations:
    eqn = eqn+1;
    b1(eqn,ystar_e) = 1; 
    b2(eqn,ystar_e) = c_ystar_1;
    c1(eqn,eps_ystar) = 1;
    
    eqn = eqn+1;
    b1(eqn,pistar_e) = 1; 
    b2(eqn,pistar_e)   = c_pistar_2;
    c1(eqn,eps_pistar) = 1;
    
    eqn = eqn+1;
    b1(eqn,istar_e) = 1; 
    b2(eqn,istar_e)   = c_istar_3; 
    c1(eqn,eps_istar) = 1;

    % Autoregressive processes
    R(eps_ystar,eps_ystar)  = 0;
    R(eps_pistar,eps_pistar) = 0;
    R(eps_istar,eps_istar)  = 0;
    
    R(a,a)         = rho_a;
    R(nu,nu)       = rho_nu;
    R(muF,muF)     = rho_muF;
    R(muH,muH)     = rho_muH;
    R(drp,drp)     = rho_drp;
    
    for jj=1:nst2
     A_cell{ii,jj} = b1\a1{ii,jj};
    end
     B_cell{ii} = b1\b2;
     C_cell{ii} = b1\c1;
     CR_cell{ii} = R;
      
     stderr_cell{ii} = ones(xvar,1);   % cell for the variance of the structural shocks
     stderr_cell{ii}(a)      = sig_a;
     stderr_cell{ii}(muF)    = sig_muF;
     stderr_cell{ii}(muF)    = sig_muH;
     stderr_cell{ii}(nu)     = sig_nu;
     stderr_cell{ii}(drp)     = sig_drp;
     stderr_cell{ii}(eps_ystar)  = sig_ystar;
     stderr_cell{ii}(eps_pistar) = sig_pistar;
     stderr_cell{ii}(eps_istar)  = sig_istar;

end

if nst~= 1
    sig_names = {'one', 'two'}; %this has to be entered manually, unfrotunately
    sigma_struct  = cell2struct(stderr_cell, sig_names,1);
    Tolk = 1000;   
    Opt = struct('maxK',[Tolk],'IRT',[npts],'IRsigma',sigma_struct);
    crit=1.0e-15;
    [OmegaK,GammaK,FK,termK,R_BarPsi_OKkOK,R_Psi_FKkFK,IRS] = msres_r(PS,A_cell,B_cell,C_cell,CR_cell,Opt);
    if R_BarPsi_OKkOK-crit<=1
        if R_Psi_FKkFK-crit>1
            disp('The model may be indeterminate');
            Problems.Det = 1;
        end
    else
        Problems.FCC = 1;
        disp('The Forward Convergence Criterion does not hold, discard the results');
        disp(R_BarPsi_OKkOK)
    end
else
    Tolk = 1000;
    Opt = struct('maxK',[Tolk],'dispon',[1]);
    [OmegaK,Geigk,GammaK,termK,Problems]=fmrss(b1,a1{1},b2,c1,R,Opt);
end

%% Preparing the matrices for the Kalman filter
% Transition equation H matrix
H=zeros(7,nvar);         hpos=1;
H(hpos,y)       = 1;     hpos=hpos+1;  
H(hpos,c)       = 1;     hpos=hpos+1; 
H(hpos,pi)      = 1;     hpos=hpos+1;    
H(hpos,i)       = 1;     hpos=hpos+1; 
H(hpos,ystar_e)  = 1;     hpos=hpos+1; 
H(hpos,pistar_e) = 1;     hpos=hpos+1; 
H(hpos,istar_e)  = 1;                  

% Transition equation mean matrix
mu_cell = cell(nst,1);
for bi = 1:nst
    mu_cell{bi} = zeros(hpos,1);
    if isempty(mu_y_pos)~=1;     mu_cell{bi}(1) = theta_cell{bi}(mu_y_pos);     end
    if isempty(mu_c_pos)~=1;     mu_cell{bi}(2) = theta_cell{bi}(mu_c_pos);     end 
    if isempty(mu_pi_pos)~=1;    mu_cell{bi}(3) = theta_cell{bi}(mu_pi_pos);    end        
    if isempty(mu_i_pos)~=1;     mu_cell{bi}(4) = theta_cell{bi}(mu_i_pos);     end
    if isempty(mu_ys_pos)~=1;    mu_cell{bi}(5) = theta_cell{bi}(mu_ys_pos);    end    
    if isempty(mu_pis_pos)~=1;   mu_cell{bi}(6) = theta_cell{bi}(mu_pis_pos);   end
    if isempty(mu_is_pos)~=1;    mu_cell{bi}(7) = theta_cell{bi}(mu_is_pos);    end
end

% Measurement Errors
R_mat = zeros(hpos,hpos);
if isempty(R_y_pos)~=1;     R_mat(1,1) = theta_cell{1}(R_y_pos);    end
if isempty(R_c_pos)~=1;     R_mat(2,2) = theta_cell{1}(R_c_pos);    end
if isempty(R_pi_pos)~=1;    R_mat(3,3) = theta_cell{1}(R_pi_pos);   end
if isempty(R_i_pos)~=1;     R_mat(4,4) = theta_cell{1}(R_i_pos);    end
if isempty(R_ys_pos)~=1;    R_mat(5,5) = theta_cell{1}(R_ys_pos);   end
if isempty(R_pis_pos)~=1;   R_mat(6,6) = theta_cell{1}(R_pis_pos);  end
if isempty(R_is_pos)~=1;    R_mat(7,7) = theta_cell{1}(R_is_pos);   end
R_mat = R_mat.^2;

% Variance-cov matrix of the shocks
for ci = 1:nst
Q_cell{ci}=eye(xvar);                 % The variance of the structural shocks..
Q_cell{ci}(eps_ystar,eps_ystar)   = theta_cell{ci}(sig_ystar_pos);                  
Q_cell{ci}(eps_pistar,eps_pistar) = theta_cell{ci}(sig_pistar_pos);                     
Q_cell{ci}(eps_istar,eps_istar)   = theta_cell{ci}(sig_istar_pos);   
Q_cell{ci}(a,a)           = theta_cell{ci}(sig_a_pos);        
Q_cell{ci}(nu,nu)         = theta_cell{ci}(sig_nu_pos);
Q_cell{ci}(drp,drp)         = theta_cell{ci}(sig_drp_pos);
Q_cell{ci}(muF,muF)     = theta_cell{ci}(sig_muF_pos);
Q_cell{ci}(muH,muH)     = theta_cell{ci}(sig_muH_pos);
Q_cell{ci} = Q_cell{ci}.^2;
end
% 



% IRS_cell=cell(nst,1);
% IRS_cell = IRS;
% for jj=1:xvar:nvar*xvar
%     IRS_cell{1}(:,jj)=IRS(
% end

% R_mat = ones(min(size(H)),min(size(H)));
