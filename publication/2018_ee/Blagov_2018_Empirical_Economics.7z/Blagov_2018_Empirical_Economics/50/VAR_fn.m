function [betavar] = VAR(xdata)

nlags = 1;
nstep = 20;      
for sh=1:3;
    [nobs,nvars] = size(xdata); 
    exo=ones(nobs-nlags,1);
    
    [responses,betavar] = estimateIRFmod(xdata,exo,nlags,nstep,nobs,nvars,sh);
end