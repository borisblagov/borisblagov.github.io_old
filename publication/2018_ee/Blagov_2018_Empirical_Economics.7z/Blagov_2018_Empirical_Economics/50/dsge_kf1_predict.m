function [likv,osaf,Problems,xm,Qa]=dsge_kf1_predict(ym,A,B,C,D,Q)
% PURPOSE: performs Kalman Filter in a linearised DSGE model
%          differs from dsge_kf because produces also 1st and 2nd moments of 
%          latent variables. 
% -----------------------------------------------------
% USAGE: [lnlv,xm,Qa]=dsge_kf1(ym,A,B,C,D)
% where: 
%       ym = (nt x ny) matrix of observables
%       A = (nx x nx) transition matrix
%       B = (nx x nx2) loading matrix of orthogonalised state eq std errors
%       C = (ny x nx) matrix in obs eq
%       D = loading matrix of meas errors
% -----------------------------------------------------
% NOTES: no dimension checks imposed , 
% first version: 21/09/2007
% -----------------------------------------------------
% RETURNS: 
%         lnlv = (nt x 1) vector with log likelihoods of each observation
%         xm   = (nt x nx) matrix with means of filtered distribution
%         Qa   = (nx x nx x nt) array with covariance matrices of filtered
%                 distributions
% -----------------------------------------------------
% written by:
% Gianni Amisano, Dept of Economics
% University of Brescia
% amisano@eco.unibs.it
lastwarn('');
Problems = 0;
warn1='MATLAB:illConditionedMatrix';

nt=size(ym,1);
ny=size(ym,2);
nx=size(A,1);
nx2=size(B,2);
nx1=nx-nx2;
Omega=D*D';
osaf = zeros(ny,nt)';
%initialise from steady state distribution of the states and transform
x0=zeros(nx,1);
Q0=reshape(inv(eye(nx^2)-kron(A,A))*reshape(B*B',nx^2,1),nx,nx); %%
lnlv=zeros(nt,1);
xm=zeros(nt,nx);
Qa=zeros(nx,nx,nt);
for it=1:nt
    y1=ym(it,:)';
    x10=A*x0;
    Q10=A*Q0*A'+B*Q*B';
    Q10=(Q10+Q10')/2; % robustness check
    k1=Q10*C';
    h1=inv(C*k1+Omega);
    kk1=k1*h1;
    Q1=Q10-kk1*k1';
    e1=y1-C*x10;
    osaf(it,:) = C*x10;
    lnlv(it)=-0.5*(ny*log(2*pi)-log(det(h1))+(e1')*h1*e1); %
    x1=x10+kk1*e1;
    xm(it,:)=x1';
    Qa(:,:,it)=Q1;
    x0=x1;
    Q0=Q1;
    [msg, msgid] = lastwarn;
    if strcmp(msgid,warn1)==1
        Problems = 1;        
        likv = -100000000;
        return
    end
end
j=2;
likv = sum(lnlv(j:end,1));