function [val] = v_probVec(ev, he,k)
%calculates the value of the conditional density in eq. (5.21), page 103.,
%i.e. f(y_t | S_t, S_{t-1}, y_{t-1})
val=(1/(((2*pi)^(k/2))*sqrt(det(he))))*exp(-0.5*(ev'/he)*ev); 