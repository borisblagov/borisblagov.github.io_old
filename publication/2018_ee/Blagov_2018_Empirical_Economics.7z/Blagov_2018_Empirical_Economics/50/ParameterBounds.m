function [Rm_cell] = ParameterBounds(info_cell)
nst=size(info_cell,1);
np = length(info_cell{1});
Rm_cell = cell(nst,1);

for ii=1:nst
    Rm_cell{ii} = zeros(np, 2);
    
    ndxBeta = find (info_cell{ii}(:,3)==1);
    muB = info_cell{ii}(ndxBeta,1);
    stB = info_cell{ii}(ndxBeta,2);
    a=muB./(1-muB);
    beta = (a./(a+1).^2 - stB.^2)./((a+1).*stB.^2);
    alpha = beta.*a;
    Rm_cell{ii}(ndxBeta,:) = [alpha beta];
    [M,V] = betastat(alpha, beta);
    if sum(isnan(M))~= 0 || sum(isnan(V))~= 0
        disp(' ')
        disp(' ')
        disp('Error: Some parameters in the Beta distributed coefficients are out of bounds.')
        disp(' ')
        disp(' ')
        break
    end
    
    ndxGamma = find (info_cell{ii}(:,3)==2);
    muG = info_cell{ii}(ndxGamma,1);
    stG = info_cell{ii}(ndxGamma,2);
    alpha= (muG.^2)./stG.^2;
    beta = (stG.^2)./muG;
    Rm_cell{ii}(ndxGamma,:) = [alpha beta];
    [M,V] = gamstat(alpha,beta);
    if sum(info_cell{ii}(ndxGamma,1)==M)~=length(M) || sum(info_cell{ii}(ndxGamma,2)==sqrt(V))~=length(V)
        disp(' ')
        disp(' ')
        disp('Error: Check the Gamma distributed bounds.')
        disp(' ')
        disp(' ')
%         break
    end
    
    ndxIGamma = find (info_cell{ii}(:,3)==3);
    muIG = info_cell{ii}(ndxIGamma,1);
    alpha = 2*ones(length(muIG),1);
    beta = muIG;
    Rm_cell{ii}(ndxIGamma,:) = [alpha beta];
    
    ndxGauss = find (info_cell{ii}(:,3)==4);
    alpha = info_cell{ii}(ndxGauss,1);
    beta = info_cell{ii}(ndxGauss,2);
    Rm_cell{ii}(ndxGauss,:) = [alpha beta];
end

