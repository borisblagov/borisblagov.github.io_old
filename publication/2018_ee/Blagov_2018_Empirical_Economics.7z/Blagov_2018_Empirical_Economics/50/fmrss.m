function [Omegak,varargout]=fmrss(B1,A1,B2,C1,R,opt)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the code for the Forward Method of Recursive Substitution
% Refer to "The Forward Method as a Solution Refinement in Rational Expectations Models" by Cho and Moreno
% Witten by Seonghoon Cho, Aug 6, 2008
% Structural Model :      B1*x(t)=A1*E[x(t+1)|I(t)]+B2*x(t-1)+C1*z(t)
%                         z(t)=R*z(t-1)+e(t)
% Input     1. B1,A1,B2 : n by n coefficient matrices           
%              *** If there is no additional input, C1=eye(n), R=zeros(n,n) are assumed by default.
%           2. C1 : (Optional) coefficient to z(t), n by m  
%           3. R  : (Optional) VAR(1) coefficient matrix of z(1). n by m C1
%                    matrix must be declared z(t)=R*z(t-1)+e(t),
%           4. opt: (Optional: structure)
%              You may change the options specified below. To do so, you must specify C1 and R
%                   If there is no z(t), set C1=0 and R=0.
%                   If there is z(t) and R is zeros, specify n by m C1 and set R=0 (or R=zeros(m,m)).
%                   If there is z(t) and R is not zeros, specify a n by m
%                   C1 and m by m R matrices.
%               The following are the options
%                   opt.maxK :  maximal number of iteration. Default is maxK=1000
%                   opt.tolK :  convergence precision: Default is tolK=0.00001;
%                               The iteration stops if the maximum of elements of 
%                               (Omega_(k)-Omega(k-1)) and Gamma_k-Gamma(k-1) is smaller than 
%                               opt.TolK. 
%                   opt.dispon : display convergence results. (Default)
%                               Set opt.dispon=0 if you don't want to display convergence results. (Default)
%                               Set opt.dispon=1 otherwise.
% Forward Representation: x(t)=Mk*E[x(t+k)|I(t)]+Omegak*x(t-1)+Gammak*z(t)
% Output :  [Omegak,varargout]=fmrss(B1,A1,B2,C1,R,opt)
%           [Omegak,Geigk,Gammak,K,Mk,OmegaKK,GeigKK,GammaKK,MKK]=fmrss(B1,A1,B2,C1,R,opt)
%           Note 1. Omegak,Geigk,Gammak,Mk are the matrices at k=K where 
%                   K is the number of iteration at which FCC is met in the case of convergence, or
%                   K is maxK when they are not convergent.
%           Note 2. OmegaKK,GeigKK,GammaKK,MKK are the
%              stacked matrices where the k-th row corresponds to the transpose of
%              the vectorized matrix at k from k=1 through k=K.
%              For example, k-th row of OmegaKK = vec(Omegak)'
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Problems=struct('FCC',[0],'Det',[0]);
%[0] size of the matrix (n,m)
        n=size(B1,2); 
        if      nargin==3, m=n;          C1=eye(n); R=zeros(m,m);        
        elseif  nargin==4, m=size(C1,2);            R=zeros(m,m); 
        elseif  nargin>=5, m=size(C1,2);           
        end
        if C1==0, C1=zeros(n,1); end
        if R==0, R=zeros(m,m); end     
%[1] Transformation of the Structural Model      
        A=inv(B1)*A1; B=inv(B1)*B2; C=inv(B1)*C1;       
              
%[2] Option structure
        maxK=1000;  tolK=0.00001;   dispon=0;  % Default values
        if nargin==6,
        if isfield(opt,'maxK'), maxK=opt.maxK; end
        if isfield(opt,'tolK'), tolK=opt.tolK; end
        if isfield(opt,'dispon'), dispon=opt.dispon; end
        end

%[3] Define Sequences of Matrices with initial values and stop if the FCC is met.
FCC=1;
K=0;
while FCC>tolK
    K=K+1;    
    if K==1; 
        MK=A; OmegaK=B; GammaK=C; GeigK=eig(B); 
        FCC_Omega=1; FCC_Gamma=1;
    end
    if K>1;  
            % (1) Define matrices at k-1
            Mk_1=MK(:,n*(K-2)+1:n*(K-1));
            Omegak_1=OmegaK(:,n*(K-2)+1:n*(K-1));
            Gammak_1=GammaK(:,m*(K-2)+1:m*(K-1));
        
            % (2) Checking the Regularity condition before defining matrices at k
            Vk_1=(eye(n)-A*Omegak_1);                       
                if abs(det(Vk_1))<0.00000000000001,
                    error('The Regularity condition and therefore, the FCC is violated')
                    break; 
                end     
            % (3) Define matrices at k     
            Mk=inv(Vk_1)*A*Mk_1;
            Omegak=inv(Vk_1)*B;
            Gammak=inv(Vk_1)*(C+A*Gammak_1*R);
            Geigk=eig(Omegak);
                
            % (4) Stacking matrices
            MK=[MK Mk];
            OmegaK=[OmegaK Omegak];
            GammaK=[GammaK Gammak];
            GeigK=[GeigK Geigk];
            FCC_Omega=max(abs((Omegak(:)-Omegak_1(:)))); FCC_Gamma=max(abs((Gammak(:)-Gammak_1(:))));
    end
    FCC=max([FCC_Omega;FCC_Gamma]);
    if K==maxK, break; end
end

%[4] Display information regarding FCC
if dispon==1, 
    if K<maxK, 
%         disp('***** The Forward Solution exists: The Forward Convergence Criterion is met at K= *****') 
%         disp(      K)
    elseif K==maxK & FCC>tolK & FCC<=10*tolK , disp('***** The FCC may hold if maxK is set at a higher level******')
            Problems.Det = 1;
    elseif K==maxK & FCC>10*tolK, 
%         disp('***** The FCC is likely to be violated. Plot OmegaKK and GammaKK as follows'), 
%         disp('      figure(1), for i=1:n^2, subplot(2,2,i), plot(OmegaKK(:,i)); end    ')
%         disp('      figure(2), for i=1:n^2, subplot(2,2,i), plot(GammaKK(:,i)); end    ')
%         disp('***** If every elements are converging, set a higher maxK and run it again')
            Problems.FCC = 1;
    end
end

% Output =========================================================
varargout(1)={Geigk};
varargout(2)={Gammak};
varargout(3)={K};
varargout(4)={Problems};
% varargout(4)={Mk};

% vectorize the sequences of matrices and stack them in big matrices.
 if nargout>4,
        OmegaKK=reshape(OmegaK,n^2,K)';
        GammaKK=reshape(GammaK,n*m,K)';
        GeigKK=GeigK';
        MKK=reshape(MK,n^2,K)'; 
        
varargout(5)={OmegaKK};
varargout(6)={GeigKK};
varargout(7)={GammaKK};
varargout(8)={MKK};
 end