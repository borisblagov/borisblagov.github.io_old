function [OmegaK,varargout]=msres_r(P,A,B,C,R,Opt)
% This is a matlab code for implementing "Characterizing Markov-Switching Rational 
% Expectations Models". Written by Seonghoon Cho, October 11, 2011
% Extended to allow for swicthing in the coefficient matrix of z(t) by Boris Blagov
% Extended also to allow for different variances of the shocks by Boris Blagov
%
% For additional information, see "Characterizing Markov-Switching Rational 
% Expectations:Technical Guide".
% Definitions: x and z are n by 1 and m by 1 vectors of endogenous and 
%              exogenous variables, respectively. There are S regimes.
% Usage: Specify the input arguments 
%         P,A (required) 
%         B,C,R and other optional arguments (optional).
% The output arguments will be explained below.
% If a warning sign is not displayed after running this code, it means that
% your model is forward-convergent (That is, the forward solution(FS) exists.)
% If a warning sign is displayed, the model is likely to fail to satisfy
% the forward convergence condition. In this case, the code will automatically 
% display all the elements of Omega_k and Gamma_k for all regimes. 
% If all the elements converge slowly, then set a larger number to maxK. 
% But if any one of them explodes or osillates,
% the forward solution does not exist. 
% =========================================================================
% Model :  x(t)=E[A(s(t),s(t+1))x(t+1)|I(t)]+B(s(t))*x(t-1)+C(s(t))*z(t)
%               z(t)=R*z(t-1)+e(t)
%               where s(t) has S regimes, 1,...,S.
%  Solution: x(t)=Omega(s(t))*x(t-1)+Gamma(s(t))*z(t)
%   [1] Input arguments
%       [1-1] Required Input arguments
%           P   : S by S transition matrix where the ij-th element, 
%                 p_ij=Pr(s(t+1)=j|s(t)=i).
%           A   : S by S cell array such that A{i,j}=A(s(t)=i,s(t+1)=j).
%                 (If A=A(s(t)), then A is S by 1 cell array such that
%                   A{i,1}=A(s(t)=i).) size(A{i,j})=n by n
%       [1-2] Optional Input arguments
%           B   : S by 1 cell array such that B{i,1}=B(s(t)=i). 
%                   - Default: B=zeros(n,n);
%                   - If there is no x(t-1) in the model, set B=[]; 
%           C   : S by 1 cell array such that C{i,1}=C(s(t)=i).
%                   - size(C{i,1})=n by m.
%                   - Default: C{i,1}=eye(n) for all i, so m=n; 
%                   - If C is not present, set C=[];
%           R   : m by m VAR coefficient matrix of z(t)
%                   - Default: R=zeros(m,m);
%                   - If R is zeros, set R=[]; 
%           Opt : Other option-structure
%               Opt.maxK: maximum number of forward recursion: (Default:maxK=1000)
%                   Change this only if the code display a warning sign. 
%               Opt.Warning: Plot Omega_k and Gamma_k against K if k reaches maxK.
%                    (Default: Opt.Warning=1 : Display Warning)
%                   Set Opt.Warning=0 if do not want to display Warning
%                   sign.
%               Opt.tolK: Precision of Forward Convergence: The forward iteration stops 
%                   if the difference between the largest element of Omega and Gamma 
%                   in absolute value at k and k-1 is less than Opt.tolK.
%                   Default is 0.00001)
%               Opt.IRsigma : m by 1 (or 1 by m ) vector of standard errors of the
%                   structural shocks, e(t) used for generating IR functions. 
%                   Default : m by 1 vector of ones.
%               Opt.IRT: number of period for IR functions. (Default=20)
%               Opt.IRvs: 
%                   Default arrangement : first variable to m shocks, ..., 
%                   the last variable to m shocks. 
%                   Set Opt.IRvs=1 if users want to arrange IR function such that the
%                   n variables to the first shock, ..., n variables to the
%                   last shock. 
%   [2] Output arguments: [OmegaK,GammaK,FK,termK,R_BarPsi_OKkOK,R_Psi_FKkFK,BarPsi_OKkOK,Psi_FKkFK,IRS]
%       OmegaK  : S by 1 cell array such that OmegaK{i,1}=Omega_k(s(t)=i) at "k=termK". (See below for "termK".)
%       GammaK  : S by 1 cell array such that GammaK{i,1}=Gamma_k(s(t)=i) at "k=termK".
%       FK      : S by S cell array such that FK{i,j}=F_k(s(t)=i,s(t+1)=j) at "k=termK".
%       termK   : number of forward iteration. 
%                   If the FS exists, then termK < maxK and there will be no warning sign.
%                   If not, termK=maxK and a warning sign and a graph will be displayed.
%       R_BarPsi_OKkOK : Spectral Radius of n^2*S by n^2*S matrix, BarPsi_(kron(OmegaK,OmegaK)) 
%       R_Psi_FKkFK    : Spectral Radius of n^2*S by n^2*S matrix, Psi_(kron(FK,FK))
%       BarPsi_OKkOK   : BarPsi_(kron(OmegaK,OmegaK)) 
%       Psi_FKkFK      : Psi_(kron(FK,FK))
%       IRS     : S by 1 cell array where i-th element of IRS is the IR
%                 function of x(t) when s(t)=i. It is T by n*m where each column is 
%                 x(1)....x(n) to 1st shock,...  x(1)....x(n) to m-th shock 
% =========================================================================
    lastwarn('');
    WarnSing=0;
    warn1='MATLAB:nearlySingularMatrix';
    discard = 0;
% [0] Identify S (number of Regime), n (rows of A) and m (columns of C)
    S=size(P,1); 
    n=size(A{1,1},1);
    vecsig=cell(S,1);
    if size(A,2)==1, for i=1:S, for j=1:S, AA{i,j}=A{i,1}; end, end, A=AA; end
  
    if nargin==2, B=[]; C=[]; m=n;    R=zeros(m,m);           end
    if nargin==3,       C=[]; m=n;    R=zeros(m,m);           end
    if nargin>3, if isempty(C), m=n; else  m=size(C{1,1},2); end, end 
    if nargin==4,                     R=zeros(m,m);           end

% [1] Make B and R cell arrays if any one of them is not a cell array. 
    if isempty(B),      for j=1:S, B{j,1}=zeros(n,n);       end, end  
    if isempty(C),      for j=1:S, C{j,1}=eye(n,n);         end, end  
    if isempty(R),      for j=1:S, R=zeros(m);              end, end  
    
% [2] Option values  
    if nargin==6 && isfield(Opt,'maxK'), maxK=Opt.maxK; else maxK=1000; end
    if nargin==6 && isfield(Opt,'Warning'), Warning=Opt.Warning; else Warning=1; end
    if nargin==6 && isfield(Opt,'tolK'), tolK=Opt.tolK; else tolK=0.000001; end
    if nargin==6 && isfield(Opt,'IRsigma'),  vecsig = struct2cell(Opt.IRsigma); else 
        for i=1:S
            vecsig{i}=ones(1,m); 
        end 
    end
    if nargin==6 && isfield(Opt,'IRT'), T=Opt.IRT; else T=20; end
    if nargin==6 && isfield(Opt,'IRvs'), vs=Opt.IRvs; else vs=0; end
    
% [3] Defining OMEGA, GAMMA and F
    % Initial Omega(s(t)=i) and Gamma(s(t)=i) at k=1
        for i=1:S, for j=1:S 
            OMEGAK{1,i}=B{i};  
            GAMMAK{1,i}=C{i};
            FFK{1,i,j}=A{i,j};
        end, end
    
    % Fill out Xi, FFK, EFGAMMA, OMEGAK, GAMMAK
        k=0; FCC=1;
        while FCC>tolK
            k=k+1;   
            % (1) Xi{k,i}=eye(n)-E[A(s(t),s(t+1))*��_{k-1}(s(t+1)) | s(t)=i] and           
                for i=1:S, 
                    EAOmegaki=zeros(n,n); 
                        for j=1:S,                 
                            EAOmegaki =EAOmegaki +P(i,j)*A{i,j}*OMEGAK{k,j};
                        end
                    Xi{k,i}=eye(n)-EAOmegaki;
                end
            %  (2) FFK{k,i,j} =inv(Xi{k,i})*A{i,j} 
                for i=1:S, for j=1:S, FFK{k,i,j}=Xi{k,i}\A{i,j}; end, end
                    
            %   (3) EFGAMMA{k,i}=E[F_{k-1}(s(t),s(t+1))*��_{k-1}(s(t+1)) | s(t)=i]
                for i=1:S,
                    EFGammaki=zeros(n,m); 
                    for j=1:S, 
                        EFGammaki = EFGammaki +P(i,j)*FFK{k,i,j}*GAMMAK{k,j};
                    end
                    EFGAMMA{k,i}=EFGammaki; 
                end


            % (4) Compute ��_{k}(s(t)) and ��_{k}(s(t))
                FCC_OmegaS=[]; FCC_GammaS=[]; 
                for i=1:S 
                    OMEGAK{k+1,i}=Xi{k,i}\B{i};
                    GAMMAK{k+1,i}=Xi{k,i}\C{i} + EFGAMMA{k,i}*R{i};
                    FCC_OmegaS=[FCC_OmegaS;max(abs(OMEGAK{k+1,i}(:)-OMEGAK{k,i}(:)))];
                    FCC_GammaS=[FCC_GammaS;max(abs(GAMMAK{k+1,i}(:)-GAMMAK{k,i}(:)))]; 
                end
    
            FCC=max([FCC_OmegaS;FCC_GammaS]);
            if k==maxK, 
                if Warning==1, 
                disp('******* Warning: FCC may not hold. Take a look at the figure (101).')
                disp('******* Figure (101) plots all the elements of ')
                         disp('******* vec(Omega_k(s(t)=i) and vec(Gamma_k(s(t)=i) for all i against k.'),
                         disp('******* Rows are Omega_k, Gamma_k, Columns are 1,..,S regimes.')
                disp('******* If any one of elements does not converge as k gets larger, then the FCC does not hold.')
                disp('******* If all elements seem to converge, set maxK at a greater number and run the code again.')
                discard = 1;
                R_BarPsi_OKkOK = 1000;
                %                 sol_chk=1;
%                     figure(101),  
%                         for i=1:S, 
%                                 subplot(2,S,i)
%                                 OMEGAki=[]; for k=1:maxK, OMEGAki=[OMEGAki;(OMEGAK{k,i}(:))']; end, plot(OMEGAki)  
%                                 subplot(2,S,S+i)
%                                 GAMMAki=[]; for k=1:maxK, GAMMAki=[GAMMAki;(GAMMAK{k,i}(:))']; end, plot(GAMMAki)   
%                         end  
                end % end of Warning
            break; end  % End of k==maxK     
        end % end of "while".
    
% [4] Output Arguments  
    termK=k;   
 
    for i=1:S, OmegaK{i,1}=OMEGAK{end,i}; GammaK{i,1}=GAMMAK{end,i}; end
    for i=1:S, for j=1:S, FK{i,j}=FFK{end,i,j}; end, end

    bdiagOm2=zeros(n^2*S,n^2*S);
        for i=1:S, 
            bdiagOm2(n^2*(i-1)+1:n^2*i,n^2*(i-1)+1:n^2*i)=kron(OmegaK{i},OmegaK{i});
        end

    BarPsi_OKkOK = bdiagOm2*kron(P',eye(n^2)); % BarPsi_(kron(OmegaK,OmegaK))
    Psi_FKkFK=[]; % Psi_(kron(FK,FK))
    for i=1:S
        Psi_FKkFKrow=[]; 
        for j=1:S,
            Psi_FKkFKrow=[Psi_FKkFKrow P(i,j)*kron(FK{i,j},FK{i,j})];
        end
        Psi_FKkFK=[Psi_FKkFK;Psi_FKkFKrow];
    end
    if discard == 0 
    R_BarPsi_OKkOK = max(abs(eig(BarPsi_OKkOK))); 
    R_Psi_FKkFK  = max(abs(eig(Psi_FKkFK))); 
    else
        R_BarPsi_OKkOK = 1000;
        R_Psi_FKkFK = 1000;
    end
% Additional Output
varargout(1)={GammaK};
varargout(2)={FK};
varargout(3)={termK};
varargout(4)={R_BarPsi_OKkOK};
varargout(5)={R_Psi_FKkFK};

if nargout>5,    
% [7] Impulse responses under Regime-Switching
    D12=cell(S,1);
    for i=1:S
        D12{i}=diag(vecsig{i});
    end
        %FT{j,t) and GT{j,t} are the coefficients of x(t) and z(t) in E_0[(x(t)].
        % Construct FT{j,1) and GT{j,1)
                for i=1:S,
                    FT{i,1}=zeros(n,n); GT{i,1}=zeros(n,m); 
                    for j=1:S,                         
                        FT{i,1}=FT{i,1}+P(i,j)*OmegaK{j};
                        GT{i,1}=GT{i,1}+P(i,j)*GammaK{j}*R{i}; 
                 end, end
      
            for t=2:T-1,
                for i=1:S,
                    FT{i,t}=zeros(n,n); GT{i,t}=zeros(n,m);
                    for j=1:S,                      
                        FT{i,t}=FT{i,t}+P(i,j)*FT{j,t-1}*OmegaK{j};
                        GT{i,t}=GT{i,t}+P(i,j)*((GT{j,t-1}+FT{j,t-1}*GammaK{j})*R{i}); 
                end, end
            end
        
        for i=1:S,
                if vs==1, 
                    tmp=GammaK{i}*D12{i}; IRs=tmp(:)';
                    for t=1:T-1, temp=(FT{i,t}*GammaK{i}+GT{i,t})*D12{i}; IRs=[IRs;temp(:)']; end
                    IRS{i,1}=IRs;
                else % Default
                    tmp=(GammaK{i}*D12{i})'; IRs=tmp(:)';
                    for t=1:T-1, temp=((FT{i,t}*GammaK{i}+GT{i,t})*D12{i})'; IRs=[IRs;temp(:)']; end
                    IRS{i,1}=IRs;    
                end
        end               
varargout(6)={IRS};
end
varargout(7)={BarPsi_OKkOK};
varargout(8)={Psi_FKkFK};
% if nargout>8,
%     varargout(9)={sol_chk};
% end