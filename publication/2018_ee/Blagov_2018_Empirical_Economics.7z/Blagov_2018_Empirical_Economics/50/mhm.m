function [mDens mDens_vec] = mhm(MH_mat,MH_LogPost_mat,p,varargin)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimates the marginal density following the Modified Harmonic Mean method
% --------------------------------------------------------------------------
% Takes as inputs:
%   MH_mat:         the matrix with the draws (not transformed, i.e. bounded)
%   theta_bar:      posterior mean or mode vector (your choice)
%   MH_LogPost_mat: vector with Log posterior values (for each column of MH_Mat)
%   p:              a percentile value for the Chi^2 distribution in Geweke's MHM
%   Nstep(optional):The stepsize (best 100 to 1000, otherwise it is too slow)
%                   If left blank, it would estimate only the full sample 
% Returns as output:
%   hMean:          log value of the marginal density for the full sample size
%   mDens_vec:      (Nstep,1) vector with the stepwise marginal density
% --------------------------------------------------------------------------
% Author:       Boris Blagov
% This version: 08.11.2012
if isempty(varargin) stepwise=0; else stepwise=1; Nstep=varargin{1}; end;

M = size(MH_mat,2);
if stepwise==0
    N = size(MH_mat,2);    
    Nstep = 0;
else
    N = Nstep;
end
Nd = M/N;
k = size(MH_mat,1);
mDens_vec = zeros(M/N,1);
mDenslog_vec = zeros(M/N,1);

for m = 1:Nd
    theta_cov_3d = zeros(k,k,N);
    p_Y_vec = zeros(N,1);
    p_Ylog_vec = zeros(N,1);
    % Estimating the mean and covariance
    theta_bar = (N^-1)*sum(MH_mat(:,1:N),2);
    for s=1:N
       theta_cov_3d(:,:,s) = MH_mat(:,s)*MH_mat(:,s)'-theta_bar*theta_bar';
    end

    theta_cov = (1/N)*sum(theta_cov_3d,3);
    crit_val = chi2inv(p,k);
    for s=1:N
        if (MH_mat(:,s)-theta_bar)'*(theta_cov^(-1))*(MH_mat(:,s)-theta_bar)<= crit_val
            dummy = 1;
        else 
            dummy = 0;
        end
        f_theta = exp(-0.5*(MH_mat(:,s)-theta_bar)'*(theta_cov^(-1))*(MH_mat(:,s)-theta_bar))*dummy/...
        (p*((2*pi)^k/2)*(det(theta_cov)^0.5));

        p_Y_vec(s) =f_theta/exp(MH_LogPost_mat(s));
        p_Ylog_vec(s) = log(f_theta)-MH_LogPost_mat(s);
    end
    mDens = log(((N^-1)*sum(p_Y_vec))^-1);
    mDens_vec(m) = mDens;
    mDens_log = ((N^-1)*sum(p_Ylog_vec(~isinf(p_Ylog_vec))));
    mDenslog_vec(m) = mDens_log;
    N=N+Nstep;    
end