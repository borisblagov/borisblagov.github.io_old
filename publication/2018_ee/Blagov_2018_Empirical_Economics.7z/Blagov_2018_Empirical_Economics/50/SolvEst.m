function [likv_val, theta_cell, Problems] = SolvEst(theta_vec,PM_cell,ndxLam_c,Data)
global ndxSwitch nst

theta_cell=PM_cell;
for ii = 1:length(ndxLam_c)
    theta_cell{ii}(ndxSwitch{1})  = theta_vec(ndxLam_c{1});
    theta_cell{ii}(ndxSwitch{ii}) = theta_vec(ndxLam_c{ii});
end
if nst == 4
    theta_cell{4}(ndxSwitch{1}) = theta_vec(ndxLam_c{1});
    theta_cell{4}(ndxSwitch{4}) = [theta_cell{2}(ndxSwitch{2}); theta_cell{3}(ndxSwitch{3})];
end

[OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_cell);

if nst~=1
    Prob_mat = Prob_extract(theta_cell);
    [likv_val, Problems.Like, pr_tt0Mean, pr_tl0Mean] = MS_Likelihood_Upd(Data, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, Prob_mat);
else
    [likv_val, Problems.Like] = dsge_kf1(Data,OmegaK,GammaK,H,R_mat,Q_cell{1});
end