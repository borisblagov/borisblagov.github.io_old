function [likv, Problems, pr_tt0M, pr_tl0M] = MS_Likelihood(yy, F, G, H, R, Q, mu, P)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimates the likelihood of a Markov Switching Model along the lines of Kim&Nelson 
% (1999)'s "States State-Space Models with Regime-Switching: Classical and Gibbs - 
% Sampling Approaches with Applications" (MIT Press). Supports only a two-state 
% regime switching (s=2) and tracks only two periods.
% This code has been adopted from the Gauss programs by Chang-Jin Kim.
% -------------------------------------------------------------------------
% The model:
%           yy_t = H(s)*beta_t     +   e_t + mu_me(s)     (measurment eq.)
%         beta_t = F(s)*beta_{t-1} + G*v_t + mu_tr(s)     (transition eq.)
% with
%           e_t ~ N(0, R(s)), v_t ~ N(0, Q(s)) and E[e_t v_t] = 0
%
% Output:   [likv] = MS_Likelihood (yy, F, Q, H, R, P) where
% likv:     the final log likelihood value (negative)
% yy:       vector or a matrix - data for the model.
% F:        a cell array with "s" transition matrices F (may be equal).
% H:        a cell array with "s" H matrices, linkin observed with unobserved 
%           variables (usually equal).
% G:        a cell array with the vector augmenting the structural shocks v_t.
% Q:        a cell array with the variance of the structural shocks (1x1 in RBC).          
% R:        a matrix, the variance of e_t
% mu_me/tr: switching means in the model, set to 0.
% P:        the matrix of switching probabilities, defined in the manner of
% Hamilton (1994) and Kim and Nelson (1999): p_21 = Prob(s_t=2 | s_{t-1}=1)
% -------------------------------------------------------------------------
% This version: 02.04.2012 - corrects for the missing G*v_t*G
% Written by: Boris Blagov
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lastwarn('');
Problems = 0;
warn1='MATLAB:illConditionedMatrix';
F_0=F{1};
F_1=F{2};
G_0=G{1};
G_1=G{2};
Q_0=Q{1};
Q_1=Q{2};
mu_0 = mu{1};
mu_1 = mu{2};
ny = size(yy,2);

T=length(yy);
nx=size(F_0,1);   % number of variables in the transition vector F

B_LL0=zeros(nx,1);
B_LL1=zeros(nx,1);

P_LL0=reshape((eye(nx^2)-kron(F_0,F_0))\reshape(G_0*Q_0*G_0',nx^2,1),nx,nx);
P_LL1=reshape((eye(nx^2)-kron(F_1,F_1))\reshape(G_1*Q_1*G_1',nx^2,1),nx,nx);

ppr=P(2,2);   % Pr(S_t=1|St-1=1)
qpr=P(1,1);   % Pr(S_t=0|St-1=0)
prob_1=(1-qpr)/(2-ppr-qpr); % Pr(S_{0}=1|Y_0) the S.S. probability, eq. (4.21) in K&N
prob_0=1-prob_1;            % Pr(S_{0}=0|Y_0) the S.S. probability, eq. (4.22) in K&N

pr_tt0M=zeros(T,1); % to store Pr(S_t=0 | Y_t)
pr_tl0M=zeros(T,1); % to store Pr(S_t=0 | Y_{t-1})
likv=0;


for j=1:T
    %% Probabilities filter
    pr_tl0M(j,1) = qpr*prob_0 + (1-ppr)*prob_1; % Pr(S_t=0 | Y_{t-1})
    
    %% Kalman Filter
    B_TL00 = F_0*B_LL0;       % S_{t-1}=0, S_{t}=0
    B_TL01 = F_1*B_LL0;       % S_{t-1}=0, S_{t}=1
    B_TL10 = F_0*B_LL1;       % S_{t-1}=1, S_{t}=0
    B_TL11 = F_1*B_LL1;       % S_{t-1}=1, S_{t}=1
    
    P_TL00 = F_0*P_LL0*F_0' + G_0*Q_0*G_0'; % S_{t-1}=0, S_{t}=0    
    P_TL01 = F_1*P_LL0*F_1' + G_1*Q_1*G_1'; % S_{t-1}=0, S_{t}=1
    P_TL10 = F_0*P_LL1*F_0' + G_0*Q_0*G_0'; % S_{t-1}=1, S_{t}=0
    P_TL11 = F_1*P_LL1*F_1' + G_1*Q_1*G_1'; % S_{t-1}=1, S_{t}=0
    
    y1=yy(j,:)';
    f_cast00 = y1 - H*B_TL00 - mu_0;  %('eta_{t|t-1}^{i,j}' in K&N's notation)
    f_cast01 = y1 - H*B_TL01 - mu_1;    
    f_cast10 = y1 - H*B_TL10 - mu_0;
    f_cast11 = y1 - H*B_TL11 - mu_1;
    
    ss00 = H*P_TL00*H' + R; % Variance forecast error ('f_{t|t-1}^{i,j}' in K&N's notation)
    ss01 = H*P_TL01*H' + R;
    ss10 = H*P_TL10*H' + R;
    ss11 = H*P_TL11*H' + R;
    
    B_TT00 = B_TL00 + ((P_TL00*H')/ss00)*f_cast00;
    B_TT01 = B_TL01 + ((P_TL01*H')/ss01)*f_cast01;
    B_TT10 = B_TL10 + ((P_TL10*H')/ss10)*f_cast10;    
    B_TT11 = B_TL11 + ((P_TL11*H')/ss11)*f_cast11;
    
    
    P_TT00 = (eye(nx) - ((P_TL00*H')/ss00)*H)*P_TL00;
    P_TT01 = (eye(nx) - ((P_TL01*H')/ss01)*H)*P_TL01;
    P_TT10 = (eye(nx) - ((P_TL10*H')/ss10)*H)*P_TL10;
    P_TT11 = (eye(nx) - ((P_TL11*H')/ss11)*H)*P_TL11;
    
    %% Hamilton filter
    
    % Those are the conditional joint densities Pr(S_{t},S_{t-1},y_{t} | {y_{t-1})
    % the function v_probVec calculates the value of the conditional density
    % scalar in eq. (5.21), page 103.
    PR_VL00 = v_probVec(f_cast00,ss00,ny)*qpr*prob_0;    
    PR_VL01 = v_probVec(f_cast01,ss01,ny)*(1-qpr)*prob_0;
    PR_VL10 = v_probVec(f_cast10,ss10,ny)*(1-ppr)*prob_1;
    PR_VL11 = v_probVec(f_cast11,ss11,ny)*ppr*prob_1;      
    
    pr_val = PR_VL00 + PR_VL01 + PR_VL10 + PR_VL11; %weighted average of the cond. densities f(y_t | y_{t-1})
    
    % The following are Pr(S_t,S_{t-1} | Y_t) - essentialy eq. (5.22) on
    % page 103. The numerator is the conditional density
    % f(y_t|S_t,S_{t-1},y_{t-1}), the denominator - f(y_t|y_{t-1})
    pro_00=PR_VL00/pr_val;  
    pro_01=PR_VL01/pr_val;
    pro_10=PR_VL10/pr_val;
    pro_11=PR_VL11/pr_val;
    
    prob_0=pro_00+pro_10;   % Pr(S_t=0 | Y_t)
    prob_1=pro_01+pro_11;   % Pr(S_t=1 | Y_t)
    
    pr_tt0M(j,1) = prob_0;
    
    %% Collapsing terms
    
    B_LL0=(pro_00*B_TT00 + pro_10*B_TT10)/prob_0;
    B_LL1=(pro_01*B_TT01 + pro_11*B_TT11)/prob_1;
    
    P_LL0=(pro_00*(P_TT00 + (B_LL0 - B_TT00)*(B_LL0 - B_TT00)') + ...
           pro_10*(P_TT10 + (B_LL0 - B_TT10)*(B_LL0 - B_TT10)'))/prob_0;
    
    P_LL1=(pro_01*(P_TT01 + (B_LL1 - B_TT01)*(B_LL1 - B_TT01)') + ...
           pro_11*(P_TT11 + (B_LL1 - B_TT11)*(B_LL1 - B_TT11)'))/prob_1;
       
    if j>1   
        likv = likv+log(pr_val);
    end
[msg, msgid] = lastwarn;
if strcmp(msgid,warn1)==1
    Problems = 1;    
    likv = -100000000;
    return
end
end