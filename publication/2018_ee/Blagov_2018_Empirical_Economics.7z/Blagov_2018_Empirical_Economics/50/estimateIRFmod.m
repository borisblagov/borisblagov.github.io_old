function [responses,betavar,u,A0inv] = estimateIRF(xdata,exo,nlags,nstep,nobs,nvars,sh);


y = xdata(nlags+1:end,:);           % compute a matrix of endogenous var
x = zeros(nobs-nlags,nlags*nvars);  % initialize a matrix for the lagged variables


% create new matrix X 159x12
for zx = 1:nlags
    x(:,(zx-1)*nvars+1:zx*nvars) = xdata((nlags+1)-zx:end-zx,:);
end

xmat = [exo x];


for zx = 1:nvars;
    yvec = y(:,zx);
    beta(:,zx) = xmat'*xmat\xmat'*yvec;
end

betavar = beta;

u = y - xmat*beta;
sigma_u = cov(u);
%sigma_u = u'*u/(nobs-nlags-nvars*nlags-1);  %correction
A0inv = chol(sigma_u)';  % cholesky-decomposition

% structural shocks
epsilon = A0inv\u';

% test of choleski-decomposition
%sigma_z - A0inv*A0inv'

beta = beta(2:end,:);   % get rid of estimates for constant and define B matrix
zlag = zeros(1,nlags*nvars); 
shockpos = sh;
scale= A0inv(shockpos,shockpos);
shock = [A0inv(:,shockpos)'./scale;zeros(nstep-1,nvars)];

for jj=1:nstep;
        imptmp = shock(jj,:)+zlag*beta; 
        responses(:,jj)=imptmp;
        zlag=[imptmp zlag(1,1:(nlags-1)*nvars)];
end;