% Drawing directly with constrained parameters
total_time = tic;
for batch_no = 1:batches
    batch_time = tic;
    move = 0;
    MR = 0;
    MH_draw_mat = zeros(rp,Nsim1_b); % Vector to save the drawn parameters in
    MH_lik_mat = zeros(Nsim1_b,1); % Vector to save the log posterior values in
    for mh = 1:Nsim_b
        draw_k = mvnrnd(draw_km1,ch*InvSigma)';
        lbTest=sum(draw_k>lowBounds_vec);
        ubTest=sum(draw_k<upBounds_vec);
        if lbTest == rp && ubTest == rp;
            % Creating a matrix from the vector
            theta_k_cell=theta_mode;
            for ii = 1:nst - indep
                theta_k_cell{ii}(ndxSwitch{1})=draw_k(ndxLam_c{1});
                theta_k_cell{ii}(ndxSwitch{ii})=draw_k(ndxLam_c{ii});
            end
            if nst == 4
                theta_k_cell{4}(ndxSwitch{1})=draw_k(ndxLam_c{1});
                theta_k_cell{4}(ndxSwitch{4})=[theta_k_cell{2}(ndxSwitch{2}); theta_k_cell{3}(ndxSwitch{3})];
            end

            % Solving
            [lambda_k_cell,lnjac_k,lnprior_k] = MS_repar(theta_k_cell,Rm_cell,0,prior_type_cell);
%             lnprior_k = lnprior_k + lnjac_k;   %If this is uncommented it doesn't work!
            [OmegaK,GammaK,Q_cell,R_mat,H,mu_cell,Problems] = MS_Solve(theta_k_cell);
           
            if nst~= 1
                % Extracting the probabilities
                PS_k = Prob_extract(theta_k_cell);
                if nst == 2
                [likv_k, Problems.Like] = MS_Likelihood(yy, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, PS_k);
                else
                [likv_k, Problems.Like] = MS_Likelihood_Upd(yy, OmegaK, GammaK, H, R_mat, Q_cell, mu_cell, PS_k);
                end
            else
                [likv_k, Problems.Like] = dsge_kf1(yy,OmegaK,GammaK,H,R_mat,Q_cell{1});
            end
            lnpost_k = likv_k + lnprior_k;
            acceptProb = exp(lnpost_k - lnpost_km1);    
            if Problems.FCC + Problems.Det + Problems.Like == 0 && isnan(likv_k)~=1; 
                u = rand(1,1) < acceptProb;
            else
                u = 0;
                fcc_prob = fcc_prob + Problems.FCC; 
                det_prob = det_prob + Problems.Det;   
                lik_prob = lik_prob + Problems.Like;   
            end          
        else
            u = 0;
            bounds_prob = bounds_prob+1;
        end
        movingratio = movingratio+u;    % Total
        move = move+u;
        lnpost_km1 = u*lnpost_k + (1-u)*lnpost_km1;
        
        draw_km1 = u*draw_k + (1-u)*draw_km1;

        if dsave == nskip
            MH_draw_mat(:,mh/dsave) = draw_km1;
            MH_lik_mat(mh/dsave,:) = lnpost_km1;
            MR = MR + u;
            nskip = 1;
        else
            nskip = nskip +1;
        end
        perc=[mh/Nsim_b (mh+(batch_no-1)*Nsim_b)/Nsim_n move/mh]*100;
        if  mh == 1 || mod(mh, disp_freq*15) < 1 
            clc
            toc_n = floor(toc(total_time));
            disp(sprintf('Total no. of draws: %6.0f', Nsim_n));
            disp(sprintf('Burn-in portion   : %6.0f', ndxBurn*dsave));
            disp(sprintf('Actual draws      : %6.0f', Nsim));
            disp(sprintf('Saving every %0.0f-th draw', dsave));
            disp(' ')
            disp(sprintf('Batch: %0.0f of %0.0f', batch_no, batches));
            disp(sprintf('Batch Completion: %0.2f %%', perc(1,1)));
            disp(sprintf('Total Completion: %0.2f %%', perc(1,2)));
            disp(sprintf('Time per batch  : %0.2f minutes',toc_b/60));  
            disp(sprintf('Time Elapsed    : %0.2f minutes',toc_n/60));            
            disp(sprintf('Time Remaining  : %0.2f minutes',(100*toc_n/perc(1,2)-toc_n)/60));
            disp(' ');
            disp(['Batch     Batch    Batch      Total    Total    Total   Total  |Total   Acceptance']);
            disp(['size      iter:     MR:       FCC.P    DET.P    LIK.P   BOU.P  |iter:   Ratio']);
        end
        if mod(mh, disp_freq) < 1 | (mh < 3 )
            disp([sprintf('%6.0f', Nsim_b) '   '...
                  sprintf('%6.0f', mh) '   '...
                  sprintf('%6.0f', move) '   '...
                  sprintf('%6.0f', fcc_prob) '   '...
                  sprintf('%6.0f', det_prob) '   '...
                  sprintf('%6.0f', lik_prob) '   '...
                  sprintf('%6.0f', bounds_prob) '   '...
                  sprintf('|%6.0f  %2.2f %%',mh+(batch_no-1)*Nsim_b,perc(1,3))]);
        end
    end     % End of the batch
    toc_b = floor(toc(batch_time));    
    iter_save = strcat('MH',num2str(run_n),'_',init,num2str(batch_no));
    save(iter_save,'MH_draw_mat','MH_lik_mat','MR','lnpost_km1','draw_km1');
    movefile(strcat(iter_save,'.mat'),simDir_full)
    if batch_no~=batches
        clear MH_draw_mat MH_lik_mat
    end 
end % End of Bayesian