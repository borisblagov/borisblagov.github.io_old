function [c,ceq] = Find_Min_R_Psi_LkL_NL(par,n,S,k,KKSbegin,KKSend,P,F) 
         
         Phi=cell(S,S);
            for i=1:S, for j=1:S
                 Phi{i,j}=reshape(par(KKSbegin(i,j):KKSend(i,j)),k{j},k{i});
             end, end
         nKKSend=KKSend(S,S);
         nVi=nKKSend;
         V=cell(S,1);
         for i=1:S,       
            V{i}= reshape(  par(nVi+1: nVi+n*k{i},:) , n,k{i} );
            nVi=nVi+n*k{i};
         end

         c1=cell(S,1);
         for i=1:S,
            c1{i}=V{i,1}'*V{i,1}-eye(k{i,1},k{i,1});
         end
         
         c2=cell(S,1);
            for i=1:S,
            tmp=zeros(n,k{i,1});
                for j=1:S,
                    tmp=tmp+P(i,j)*F{i,j}*V{j}*Phi{i,j};
                end
            c2{i}=tmp-V{i};
            end
            
         vecc1=[]; for i=1:S, vecc1=[vecc1;vec(c1{i})]; end
         vecc2=[]; for i=1:S, vecc2=[vecc2;vec(c2{i})]; end
                 
         ceq=[vecc1;vecc2]; 

c=[];

