function [smooth, Nsmooth] = MS_smooth(pr_tt0,pr_tl0,P)
TT=length(pr_tt0);
ppr=P(2,2);
qpr=P(1,1);

pr_TT0 = pr_tt0;
pr_TL0 = pr_tl0;

pr_TT1 = 1-pr_TT0;
pr_TL1 = 1-pr_TL0;

pr_sm0 = pr_TT0;  % Pr(S_t | Y_T)
pr_sm1 = pr_TT1;
j=TT-1;
while j>0
    pr_sm00 = pr_sm0(j+1)*   qpr *pr_TT0(j)/pr_TL0(j+1);
    pr_sm01 = pr_sm1(j+1)*(1-qpr)*pr_TT0(j)/pr_TL1(j+1);
    pr_sm10 = pr_sm0(j+1)*(1-ppr)*pr_TT1(j)/pr_TL0(j+1);
    pr_sm11 = pr_sm1(j+1)*   ppr *pr_TT1(j)/pr_TL1(j+1);
    
    pr_sm0(j) = pr_sm00 + pr_sm01;
    pr_sm1(j) = pr_sm10 + pr_sm11;
    j=j-1;
end
Nsmooth = pr_TT0;
smooth = pr_sm0;